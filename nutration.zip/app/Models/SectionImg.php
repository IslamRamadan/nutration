<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class SectionImg extends Model
{
    protected $table='sections_imgs';
    protected $guarded=[];
}
