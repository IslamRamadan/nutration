<?php $__env->startSection('title', 'Checkout'); ?>

<?php $__env->startSection('content'); ?>
 

<!--- --->
<div class="container " >  <br><br>     
 <form method="post" name="checkout" action="">
<?php echo csrf_field(); ?>     
<div class="row pad  ">
<div class="col-md-8 ">
 

<h4 class="main-color "> Shipping Details</h4>


<br>     
 
<?php if(Session::has('stop')): ?>
<div class="alert alert-danger text-center">
<ul>
<li><?php echo \Session::get('stop'); ?></li>
</ul>
</div>
<?php endif; ?>

<?php if(Session::has('success-add')): ?>
<div class="alert alert-success text-center">
<ul>
<li><?php echo \Session::get('success-add'); ?></li>
</ul>
</div>
<?php endif; ?>
<?php if($errors->any()): ?>
<div class="alert alert-danger" style="width:100%">
<ul>
<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<li><?php echo e($error); ?></li>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>
</div>
<?php endif; ?>

<div class="form-group">
<label for="Orders_address_line1"> full name  </label>
<input type="text" class="form-control " name="name" placeholder="first name" required>

</div>

   
   <br>

 

<div class="form-group">
<label for="Orders_address_line1" > country </label>

<select name="country_id"  class="form-control" style="height: 55px;" required>
<option value="">country ..</option>
<?php $__currentLoopData = \App\Models\Country::get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<option value="<?php echo e($country->id); ?>"><?php echo e($country->name_en); ?></option>
 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</select>
</div>
<br>
<div class="form-group">
<label for="Orders_address_line1" > Town / City </label>
<input type="text" class="form-control " name="city_id"  placeholder="Town / City " required>  
</div><br>

<div class="form-group">
<label for="Orders_address_line1" > House number and street name </label>
<input type="text" class="form-control " name="street"  placeholder="House number and street name" required>  
</div>
<br>

<div class="form-group">
<label for="Orders_address_line1" >Apartment, suite, unit  </label>
<input type="text" class="form-control " name="apartment_no"  placeholder="Apartment, suite, unit, etc. (optional)"  >  

</div><br>

<div class="form-group">
<label for="Orders_address_line1" > Phone   </label>
<input type="text" class="form-control " name="phone"  placeholder="Phone  " required>  
</div><br>

<div class="form-group">
<label for="Orders_address_line1"  > Email address  </label>

<input type="email" class="form-control " name="email" placeholder="Email address   " required>  

</div><br>
<br>
<div class="form-group">
<label for="Orders_address_line1"  > Order notes  </label>

<textarea class="col-12" name="note"  placeholder="Order notes (optional)" rows="6"></textarea>
</div>
<br><br>
<br><br>
 

 

</div>
<div class="col-md-4 ">
<div class="col-12 border">
<div class="btn-dark row">
<h4 class=" col-12 mr-0">   Order Summary</h4>
</div><br>
<?php $total = 0 ?>
<?php if(session('cart')): ?> 
<?php $__currentLoopData = session('cart'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $details): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php
$total += $details['price'] * $details['quantity'] ;
$product = \App\Models\Item::where('id', $details['id'])->first();
$vendor = \App\Models\Category::where('id', $product->category_id)->first();
?>
 
<div class="row ">
<a href="<?php echo e(url('/en/product/'.$product->slug)); ?>" class=" col-3">
<img alt="<?php echo e($product->name_en); ?>" src="<?php echo e(asset($product->img)); ?>" width="80px;">
</a>
<div class="col-6">
<a href="<?php echo e(url('/en/product/'.$product->slug)); ?>" ><?php echo e($product->name_en); ?></a> 
<p class="mr-0">Qty : <?php echo e($details['quantity']); ?></p>
<p class="mr-0">vendor : <?php echo e($vendor->name); ?></p>
</div>
<p class="col-3"> <?php echo e($details['price'] * $details['quantity']); ?> KWD </p>
</div>
<hr>
 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
 <?php endif; ?>
<p > Subtotal:<b class="float-right main-color"><?php echo e($total); ?> KWD</b></p>



<p >Shipping:<b class="float-right main-color">Free Shipping</b></p> <hr>
<p >ORDER TOTAL: <b class="float-right main-color"><?php echo e($total); ?> KWD</b></p> <hr>


 <h4 class="main-color">Coupon Discount</h4>

<input type="text" class="form-control "  name="discount_code" placeholder="Coupon code" > <br>


<div class="form-check">
<input class="form-check-input" type="radio" name="payment_method" id="exampleRadios1" value="1" checked>
<label class="form-check-label" for="exampleRadios1">
Cash on delivery 
<br>(Pay with cash upon delivery.
)

</label>
</div>
<br>
<div class="form-check">
<input class="form-check-input mt-3" type="radio" name="payment_method" id="exampleRadios2" value="2">
<label class="form-check-label" for="exampleRadios2">
<img src="<?php echo e(asset('front/img/cash.png')); ?>" class="w-100">  </label>
</div>
<hr><br>
<p>Your personal data will be used to process your order, support your experience throughout this website, and for other purposes described in our <a href="<?php echo e(url('/en/policy')); ?>" target="_blank" class="main-color">privacy policy.</a>

</p>   
<hr><br>                    
<div class="form-check">
<input id="confirm" name="confirm" class="form-check-input" type="checkbox"  >
<label class="form-check-label" for="confirm">
I want to receive updates about products and promotions.
</label>
</div>

<br>            
<button id="btn_form" type="submit"   class="btn w-100 bg-main " onClick="if (!  document.checkout.confirm.checked) {alert('Please accept the terms and conditions!') ; return false; }">place order</button>  <br><br>
<br></div>
</div>

</div>
</form>
<br><br></div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.front2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\kokart\resources\views/front/cart/checkout_en.blade.php ENDPATH**/ ?>