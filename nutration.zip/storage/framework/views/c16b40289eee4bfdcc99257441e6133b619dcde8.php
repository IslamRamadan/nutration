



<?php $__env->startSection('title', 'Wish List'); ?>
<?php $__env->startSection('content'); ?>






    <div class="container"  id="divid"> <br><br>
        <div class="row pad text-center ">
            <?php if(session('success')): ?>

                <div class="alert alert-success text-center" style="width: 60%; margin-left: 15%;">
                    <?php echo e(session('success')); ?>

                </div>

            <?php endif; ?>
            <h1  class="col-12 text-center">Wish List</h1>

            <div class="col-lg-8 col-md-12"> <!--d-md-block d-none-->
                <div class="table_block table-responsive " >
                    <?php if(  count($items) > 0): ?>)

                    <table class="table table-bordered">
                        <thead class="btn-dark">

                        <tr>
                            <th >item name</th>
                            <th >vendor</th>
                            <th >Price</th>
                            <th >QUANTITY</th>
                            <th >SUBTOTAL</th>
                            <th >&nbsp;</th>
                        </tr>
                        </thead>
                        <tbody >

                            <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <tr >
                                    <td >
                                        <a href="#">
                                            <img alt="<?php echo e($item->name_en); ?>" src="<?php echo e(asset($item->img)); ?>" width="100px;">
                                        </a>
                                    </td>
                                    <td >
                                        <p class="">
                                            <a href="<?php echo e(url('/en/item/'.$item->slug)); ?> " class="active"><?php echo e($item->name); ?></a>
                                        </p>

                                        <small>item Code: <span><?php echo e($item->ref_id); ?> </span></small>
                                    </td>

                                    <td >
                                        <span><?php echo e($item->price); ?></span>
                                    </td>

                                    <td data-th="Quantity" class=" text-center" style="width:15%">
                                            <span><?php echo e($item->qut); ?></span>

                                    </td>
                                    <td class="subtotal text-center" data-title="SUBTOTAL">
                                        <span><?php echo e($item->over_price); ?></span>


                                    </td>
                                    <td style="" >

                                        <a href="#" title="delete" style="border: none;color: #fe3843;padding:0px;background: none; cursor: pointer;" class="btn btn-danger btn-sm remove-from-wish " data-id="<?php echo e($item->id); ?>"><i style="width:15px"  class="fas fa-trash"></i></a>

                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                        <?php elseif( count($items) == 0): ?>
                            <tr >
                                <td colspan="7" class="text-center" >  <h1 style="color: red">There are no item in the cart</h1>  </td>
                            </tr>


                        <?php endif; ?>


                        </tbody>
                    </table>
                </div>
            </div>





        </div>
    </div>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>


    <script  >
        $(document).on('click','.remove-from-wish',function (e) {

            e.preventDefault();
            $.ajax({
                type: 'delete',
                url:"<?php echo e(route('wishlist.destroy')); ?>",
                data:{
                    "_token": "<?php echo e(csrf_token()); ?>",
                    'productId':$(this).attr('data-id'),
                },
                success:function (data) {
                    if (data.message){
                                    alert(data.message)
                        Location.reload();
                    }
                }
            });


        });


    </script>






    <!-- pg-body -->


<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\kokart\resources\views/wishlist.blade.php ENDPATH**/ ?>