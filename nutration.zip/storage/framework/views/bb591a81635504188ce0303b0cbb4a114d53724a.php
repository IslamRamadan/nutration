<?php $__env->startSection('title'); ?>
    <?php echo app('translator')->get("site.post_galary"); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('mo'); ?>




<?php $__env->startSection('ti'); ?>
    <?php echo app('translator')->get("site.post_galary"); ?>
<?php $__env->stopSection(); ?>



    <div class="box-body">


        <div class="box-header with-border">
            <?php echo Form::model("", ['route' => ['post_galaries.store',$id],
            "method"=>"post", 'enctype' => 'multipart/form-data'

            ]); ?>

            <?php echo e(csrf_field()); ?>



            <div class="form-group" >
                <label> <?php echo app('translator')->get('site.add_imgs'); ?></label>
                <input type="file" name="img[]" multiple class="form-control"  required>
            </div>





            <div class="form-group">
                <button type="submit" class="btn btn-primary"><i class="fa fa-plus"></i> اضف</button>
            </div>

            <?php echo Form::close(); ?>


        </div><!-- end of box body -->

    </div>

    <div class="box box-primary">







        <div class="box-body">


            <div class="table-responsive">
            <table class="table table-hover table table-bordered">

                <thead>
                <tr>
                    <th>#</th>
                    <th class="text-center"><?php echo app('translator')->get('site.img'); ?></th>





                    <th class="text-center"><?php echo app('translator')->get('site.action'); ?></th>
                </tr>
                </thead>

                <tbody>
                <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


                    <tr>
                        <td><?php echo e($loop->iteration); ?></td>

                        <td class="text-center"> <img style="width:150px;height:100px" src="<?php echo e(asset($post->img)); ?>" alt=""></td>




                        <td class="text-center">

                            <form action="<?php echo e(url(route("post_galaries.destroy",$post->id))); ?>" method="post" style="display: inline-block">
                                <?php echo e(csrf_field()); ?>

                                <?php echo e(method_field('delete')); ?>

                                <button type="submit" class="btn btn-danger delete  btn-sm"><i class="fa  fa-trash"></i> حذف</button>
                            </form><!-- end of form -->

                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </tbody>

            </table><!-- end of table -->
            </div>




        </div><!-- end of box body -->

        <?php if(count($posts)==0): ?>
            <div class="alert alert-danger"> <?php echo app('translator')->get('site.no_data'); ?>
            </div>
        <?php endif; ?>



    </div>





<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.dashboard.app2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\monaleza\Documents\GitHub\Turk\resources\views//dashboard/post_galary/index.blade.php ENDPATH**/ ?>