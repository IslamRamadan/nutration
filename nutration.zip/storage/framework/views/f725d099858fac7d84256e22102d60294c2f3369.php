<html lang="<?php echo e(app()->getLocale()); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="<?php echo e(asset('front/css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('front/css/all.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('front/css/animate.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('front/css/main-style.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('front/css/media.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('front/css/custom.css')); ?>">
    <!-- slick css-->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('front/css/slick.css')); ?>"/>
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('front/css/slick-theme.css')); ?>"/>
    <title><?php echo $__env->yieldContent('title'); ?></title>
</head>

    <?php if(Lang::locale()=='ar'): ?>
        <body class="arabic">

        <?php else: ?>
            <body class="english">


<?php endif; ?>
<?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="container-fluid pad-0 bg-main  ">
    <div class="container  ">
        <div class="float-left">
            <nav class="navbar navbar-expand pad-0 " >
                <ul class="navbar-nav  pad-0">

                    <li class="nav-item ">
                        <a href="tel:<?php echo e($my_setting->contact_phone); ?>" title="" class="nav-link "> <i class="fas fa-phone"></i>  <?php echo e($my_setting->contact_phone); ?></a></li>
                    <li class="nav-item ">
                        <a href="https://wa.me/<?php echo e($my_setting->wats); ?>" title="" class="nav-link "> <i class="fab fa-whatsapp"></i>  <?php echo e($my_setting->wats); ?></a>
                    </li></ul>
            </nav>
        </div>
        <div class="float-right text-dir">
            <nav class="navbar navbar-expand pad-0 " >
                <ul class="navbar-nav pad-0">

                    <li class="nav-item "><a class="nav-link " href="<?php echo e($my_setting->insta_link); ?>" title="instagram"><i class="fab fa-instagram"></i>  </a></li>
                    <li class="nav-item "><a class="nav-link " href="<?php echo e($my_setting->tw_link); ?>" title="twitter"><i class="fab fa-twitter"></i>  </a></li>
                    <li class="nav-item "><a class="nav-link " href="tel:<?php echo e($my_setting->contact_phone); ?>" title="call us"><i class="fas fa-phone"></i>  </a></li>
                    <li class="nav-item "><a class="nav-link " href="<?php echo e($my_setting->yt_link); ?>" title="youtube"><i class="fab fa-youtube"></i>  </a></li>

                </ul>


            </nav>
        </div>
        <div class="clearfix"></div>
    </div></div>

<!--- -->
<div class="container-fluid  border-main sticky-top bg-w">
    <div class="container  ">
        <div class="row  ">
            <nav class="navbar navbar-expand-lg col-12" id="start">
                <a  href="<?php echo e(route('home.index')); ?>" class="p-2">
                    <img src="<?php echo e(asset('front/img/logo.png')); ?>"  class="logo" >
                </a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                    <i class=" fas fa-bars c-b"></i>
                </button>
                <div class="collapse navbar-collapse " id="navbarSupportedContent">
                    <ul class="navbar-nav mr-right pad-0">
                        <li class="nav-item "><a class="nav-link active" href="<?php echo e(route('home.index')); ?>"><?php echo app('translator')->get('site.home'); ?></a></li>
                        

                        
                            
                                
                                    
                                
                                
                                    
                                        
                                            

                                        
                                            


                                        
                                    

                                
                            
                        


                        <?php $__currentLoopData = \App\Models\Category::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="nav-item relative ul1"><a class="nav-link "
                                href="<?php echo e(route('category.show',$b->id)); ?>">
                                <?php if(app()->getLocale() == 'en'): ?>
                                    <?php echo e($b->name_en); ?>

                                <?php else: ?>
                                    <?php echo e($b->name_ar); ?>

                                <?php endif; ?>

                            </a>

                            <div class=" ul2  bg-w  text-dir ">


                                <?php if(\App\Models\Service::where('category_id', $b->id)->count() > 0): ?>
                                    <?php $__currentLoopData = \App\Models\Service::where('category_id', $b->id)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <a class="nav-link " href="<?php echo e(route('service.show',$c->id)); ?>">
                                            <?php if(app()->getLocale() == 'en'): ?>
                                                <?php echo e($c->name_en); ?>

                                            <?php else: ?>
                                                <?php echo e($c->name_ar); ?>

                                            <?php endif; ?>
                                        </a>
                                        
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>

                            </div>

                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                        <li class="nav-item "><a class="nav-link " href="<?php echo e(route('all_products')); ?>" ><?php echo $my_setting['product_'.app()->getLocale()]; ?></a></li>
                        <li class="nav-item "><a class="nav-link " href="<?php echo e(route('all_posts')); ?>" ><?php echo $my_setting['blog_'.app()->getLocale()]; ?></a></li>
                        <li class="nav-item "><a class="nav-link " href="<?php echo e(route('about.index')); ?>" ><?php echo $my_setting['about_'.app()->getLocale()]; ?></a></li>
                        
                        

                        <li class="nav-item"><a class="nav-link " href="<?php echo e(route('contacts.index')); ?>" ><?php echo $my_setting['contact_'.app()->getLocale()]; ?></a></li>

                        <li class="nav-item">
                            <div class="dropdown nav-link" >
                                <div class=" dropdown-toggle"  id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">



                                    <?php if(Lang::locale()=='ar'): ?>
                                        <img src="<?php echo e(asset('front/img/kuwait.png')); ?>" width="20">  العربيه

                                    <?php else: ?>
                                        <img src="<?php echo e(asset('front/img/en.png')); ?>" width="20">  English


                                    <?php endif; ?>
                                </div>
                                <div class="dropdown-menu  text-dir" aria-labelledby="dropdownMenuButton" >

                                        <?php $__currentLoopData = LaravelLocalization::getSupportedLocales(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $localeCode => $properties): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                <a style="color: red" class="dropdown-item" rel="alternate" hreflang="<?php echo e($localeCode); ?>" href="<?php echo e(LaravelLocalization::getLocalizedURL($localeCode, null, [], true)); ?>">
                                                    <?php echo e($properties['native']); ?>

                                                </a>

                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </div>
                            </div>
                        </li>

                    </ul>

                </div>
            </nav>
        </div>
    </div>

</div>
<?php /**PATH C:\Users\monaleza\Documents\GitHub\Turk\resources\views/layouts/front/header.blade.php ENDPATH**/ ?>