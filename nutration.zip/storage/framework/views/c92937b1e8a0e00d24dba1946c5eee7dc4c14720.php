<?php $__env->startSection('title'); ?>
<?php echo app('translator')->get("site.profile"); ?> 
<?php $__env->stopSection(); ?>

<?php $__env->startSection('mo'); ?>
    



     <?php $__env->startSection('ti'); ?>
<?php echo app('translator')->get("site.profile"); ?>     <?php $__env->stopSection(); ?>



        <div class="box box-primary">



            <div class="box-header with-border">





            </div><!-- end of box header -->



            <div class="box-body">


                <?php echo Form::model($profile, ['route' => ['profile.username'],
                "method"=>"post"

                ]); ?>

                  <?php echo e(csrf_field()); ?>




                      <div class="form-group">
                          <label><?php echo app('translator')->get('site.username'); ?></label>
                        <?php echo Form::text('name',$profile->name,[
                      "class"=>"form-control",
                        "required"=>"required"
                        ]); ?>

                      </div>




                  <div class="form-group">
                      <button type="submit" class="btn btn-primary"><i class="fa fa-plus"></i> <?php echo app('translator')->get('site.save'); ?></button>
                  </div>

                  <?php echo Form::close(); ?>







                    <!-- Button trigger modal -->


            </div><!-- end of box body -->






        </div>
        <div class="box box-primary">



            <div class="box-header with-border">





            </div><!-- end of box header -->



            <div class="box-body">


                <?php echo Form::model($profile, ['route' => ['profile.password'],
                "method"=>"post"

                ]); ?>

                  <?php echo e(csrf_field()); ?>




                      <div class="form-group">
                          <label><?php echo app('translator')->get('site.old_password'); ?></label>
                     <input  required type="password" class="form-control" name="old" >
                      </div>



                      <div class="form-group">
                        <label><?php echo app('translator')->get('site.password'); ?></label>
                        <input required type="password" class="form-control" name="password" >
                    </div>

                      <div class="form-group">
                        <label><?php echo app('translator')->get('site.password_confirmation'); ?></label>
                   <input required type="password" class="form-control" name="password_confirmation">
                    </div>







                  <div class="form-group">
                      <button type="submit" class="btn btn-primary"><i class="fa fa-plus"></i> <?php echo app('translator')->get('site.save'); ?></button>
                  </div>

                  <?php echo Form::close(); ?>







                    <!-- Button trigger modal -->


            </div><!-- end of box body -->






        </div>

        <div class="box box-primary">



            <div class="box-header with-border">





            </div><!-- end of box header -->



            <div class="box-body">


                <?php echo Form::model($profile, ['route' => ['profile.email'],
                "method"=>"post"

                ]); ?>

                  <?php echo e(csrf_field()); ?>




                      <div class="form-group">
                          <label><?php echo app('translator')->get('site.email'); ?></label>
                        <?php echo Form::text('email',$profile->email,[
                      "class"=>"form-control",
                      "required"=>"required"

                        ]); ?>

                      </div>




                  <div class="form-group">
                      <button type="submit" class="btn btn-primary"><i class="fa fa-plus"></i> <?php echo app('translator')->get('site.save'); ?></button>
                  </div>

                  <?php echo Form::close(); ?>







                    <!-- Button trigger modal -->


            </div><!-- end of box body -->






        </div>




    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard.app2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\untitled folder\resources\views//dashboard/profile/index.blade.php ENDPATH**/ ?>