<footer class="container-fluid bg-main">
    <div class="container">
        <br><br>
        <div class="row">
            <div class="col-12">
                <h2>PRESTIGE CLEANSING </h2>
                <p><?php echo app('translator')->get('site.home_address'); ?></p>
            </div>
            <div class="col-md-9">

                <a href="<?php echo e(route('home.index')); ?>"><?php echo app('translator')->get('site.home'); ?></a>
                <a href="<?php echo e(route('about.index')); ?>"><?php echo app('translator')->get('site.about_us'); ?></a>
                <a href="<?php echo e(route('contacts.index')); ?>"><?php echo app('translator')->get('site.contact_us'); ?></a>
                <a href="<?php echo e(route('terms')); ?>"><?php echo app('translator')->get('site.terms_and_condition'); ?></a>
                
                

            </div>

            <div class="col-md-3">
                <nav class="navbar navbar-expand pad-0 ">
                    <ul class="navbar-nav mr-auto ">


                        <li class="nav-item "><a class="nav-link " href="<?php echo e($my_setting->insta_link); ?>" title="instagram"><i class="fab fa-instagram"></i>  </a></li>
                        <li class="nav-item "><a class="nav-link " href="<?php echo e($my_setting->tw_link); ?>" title="twitter"><i class="fab fa-twitter"></i>  </a></li>
                        <li class="nav-item "><a class="nav-link " href="<?php echo e($my_setting->fb_link); ?>" title="call us"><i class="fas fa-phone"></i>  </a></li>
                        <li class="nav-item "><a class="nav-link " href="<?php echo e($my_setting->yt_link); ?>" title="youtube"><i class="fab fa-youtube"></i>  </a></li>

                    </ul>

                </nav>
            </div>
            <p class="col-12 text-center"><br><br>All rights reserved © 2020 | This template is made by <a href="https://bluezonekw.com/" target="_blank" class="">blue zone</a></p>

        </div>

    </div>

</footer>







<a href="whatsapp://<?php echo e($my_setting->wats); ?>">
    <img src="<?php echo e(asset('front/img/whatsapp.svg')); ?>" class="whatsapp shadow">
</a>














<script src="<?php echo e(asset('front/js/jquery-3.3.1.min.js')); ?>"></script>
<script src="<?php echo e(asset('front/js/popper.min.js')); ?>"></script>
<script src="<?php echo e(asset('front/js/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('front/js/all.min.js')); ?>"></script>
<script src="<?php echo e(asset('front/js/wow.min.js')); ?>"></script>
<script>
    new WOW().init();
</script>
<script src="<?php echo e(asset('front/js/main-js.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('js/slick.min.js')); ?>"></script>
<script src="<?php echo e(asset('front/js/counterup.min.js')); ?>"></script>

</body>

</html><?php /**PATH C:\xampp\htdocs\prestige\prestige\untitled folder\resources\views/layouts/front/footer.blade.php ENDPATH**/ ?>