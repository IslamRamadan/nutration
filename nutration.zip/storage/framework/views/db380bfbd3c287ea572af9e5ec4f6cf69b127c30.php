
<?php $__env->startSection('title', $records->name_en); ?>

<?php $__env->startSection('id',$records->id); ?>
<?php $__env->startSection('cat_or_sub',1); ?>

<?php $__env->startSection('new_titles'); ?>
    <div class="container  border-main"><br>
        <div class="row  ">
            <div class="col-md-2 col-12 ">
                <h3 style="border-radius: 5px;padding: 10px 15px;background-color: #180a1a;color: white;margin-bottom: 15px">Filter
                </h3>
                <hr>

                <ul>
                    <?php $__currentLoopData = $sub_sub_cat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <li>
                                <a href="<?php echo e(route('sub.cat.products' , $sub->id)); ?>" style="font-weight: bold">
                                <?php echo e($sub->name_en); ?>

                                </a>

                            </li>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
                <hr>

            </div>
            <div class="col-md-10 col-12">
                <div class="row  ">

                    <h3 style="width: 100%;border-radius: 5px;margin: 0 15px;padding: 10px 15px;background: linear-gradient(90deg, rgba(0,24,36,1) 0%, rgba(9,32,121,1) 53%, rgba(0,212,255,1) 100%);color: white"> <?php echo e($records->name_en); ?> </h3>
                    <?php $__env->stopSection(); ?>
                    <?php $__env->startSection('content'); ?>
                      <?php if($populars->count() < 1): ?>

                            <p style="text-align: center ;width: 100%;margin: 30px" >
                                لا يوجد منتجات في هذا القسم
                            </p>
                        <?php else: ?>
                    <?php $__currentLoopData = $populars; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $one): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class=" col-12 col-md-4 col-lg-3 ">
                            <br>
                            <div class="card ">
                                <h6 class="bg-main abs">ref:<?php echo e($one->id); ?></h6>
                                <a href="<?php echo e(route("product",$one->id)); ?>">
                                    <img height="200" src="<?php echo e(asset($one->img)); ?>" class="card-img-top  " alt="..."> </a>
                                <div class="card-body">
                                    <a href="<?php echo e(route("product",$one->id)); ?>" class="card-text "><?php echo e($one->name_en); ?></a>
                                    <p class="card-title" href=""><b>KWD<?php echo e($one->price); ?></b></p>

                                </div>
                                <div class="row mr-0">
                                    <a href="<?php echo e(route('add.cart',[$one->id,1])); ?>" class="btn btn-dark border col-9">add
                                        to cart</a>
                                    <?php if(!Auth::guard('client')->check()): ?>

                                    <div class="btn btn-light border col-3 heart text-center"><a href="<?php echo e(route('login/client')); ?>"><i class="fas fa-heart heart-none"></i><i class="far fa-heart  heart-block"></i></a></div>

                                            <?php elseif(Auth::guard('client')->check()): ?>

                                            <div class="addToWishlist btn btn-light border col-3 heart text-center" data-product-id = "<?php echo e($one->id); ?>"> <i class="fas fa-heart heart-none"></i><i class="far fa-heart  heart-block"></i>
                                            </div>
 <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>

                </div>
                <br>
                <?php echo e($populars->appends(request()->query())->links()); ?>

                <br><br>
            </div>
            </div>
            </div>
            <br><br>



<?php $__env->stopSection(); ?>





<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script> 
    <script  >
    $(document).on('click','.addToWishlist',function (e) {

        e.preventDefault();
        $.ajax({
            type: 'get',
            url:"<?php echo e(route('wishlist.store')); ?>",
            data:{
                'productId':$(this).attr('data-product-id'),
            },
            success:function (data) {
                if (data.message){
                alert(data.message)}
                else {
                    alert('This product already in you wishlist');
                }
            }
        });


    });


</script>
    
   

<?php echo $__env->make('layouts.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\untitled folder\resources\views/front/cat.blade.php ENDPATH**/ ?>