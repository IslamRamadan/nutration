

<?php $__env->startSection('title'); ?>
    <?php echo app('translator')->get("why_works"); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('mo'); ?>




<?php $__env->startSection('ti'); ?>
    <?php echo app('translator')->get("site.why_work"); ?>

<?php $__env->stopSection(); ?>



<div class="  " style="padding:10px">

    <a href="<?php echo e(route('why_works.create')); ?>" class="btn btn-primary"><i class="fa fa-plus"></i> <?php echo app('translator')->get("site.new"); ?></a>

</div>


<div class="box box-primary">







    <div class="box-body">


        <div class="table-responsive">
            <table class="table table-hover table-bordered  ">

                <thead>
                <tr>
                    <th>#</th>

                    <th class="text-center"><?php echo app('translator')->get('site.title_en'); ?></th>
                    <th class="text-center"><?php echo app('translator')->get('site.title_ar'); ?></th>
                    <th class="text-center"><?php echo app('translator')->get('site.content_en'); ?></th>
                    <th class="text-center"><?php echo app('translator')->get('site.content_ar'); ?></th>

                    <th class="text-center"><?php echo app('translator')->get('site.Procedures'); ?></th>
                </tr>
                </thead>

                <tbody>
                <?php $__currentLoopData = $works; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $work): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


                    <tr>
                        <td><?php echo e($loop->iteration); ?></td>
                        <td class="text-center"><?php echo e($work->title_en); ?></td>

                        <td class="text-center"><?php echo e($work->title_ar); ?></td>
                        <td class="text-center"><?php echo e($work->content_en); ?></td>
                        <td class="text-center"><?php echo e($work->content_ar); ?></td>


                        <td class="text-center">

                            <a href="<?php echo e(url(route("why_works.edit",$work->id))); ?>" class="btn btn-info btn-sm"><i class="fa fa-edit"></i> <?php echo app('translator')->get('site.edit'); ?></a>


                            <form action="<?php echo e(url(route("why_works.destroy",$work->id))); ?>" method="post" style="display: inline-block">
                                <?php echo e(csrf_field()); ?>

                                <?php echo e(method_field('delete')); ?>

                                <button type="submit" class="btn btn-danger delete  btn-sm"><i class="fa  fa-trash"></i> <?php echo app('translator')->get('site.delete'); ?></button>
                            </form><!-- end of form -->

                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </tbody>

            </table><!-- end of table -->
        </div>

    <?php echo e($works->appends(request()->query())->links()); ?>

    <!-- Button trigger modal -->


    </div><!-- end of box body -->

    <?php if(count($works)==0): ?>

                    <div class="alert alert-danger"><?php echo app('translator')->get('site.no_data'); ?>
                    </div>
                <?php endif; ?>













            </div>












<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard.app2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\prestige\untitled folder\resources\views//dashboard/why_works/index.blade.php ENDPATH**/ ?>