
<?php $__env->startSection('title'); ?>
<?php echo app('translator')->get("site.users"); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('mo'); ?>
<?php echo $__env->make('flash::message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $role = app('App\Role'); ?>

    <?php $__env->startSection('ti'); ?>
    <?php echo app('translator')->get("site.managers"); ?>

<?php $__env->stopSection(); ?>
    <div class="  " style="padding:10px">

            <a href="<?php echo e(url(route("users.create"))); ?>" class="btn btn-primary"><i class="fa fa-plus"></i> <?php echo app('translator')->get("site.new"); ?></a>

    </div>


        <div class="box box-primary">



            <div class="box-header with-border">





                    <form action="<?php echo e(route('users.index')); ?>" method="get">

                        <div class="row">

                            <div class="col-md-4"  style="margin-top:5px ">
                                <?php echo Form::text('keyword',request('keyword'),[
                                    'class' => 'form-control',
                                    'placeholder' => 'Search By name or email'
                                ]); ?>

                            </div>


                            <div class="col-sm-4" style="margin-top: 5px">
                                <?php echo Form::select('role_id',$role->pluck('display_name','id')->toArray(),request('role_id'),[
                                        'class' => 'form-control',
                                        'placeholder' =>'search by level'
                                    ]); ?>

                            </div>

                            <div class="col-md-4" style="margin-top:5px ">
                                <button  type="submit" class="btn btn-primary btn-block"><i class="fa fa-search"></i> <?php echo app('translator')->get('site.search'); ?></button>



                            </div>

                        </div>
                    </form><!-- end of form -->


            </div><!-- end of box header -->



            <div class="box-body">


                <div class="table-responsive">
                    <table class="data-table table table-bordered">
                        <thead>
                        <th>#</th>
                        <th class="text-center"><?php echo app('translator')->get('site.user_name'); ?></th>
                        <th class="text-center"><?php echo app('translator')->get('site.user_name'); ?></th>
                        <th class="text-center"><?php echo app('translator')->get('site.rank'); ?></th>
                        <th class="text-center"><?php echo app('translator')->get('site.Procedures'); ?></th>
                        </thead>
                        <tbody>

                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr >
                                <td><?php echo e($loop->iteration); ?></td>
                                <td class="text-center"><?php echo e($user->name); ?></td>
                                <td class="text-center"><?php echo e($user->email); ?></td>
                                <td class="text-center">
                                    <?php $__currentLoopData = $user->roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <span class="label label-success"><?php echo e($role->display_name); ?></span>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </td>
                                <td class="text-center">
                                    <a href="<?php echo e(url(route("users.edit",$user->id))); ?>" class="btn btn-info btn-sm"><i class="fa fa-edit"></i> <?php echo app('translator')->get('site.edit'); ?></a>
                               
                                    <form action="<?php echo e(url(route("users.destroy",$user->id))); ?>" method="post" style="display: inline-block">
                                        <?php echo e(csrf_field()); ?>

                                        <?php echo e(method_field('delete')); ?>

                                                <button type="submit" class="btn btn-danger delete  btn-sm"><i class="fa  fa-trash"></i> <?php echo app('translator')->get('site.delete'); ?></button>
                                            </form><!-- end of form -->

                                    </td>
                            </tr>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>

                    <?php echo e($users->appends(request()->query())->links()); ?>

                    <!-- Button trigger modal -->


            </div><!-- end of box body -->

            <?php if(count($users)==0): ?>
            <div class="alert alert-danger">  <?php echo app('translator')->get('site.no_data'); ?>
            </div>
             <?php endif; ?>




        </div>


    </div><!-- end of box body -->





<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard.app2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\prestige\untitled folder\resources\views/dashboard/users/index.blade.php ENDPATH**/ ?>