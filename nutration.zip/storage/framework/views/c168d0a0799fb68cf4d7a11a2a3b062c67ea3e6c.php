
<?php $__env->startSection('title'); ?>
    <?php echo app('translator')->get("site.contacts_sec"); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('mo'); ?>




<?php $__env->startSection('ti'); ?>
    <?php echo app('translator')->get("site.contacts_sec"); ?>
<?php $__env->stopSection(); ?>



<div class="box box-primary">







    <div class="box-body">


        <div class="table-responsive">
            <table class="table table-hover table-bordered  ">

                <thead>
                <tr>
                    <th>#</th>

                    <th class="text-center"><?php echo app('translator')->get('site.name'); ?></th>
                    <th class="text-center"><?php echo app('translator')->get('site.email'); ?></th>
                    <th class="text-center"><?php echo app('translator')->get('site.phone'); ?></th>
                    <th class="text-center"><?php echo app('translator')->get('site.comment'); ?></th>

                </tr>
                </thead>

                <tbody>
                <?php $__currentLoopData = $contacts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contact): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


                    <tr>
                        <td><?php echo e($loop->iteration); ?></td>
                        <td class="text-center"><?php echo e($contact->name); ?></td>

                        <td class="text-center"><?php echo e($contact->email); ?></td>
                        <td class="text-center"><?php echo e($contact->phone); ?></td>
                        <td class="text-center"><?php echo e($contact->comment); ?></td>



                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </tbody>

            </table><!-- end of table -->
        </div>

    <?php echo e($contacts->appends(request()->query())->links()); ?>

    <!-- Button trigger modal -->


    </div><!-- end of box body -->

    <?php if(count($contacts)==0): ?>

        <div class="alert alert-danger"><?php echo app('translator')->get('site.no_data'); ?>
        </div>
    <?php endif; ?>













</div>














<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard.app2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\prestige\untitled folder\resources\views//dashboard/contacts/index.blade.php ENDPATH**/ ?>