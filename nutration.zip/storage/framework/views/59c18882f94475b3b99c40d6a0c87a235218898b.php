<?php $__env->startSection('mo'); ?>

<?php $Slider = app('App\Models\Slider'); ?>

<?php $User = app('App\User'); ?>
<?php $Role = app('App\Role'); ?>


     <?php $__env->startSection('ti'); ?>
         <?php echo app('translator')->get('site.home'); ?>
     <?php $__env->stopSection(); ?>



        <div class="box box-primary">
            <section class="content" style="background: #ECF0F5">
                <!-- Info boxes -->
                <div class="row">




                  <!-- fix for small devices only -->

                    <?php if(Auth::user()->job_id == 1): ?>


                  <div class="col-md-3 col-sm-6 col-xs-12">
                    <div class="info-box">
                      <span class="info-box-icon  bg-aqua"><i class="fa fa-list"></i></span>
                      <div class="info-box-content">
                        <span class="info-box-text">         <?php echo app('translator')->get('site.slider'); ?>
</span>
                        <span class="info-box-number"><?php echo e($Slider->count()); ?></span>
                      </div><!-- /.info-box-content -->
                    </div><!-- /.info-box -->
                  </div><!-- /.col -->








                  <div class="col-md-3 col-sm-6 col-xs-12">
                    <div class="info-box">
                      <span class="info-box-icon bg-red"><i class="fa fa-users"></i></span>
                      <div class="info-box-content">
                        <span class="info-box-text">         <?php echo app('translator')->get('site.managers'); ?>
</span>
                        <span class="info-box-number"><?php echo e($User->count()); ?></span>
                      </div><!-- /.info-box-content -->
                    </div><!-- /.info-box -->
                  </div><!-- /.col -->


                  <div class="col-md-3 col-sm-6 col-xs-12">
                    <div class="info-box">
                      <span class="info-box-icon bg-green"><i class="fa fa-list"></i></span>
                      <div class="info-box-content">
                        <span class="info-box-text">         <?php echo app('translator')->get('site.managers_role'); ?>
</span>
                        <span class="info-box-number"><?php echo e($Role->count()); ?></span>
                      </div><!-- /.info-box-content -->
                    </div><!-- /.info-box -->
                  </div><!-- /.col -->





<?php endif; ?>


                </div><!-- /.row -->
              </section><!-- /.content -->


             




              </div><!-- end of box body -->










<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
<script src="https://canvasjs.com/assets/script/canvasjs.min.js"></script>
<script>
  window.onload = function () {

  var chart = new CanvasJS.Chart("chartContainer", {
    animationEnabled: true,

    axisX:{
      valueFormatString: "DD MMM"
    },
    axisY: {
      title: "عدد الطلبات",
      scaleBreaks: {
        autoCalculate: true
      }
    },
    data: [{
		type: "line",
		xValueFormatString: "DD MMM",
		color: "#F08080",
		dataPoints: [


		]
	}]
});
  chart.render();

  }

  </script>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.dashboard.app2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\monaleza\Documents\GitHub\Turk\resources\views/dashboard/welcome.blade.php ENDPATH**/ ?>