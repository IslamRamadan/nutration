<?php $__env->startSection('title'); ?>
<?php echo app('translator')->get("site.add_user"); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('mo'); ?>
<?php echo $__env->make('flash::message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $role = app('App\Role'); ?>

    <?php $__env->startSection('ti'); ?>
<?php echo app('translator')->get("site.add_user"); ?>
<?php $__env->stopSection(); ?>

        <div class="box box-primary">




            <div class="box-header">

            </div><!-- end of box header -->
            <div class="box-body">




               <?php echo Form::model($model, ['route' => ['users.store'],
               "method"=>"post"

               ]); ?>





<?php
$roles = $role->pluck('display_name', 'id')->toArray();
?>

<div class="form-group">
    <label for="name"><?php echo app('translator')->get("site.name"); ?>
</label>
    <?php echo Form::text('name',null,[
    'class' => 'form-control'
 ]); ?>

</div>
<div class="form-group">
    <label for="email"><?php echo app('translator')->get("site.email"); ?>
</label>
    <?php echo Form::text('email',null,[
    'class' => 'form-control'
 ]); ?>

</div>
<div class="form-group">
    <label for="password"><?php echo app('translator')->get("site.password"); ?>
</label>
    <?php echo Form::password('password',[
    'class' => 'form-control'
 ]); ?>

</div>
<div class="form-group">
    <label for="password_confirmation"><?php echo app('translator')->get("site.password_confirmation"); ?>
</label>
    <?php echo Form::password('password_confirmation',[
    'class' => 'form-control'
 ]); ?>

</div>
<div class="form-group">
    <label for="roles_list"> <?php echo app('translator')->get("site.users_arrangment"); ?></label>
    <?php echo Form::select('roles_list[]',$roles,null,[
    'class' => 'form-control select2',
    'multiple' => 'multiple',
 ]); ?>

</div>

<div class="form-group">
 <button class="btn btn-primary" type="submit" > <?php echo app('translator')->get("site.save"); ?></button>
</div>







             <?php echo Form::close (); ?>


            </div><!-- end of box body -->

        </div><!-- end of box -->






<?php $__env->stopSection(); ?>


















<?php echo $__env->make('layouts.dashboard.app2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\monaleza\Documents\GitHub\Turk\resources\views//dashboard/users/create.blade.php ENDPATH**/ ?>