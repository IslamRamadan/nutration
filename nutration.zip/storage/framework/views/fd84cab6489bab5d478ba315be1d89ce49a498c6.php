
<?php $__env->startSection('title','Address Edit'); ?>
<?php echo app('translator')->get(""); ?>
<?php $__env->startSection('content'); ?>

    <form method="post" action="<?php echo e(route('address.update',$address->id)); ?>">
        <?php echo csrf_field(); ?>
        <?php echo method_field('put'); ?>

        <div class="sign w-50 text-center shadow pad-10">
            <br>
            <h1>Edit adress</h1>
            <div class="d-flex">

                <input placeholder="City" class="w-50 " type="text" name="city" value="<?php echo e(old('city',$address->city)); ?>">
                <input placeholder="Government" class="w-50 " type="text" name="gover" value="<?php echo e(old('gover',$address->gover)); ?>">


            </div>

            <div class="d-flex">
                <input placeholder="Plot" class="w-50 " type="number" name="plot" value="<?php echo e(old('plot',$address->plot)); ?>">
                <input placeholder="Street" class="w-50 " type="text" name="street" value="<?php echo e(old('street',$address->street)); ?>">
            </div>




            <div class="d-flex">

                <input placeholder="Building number" class="w-50 " type="text" name="building_number" value="<?php echo e(old('building_number',$address->building_number)); ?>">

                <input placeholder="Role" class="w-50 " type="number" name="role" value="<?php echo e($address->role); ?>">
            </div>

            <textarea class="w-100 "name="additionaltips" rows="4" cols="50" ><?php echo e(old('additionaltips',$address->additionaltips)); ?>

            </textarea>



            <input placeholder="client_id" class="w-50 " type="hidden" name="client_id" value="<?php echo e(Auth::guard('client')->user()->id); ?>">

            <button type="submit" class="btn w-100 btn-dark bg-main">Add address </button><br><br>

            <br>
        </div>
    </form>

    <br><br>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\untitled folder\resources\views/front/address_edit.blade.php ENDPATH**/ ?>