

<?php $__env->startSection('title'); ?>
<?php echo app('translator')->get("site.categories"); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('mo'); ?>
    



     <?php $__env->startSection('ti'); ?>
         الاقسام 
     <?php $__env->stopSection(); ?>



    <div class="  " style="padding:10px">

            <a href="<?php echo e(route('subCategories.create')); ?>" class="btn btn-primary"><i class="fa fa-plus"></i> <?php echo app('translator')->get("site.new"); ?></a>

    </div>


        <div class="box box-primary">



            <div class="box-header with-border">



                <form action="<?php echo e(route('subCategories.index')); ?>" method="get">

                    <div class="row">

                        
                            

                            <div class="col-md-12">
                                <?php $cat = app('App\Models\Category'); ?>
                            <?php echo Form::select('category_id',$cat->pluck('name','id')->toArray(),null,[
                               'class' => 'form-control ' . ($errors->has('category_id') ? ' is-invalid' : null),
                                'id' => 'category_id',
                                'placeholder' => 'اختر التاجر',
                              

                            ]); ?>


                            </div>
                       

                        <div class="col-md-6"  style="margin-top:5px ">
                            <input type="text" name="search" class="form-control" placeholder="بحث بالاسم" value="<?php echo e(request()->search); ?>">
                        </div>

                        <div class="col-md-6" style="margin-top:5px ">
                            <button  type="submit" class="btn btn-primary btn-block"><i class="fa fa-search"></i> <?php echo app('translator')->get('site.search'); ?></button>



                        </div>

                    </div>
                </form><!-- end of form -->

            </div><!-- end of box header -->



            <div class="box-body">


                <div class="table-responsive">
                    <table class="table table-hover table-bordered  ">

                        <thead>
                        <tr>
                            <th>#</th>
                            <th class="text-center"><?php echo app('translator')->get('التاجر '); ?></th>
                            <th class="text-center"><?php echo app('translator')->get('القسم  '); ?></th>
                            <th class="text-center"><?php echo app('translator')->get('الترجمة '); ?></th>
                            <th class="text-center"><?php echo app('translator')->get('الصورة '); ?></th>
                            <th class="text-center"><?php echo app('translator')->get('الحالة'); ?></th>
                            <th class="text-center"><?php echo app('translator')->get('الترتيب'); ?></th>

                            <th class="text-center"><?php echo app('translator')->get('الاجراءت'); ?></th>
                        </tr>
                        </thead>

                        <tbody>
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


                            <tr>
                                <td><?php echo e($loop->iteration); ?></td>
                                <td class="text-center"><?php echo e($cat->find( $category->category_id)->name??""); ?></td>
                            <td class="text-center"><?php echo e($category->name); ?></td>
                            <td class="text-center"><?php echo e($category->name_en); ?></td>
                            <td class="text-center"><img src="<?php echo e(asset($category->img)); ?>" alt="" width="90px" height="70px">  </td>
                            <td class="text-center"><?php echo e($category->activity==1?"مفعل":"معطل"); ?></td>
                            <td class="text-center"><?php echo e($category->num); ?></td>


                                <td class="text-center">

                                        <a href="<?php echo e(url(route("subCategories.edit",$category->id))); ?>" class="btn btn-info btn-sm"><i class="fa fa-edit"></i> <?php echo app('translator')->get('site.edit'); ?></a>

                               
                                <form action="<?php echo e(url(route("subCategories.destroy",$category->id))); ?>" method="post" style="display: inline-block">
                                    <?php echo e(csrf_field()); ?>

                                    <?php echo e(method_field('delete')); ?>

                                            <button type="submit" class="btn btn-danger delete  btn-sm"><i class="fa  fa-trash"></i> <?php echo app('translator')->get('site.delete'); ?></button>
                                        </form><!-- end of form -->

                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </tbody>

                    </table><!-- end of table -->
                </div>

                    <?php echo e($categories->appends(request()->query())->links()); ?>

                    <!-- Button trigger modal -->


            </div><!-- end of box body -->

            <?php if(count($categories)==0): ?>
            <div class="alert alert-danger"> لا يوجد بيانات
            </div>
             <?php endif; ?>










  

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard.app2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/bluezo11/kocart.easyshop-qa.com/resources/views//dashboard/subCategories/index.blade.php ENDPATH**/ ?>