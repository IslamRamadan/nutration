
<?php $__env->startSection('title'); ?>
<?php echo app('translator')->get("site.settings"); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('mo'); ?>
<?php echo $__env->make('flash::message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php $__env->startSection('ti'); ?>
    <?php echo app('translator')->get("site.settings"); ?>

<?php $__env->stopSection(); ?>


        <div class="box box-primary">



            <div class="box-header with-border">





            </div><!-- end of box header -->



            <div class="box-body">

             <?php if($setting): ?>

                    <?php
                  
                  $about_app=$setting->about_app;
                   $about_app_en=$setting->about_app_en;
                    $strategy=$setting->strategy;
                   $strategy_en=$setting->strategy_en;
                  $currency=$setting->currency;

                    
                      $color=$setting->color;
                      $color2=$setting->color2;
                    $id = $setting->id;
			     	$dolar=$setting->dolar	;
			     	$android=$setting->android	;
			     	$ios=$setting->ios	;
			     	$contact_phone= $setting->contact_phone	;
                   
                     ?>

             <?php else: ?>

                    <?php
                    
                   
                    $id = "";
					$dolar= ""	;
			        $contact_phone= ""	;
			        $color= ""	;
			        $colo2r="";
			        $android= ""	;
			        $ios= ""	;


                  $about_app= "";
                   $about_app_en= "";
                    $strategy= "";
                   $strategy_en= "";
                  $currency= "";

                      ?>

             <?php endif; ?>
                <?php echo Form::model($setting, ['route' => ['settings.update',$id],
                "method"=>"post",
                "enctype"=>"multipart/form-data"

                ]); ?>

                  <?php echo e(csrf_field()); ?>

                  
                    
                  
                  

                  
                
                 <div class="form-group">
                        <label><?php echo app('translator')->get('site.contact_phone'); ?></label>
                      <?php echo Form::text('contact_phone',$contact_phone,[
                    "class"=>"form-control"

                      ]); ?>

                    </div>
                    
                     
                        
                        
                       
                        
                      
                    

                      
                    
                    
                     
                        
                        
                       
                        
                      
                    

                      
                    
                    
                     
                        
                      
                    

                      
                    
                    
                    
                     <div class="form-group">
                        <label><?php echo app('translator')->get('site.ggl_play'); ?></label>
                      <?php echo Form::text('android',$android,[
                    "class"=>"form-control"

                      ]); ?>

                    </div>
                    
                     <div class="form-group">
                        <label><?php echo app('translator')->get('site.app_store'); ?></label>
                      <?php echo Form::text('ios',$ios,[
                    "class"=>"form-control"

                      ]); ?>

                    </div>
                    
                    
                    <div class="form-group">
                         <label><?php echo app('translator')->get('site.about_app'); ?></label>
                       <textarea  class="form-control" rows="10"  name="about_app">
                          <?php echo e($about_app); ?>

                       </textarea >
                    </div>
                    
                     <div class="form-group">
                         <label><?php echo app('translator')->get('site.about_app_en'); ?></label>
                       <textarea  class="form-control" rows="10"  name="about_app_en">
                          <?php echo e($about_app_en); ?>

                       </textarea >
                    </div>
                    
                    
                     <div class="form-group">
                         <label><?php echo app('translator')->get("site.terms_and_condition"); ?></label>
                       <textarea  class="form-control" rows="10"  name="strategy">
                          <?php echo e($strategy); ?>

                       </textarea >
                    </div>
                    
                     <div class="form-group">
                         <label><?php echo app('translator')->get("site.terms_and_condition_en"); ?></label>
                       <textarea  class="form-control" rows="10"  name="strategy_en">
                          <?php echo e($strategy_en); ?>

                       </textarea >
                    </div>
                    
                    
                    
                
                

         


                    

                  


                  <div class="form-group">
                      <button type="submit" class="btn btn-primary"><i class="fa fa-plus"></i> <?php echo app('translator')->get('site.save'); ?></button>
                  </div>

                  <?php echo Form::close(); ?>




                    <!-- Button trigger modal -->


            </div><!-- end of box body -->






        </div>






  

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard.app2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\prestige\untitled folder\resources\views//dashboard/settings/index.blade.php ENDPATH**/ ?>