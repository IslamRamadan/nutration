<?php $__env->startSection('title'); ?>
    <?php echo app('translator')->get("site.settings"); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('mo'); ?>
    <?php echo $__env->make('flash::message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->startSection('ti'); ?>
    <?php echo app('translator')->get("site.settings"); ?>

<?php $__env->stopSection(); ?>


<div class="box box-primary">



    <div class="box-header with-border">





    </div><!-- end of box header -->



    <div class="box-body">

        <?php if($setting): ?>

            <?php


            $description_ar = $setting->description_ar;
            $description_en = $setting->description_en;
            $about_app_ar  = $setting->about_app_ar ;
            $about_app_en = $setting->about_app_en;
            $name = $setting->name;
            $name_en = $setting->name_en;

            $wats = $setting->wats;
            $yt_link = $setting->yt_link;
            $insta_link = $setting->insta_link;
            $tw_link = $setting->tw_link;
            $color2 = $setting->color2;
            $id = $setting->id;
            $dolar = $setting->dolar;
            $android = $setting->android;
            $ios = $setting->ios;
            $contact_phone = $setting->contact_phone;
            $address = $setting->address;
            $address_en = $setting->address_en;

            ?>

        <?php else: ?>

            <?php

            $id = '';
            $dolar = '';
            $contact_phone = '';
            $address = '';
            $address_en = '';
            $wats = '';
            $yt_link = '';
            $insta_link = '';
            $tw_link = '';
            $colo2r = '';
            $name = '';
            $name_en = '';


            $android = '';
            $ios = '';

            $description_ar = '';
            $description_en = '';
            $about_app_ar  = '';
            $about_app_en  = '';


            ?>

        <?php endif; ?>
        <?php echo Form::model($setting, ['route' => ['settings.update', $id], 'method' => 'post', 'enctype' => 'multipart/form-data']); ?>

        <?php echo e(csrf_field()); ?>

        
        
        
        

        
        
        <div class="form-group">
            <label><?php echo app('translator')->get('site.name_ar'); ?></label>
            <input class="form-control" name="name" value="<?php echo e($name); ?>">
        </div>
        <div class="form-group">
            <label><?php echo app('translator')->get('site.name_en'); ?></label>
            <input class="form-control" name="name_en" value="<?php echo e($name_en); ?>">
        </div>

        <div class="form-group">
            <label><?php echo app('translator')->get('site.web_en'); ?></label>
            <input class="form-control" name="description_en" value="<?php echo e($description_en); ?>">
        </div>
        <div class="form-group">
            <label><?php echo app('translator')->get('site.web_ar'); ?></label>
            <input class="form-control" name="description_ar" value="<?php echo e($description_ar); ?>">
        </div>
        <div class="form-group">
            <label><?php echo app('translator')->get('site.logo'); ?></label>
            <input type="file" class="form-control" name="logo">
        </div>
        <img src="<?php echo e(asset('/storage/' . $setting->logo)); ?>" alt="" width="50%">


        
        <div class="form-group">
            <label><?php echo app('translator')->get('site.contact_phone'); ?></label>
            <?php echo Form::text('contact_phone', $contact_phone, [
    'class' => 'form-control',
]); ?>

        </div>
        <div class="form-group">
            <label><?php echo app('translator')->get('site.wats'); ?></label>
            <?php echo Form::text('wats', $wats, [
    'class' => 'form-control',
]); ?>

        </div>
        <div class="form-group">
            <label><?php echo app('translator')->get('site.yt_link'); ?></label>
            <?php echo Form::text('yt_link', $yt_link, [
    'class' => 'form-control',
]); ?>

        </div>
        <div class="form-group">
            <label><?php echo app('translator')->get('site.tw_link'); ?></label>
            <?php echo Form::text('tw_link', $tw_link, [
    'class' => 'form-control',
]); ?>

        </div>
        <div class="form-group">
            <label><?php echo app('translator')->get('site.insta_link'); ?></label>
            <?php echo Form::text('insta_link', $insta_link, [
    'class' => 'form-control',
]); ?>

        </div>

        <div class="form-group">
            <label><?php echo app('translator')->get('site.about_app'); ?></label>
            <textarea class="form-control" rows="10" name="about_app_ar">
                          <?php echo e($about_app_ar); ?>

                       </textarea>
        </div>

        <div class="form-group">
            <label><?php echo app('translator')->get('site.about_app_en'); ?></label>
            <textarea id="summernote" class="form-control" rows="10" name="about_app_en">
                          <?php echo e($about_app_en); ?>

                       </textarea>
        </div>

        <div class="form-group">
            <button type="submit" class="btn btn-primary"><i class="fa fa-plus"></i> <?php echo app('translator')->get('site.save'); ?></button>
        </div>

        <?php echo Form::close(); ?>




        <!-- Button trigger modal -->


    </div><!-- end of box body -->






</div>






<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

<script src="https://cdn.ckeditor.com/4.17.1/standard/ckeditor.js"></script>
<script>
    CKEDITOR.replace('about_app_ar');
    CKEDITOR.replace('about_app_en');
</script>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard.app2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\monaleza\Documents\nutration\resources\views//dashboard/settings/index.blade.php ENDPATH**/ ?>