<?php $__env->startSection('title'); ?>
    

    <?php echo app('translator')->get('site.about'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<!-----start carousel --->
<div  class=" relative1 " >
    <div class="abs w-100">
        <h4 class="custom-h4"><?php echo $my_setting['about_'.app()->getLocale()]; ?></h4>
        <h1><?php echo app('translator')->get('site.about'); ?></h1>

    </div>
</div>

<div class="container-fluid">
    <div class="row justify-content-between">
        <div class="col-md-7 col-12 ">

<br>
<?php echo $my_setting['about_app_'.app()->getLocale()]; ?>


    </div>
</div>

</div>
<!--- -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.front.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\monaleza\Documents\nutration\resources\views/front/about.blade.php ENDPATH**/ ?>