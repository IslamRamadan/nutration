
<?php $__env->startSection('title', $records->name_en); ?>

<?php $__env->startSection('content'); ?>
 <div class="container  border-main">
        <div class="row ">
             
         <h1 class="col-md-12   main-color text-center">
             <img src="<?php echo e(asset($records->img)); ?>" width="50px;"> <?php echo e($records->name_en); ?>

                    
            </h1>
      <h3 class="col-md-12 text-center "   data-toggle="modal" data-target="#location">
          <i class="fas fa-map-marker-alt"></i>
        get location   
        <br> </h3>
 <div class="col-md-2 col-12">
                  <a href=""><img src="<?php echo e(asset($records->img2)); ?>" class="w-100"></a><br><br>
              
              
            </div><div class="col-md-10 col-12">
          <div id="carouselExampleIndicators" class="carousel slide  carousel-fade " data-ride="carousel">
          <ol class="carousel-indicators">
            <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
            <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
            
          </ol>
<div class="carousel-inner">
          <?php
          $i = 0;
          ?>
          <?php $__currentLoopData = $records->imgs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $one): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="carousel-item h  <?php if($i==0): ?> active <?php endif; ?>">
              <img class="d-block w-100 " src="<?php echo e(asset($one->img)); ?>" alt="<?php echo e($one->name_en); ?>">
          
      </div>
          <?php
          $i ++;
          ?>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
     
      </div>          <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="sr-only">Previous</span>
          </a>
          <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="sr-only">Next</span>
          </a>
        </div>
      
          </div>
            
       </div><br><br></div>
    <br>
              <div class="container border-main" >
          
        <div class="row  row5 ">
                 <h1 class="col-12"> Offers</h1>
             <?php $__currentLoopData = $offers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $one): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
             <div class=" col-6 col-md-4 col-lg-3 "  >
                          <br> <div class="card">
                 <h6 class="bg-main abs">ref:<?php echo e($one->id); ?></h6>
				 <a href="<?php echo e(route("product",$one->id)); ?>">
                     <img height="200" src="<?php echo e(asset($one->img)); ?>" class="card-img-top  " alt="..." > </a>
                                <div class="card-body">
                  <a href="<?php echo e(route("product",$one->id)); ?>" class="card-text "><?php echo e($one->name_en); ?></a>
             <p class="card-title" href=""><b>KWD<?php echo e($one->price); ?></b></p>
                              
                                </div>
                                    <div class="row mr-0">
                <a href="<?php echo e(route('add.cart',[$one->id,1])); ?>" class="btn btn-dark border col-9">add to cart</a> 
 <div class="btn btn-light border col-3 heart text-center"> <i class="fas fa-heart heart-none"></i><i class="far fa-heart  heart-block"></i></div>                          </div> </div></div>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              
            
						</div>
<br>
<?php echo e($offers->appends(request()->query())->links()); ?>

               <br><br></div>
 
    
    
      <div class="container  border-main" ><br>
          <div class="row  " >
               <div class="col-md-2 col-12 ">
              <h3>filtter <hr></h3>
                <a href="">subcategory</a><br><br>
                <a href="">subcategory</a><br><br>
                <a href="">subcategory</a><br><br>
                <a href="">subcategory</a><br><br>
            </div>
        <div class="col-md-10 col-12">
        <div class="row  " >
                  
               <br>
             <h1 class="col-12">more products </h1>
       
              <?php $__currentLoopData = $populars; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $one): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
             <div class=" col-6 col-md-4 col-lg-3 "  >
                          <br> <div class="card">
                 <h6 class="bg-main abs">ref:<?php echo e($one->id); ?></h6>
				 <a href="<?php echo e(route("product",$one->id)); ?>">
                     <img height="200" src="<?php echo e(asset($one->img)); ?>" class="card-img-top  " alt="..." > </a>
                                <div class="card-body">
                  <a href="<?php echo e(route("product",$one->id)); ?>" class="card-text "><?php echo e($one->name_en); ?></a>
             <p class="card-title" href=""><b>KWD<?php echo e($one->price); ?></b></p>
                              
                                </div>
                                    <div class="row mr-0">
                <a href="<?php echo e(route('add.cart',[$one->id,1])); ?>" class="btn btn-dark border col-9">add to cart</a> 
 <div class="btn btn-light border col-3 heart text-center"> <i class="fas fa-heart heart-none"></i><i class="far fa-heart  heart-block"></i></div>                          </div> </div></div>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              
            
						</div>
<br>
<?php echo e($populars->appends(request()->query())->links()); ?>

   <br><br>
          </div>
      <br><br>
            <div class="container">
            <div id="carouselExampleIndicators" class="carousel slide  carousel-fade" data-ride="carousel">
        
      <div class="carousel-inner">
      <div class="carousel-item  active">
                <img src="<?php echo e(asset('front/img/c.png')); ?>" class="w-100 ad">
          
      </div>
           <div class="carousel-item  ">
               <img src="<?php echo e(asset('front/img/s3.jpg')); ?>" class="w-100 ad">
          
      </div>
      <div class="carousel-item  ">
            <img src="<?php echo e(asset('front/img/s2.jpg')); ?>" class="w-100 ad">  
          
      </div>
      </div>
         
        </div>
   
       
    </div>  <br><br>   

  <!-- location -->
<div class="modal fade " id="location" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header">
          <img src="<?php echo e(asset($records->img)); ?>" width="100px">
        <button type="button" class="close " data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
             <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d1781246.1045858918!2d48.657151504561746!3d29.311784251648273!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3fc5363fbeea51a1%3A0x74726bcd92d8edd2!2z2KfZhNmD2YjZitiq4oCO!5e0!3m2!1sar!2seg!4v1589595972634!5m2!1sar!2seg" class="col-12" height="450" frameborder="0" style="border:0;" allowfullscreen="" aria-hidden="false" tabindex="0"></iframe>
       
      </div>
    
    </div>
  </div>
</div>
   <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.front2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/bluezo11/kocart.easyshop-qa.com/resources/views/front/vendor.blade.php ENDPATH**/ ?>