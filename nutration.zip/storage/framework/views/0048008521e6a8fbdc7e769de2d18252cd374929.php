 
<?php $__env->startSection('title', $result->name_en); ?>
<?php $__env->startSection('content'); ?>
 <?php
$photos = $result->images;
 ?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
 
<script>
function add_fav(pro_id)
{ 
    
alert(' Please login first...');

//id = <?=(\Auth::user() !== null)? Auth::user()->id :'0'?> ;
// alert(id);
if(id != 0){
$.ajax({url:"<?php echo e(url('/en/ajaxFavorite')); ?>/product_id/" + pro_id  ,type: "GET",
success:function(data){
successmessage = data;
//$("._fav_id"+ pro_id).html(successmessage);
}

}); 

} else {
alert(' Please login first...');
}

}
</script>





 

<header class="container border-main">
<ul class="nav product" >
<li class="nav-item  ">  <a class="nav-link  "  href="<?php echo e(url('/')); ?>" > home </a>	
</li>
<li class="nav-item  ">  <a class="nav-link  "  href="" >  <i class="fas fa-arrow-right " style="font-size: 20px"></i></a>	
</li>
<li class="nav-item ">  <a class="nav-link   "   > <?php echo e($result->name_en); ?>  </a>
</li>    
</ul>
</header>
<!--- --->
<div class="container "><br><br>
<div class="row">
<?php if(session('success')): ?>

<div class="alert alert-success text-center" style="width: 100%; margin-top: 1%;display:none">
<?php echo e(session('success')); ?>

</div>

<?php endif; ?>
<div id="message" class="alert  text-center" style="width:60%;margin:0 auto;margin-bottom: 2%;">
        
    </div>
	
<div class="col-md-6 col-12 pad-0">
<div id="carouselExampleIndicators" class="carousel slide carousel1 carousel-fade" data-ride="carousel" >

<div class="carousel-inner">
<?php $__currentLoopData = $photos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i=>$photo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="carousel-item <?php echo e(($i==0)?'active':''); ?>">
<a href="<?php echo e(asset($photo->img)); ?>"> <img height="330" src="<?php echo e(asset($photo->img)); ?>" class="d-block w-100 h-img" alt="..." data-toggle="modal" data-target="#staticBackdrop"></a>
</div>
 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
<span class="carousel-control-prev-icon" aria-hidden="true"></span>
<span class="sr-only">Previous</span>
</a>
<a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
<span class="carousel-control-next-icon" aria-hidden="true"></span>
<span class="sr-only">Next</span>
</a>
<a href="<?php echo e(asset($photo->img)); ?>" class="abs"><i class="fas fa-expand" style="font-size: 30px;"></i></a>
</div>

<ol class=" position-relative navbar" style="width:100%;margin-top:10x;z-index: 10;list-style: none;justify-content:space-between" >
<br>
<?php $__currentLoopData = $photos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i=>$photo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<li data-target="#carouselExampleIndicators" data-slide-to="<?php echo e($i); ?>" class="<?php echo e(($i==0)?'active':''); ?>"  >
  <img src="<?php echo e(asset($photo->img)); ?>"  style="height: 90px;width: 90px;margin: 10px">
	   </li><br>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ol>          
</div>
<div class="col-md-6 col-12">
<h2 ><?php echo e($result->name_en); ?> </h2>
<h5><?php echo e($result->price); ?> KWD </h5>
<br><br>
 

 

<div class=" row ">  
 <form method="post" id="cart<?php echo e($result->id); ?>" name="cart_form" class="col-md-6 col-12" action="<?php echo e(route('home')); ?>">
<?php echo csrf_field(); ?>
 <h6 >&nbsp;&nbsp;&nbsp; Quantity</h6>
<div class=" product-count col-12">
<a onClick="update_cart(<?php echo e($result->id); ?>,<?php echo e($result->price); ?>,'minus',<?php echo e($result->id); ?>);" rel="nofollow" data-id="<?php echo e($result->id); ?>" class="btn btn-default btn-minus " href="#" title="Subtract">&ndash;</a>
<input type="text" name="qut" id="qty_<?php echo e($result->id); ?>" value="<?=(isset((\Session::get('cart'))[$result->id]['quantity']))?(\Session::get('cart'))[$result->id]['quantity'] : 1 ?>" size="2" class="cart_quantity_input form-control grey count quantity" min=1 style="" />
<a onClick="update_cart(<?php echo e($result->id); ?>,<?php echo e($result->price); ?>,'plus',<?php echo e($result->id); ?>);"  rel="nofollow" class="btn btn-default btn-plus " href="#" title="Add">+</a>
</div>

<div class="col-md-8 col-12">

<div class="col-9" style="height: 38px; padding: 0;">

<input type="hidden" name="id" value="<?php echo e($result->id); ?>" />
<button id="send<?php echo e($result->id); ?>" type="submit" class="btn btn-dark border col-12">Add to cart</button>	<br><br>
</div>

</div>
</form>
<div class="col-md-6 col-12">
<div class="btn btn-light ">
<div class="row">
<div class="col-9">Add to wishlist </div> 
 
 
<div id="" class=" btn btn-light border col-3 heart text-center"> 
<!--<i class="fas fa-heart heart-none"></i>-->
<i class="far fa-heart  " ></i>
</div>   
 
</div>	
</div>
</div>
   <br><br> 
   </div>
   <br>
<h5> Share on
<a href="https://www.facebook.com/sharer/sharer.php?u=https://al3semaa.com/<?php echo $result->name_en ?>" target="_blank"  class="mr-10"><i class="fab fa-facebook-f"  style="font-size: 25px;"></i></a> 
<a  href="http://twitter.com/share?text=<?php echo $result->name_en ?>&url=https://al3semaa.com/product/<?php echo $result->id ?>" class="mr-10"> <i class="fab fa-twitter" style="font-size: 25px;"></i> </a>
<a  href="whatsapp://send?text=https://al3semaa.com/product<?php echo $result->id ?>" data-action="share/whatsapp/share" class="mr-10"> <i class="fab fa-whatsapp" style="font-size: 25px;"></i> </a> </h5>
  
<h5>Description</h5>

<p><?php echo e($result->description_en); ?> </p>
<?php if($result->color !='' or $result->color !=0): ?>
<?php
$color = \App\Color::where('id', $result->color)->first();
?>
<?php if($color != null): ?>
<p>Colour: <?php echo e($color->name); ?></p>
<?php endif; ?>
<?php endif; ?>



<?php if($result->qut > 0): ?>
<h5>status :  <span class="text-danger"><?php echo e($result->qut); ?> in stock 
<?php endif; ?>
</span></h5>

</div>
</div></div>

<!-----start glasses --->
<?php 
$similar_products=[];
?>
<?php if(count($similar_products) > 0 ): ?> 
<div class="container-fluid ">
<div class="container"><br>
<div class="row ">
<div class="col-12 border-bottom pad-0">
<h3 class="float-left">You may also like</h3>
<div class="float-right">
<a href="" class="main-color">view all  </a>
<div class="float-right" style="width: 50px;position: relative;margin: 10px;">              
<a class="carousel-control-prev left"  href="#carousel-glass" role="button" data-slide="prev" style="color:#000!important">
<i class="fas fa-chevron-left"></i>
</a>
<a class="carousel-control-next right" href="#carousel-glass" role="button" data-slide="next">
<i class="fas fa-chevron-right" style="color:#000!important"></i>
 </a></div></div>
<div style="clear: both"></div>
</div>
<br><br>
<div id="carousel-glass" class="carousel slide multi col-12" data-ride="carousel"  >
<div class="carousel-inner  row w-100 mx-auto" role="listbox">
<?php $__currentLoopData = $similar_products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i=>$similar_product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="carousel-item col-12 col-sm-6 col-md-4 col-lg-3 <?php echo e(($i==0)?'active':''); ?>"  >
<br> 
<div class="card">
<h6 class="bg-main abs">ref:<?php echo e($similar_product->ref_id); ?></h6>
<a href="<?php echo e(url('/en/product/'.$similar_product->slug)); ?>">
<img src="<?php echo e(url('/public/uploads/')); ?>/<?php echo e($similar_product->thumbnail); ?>" class="card-img-top  " alt="..." > </a>
<div class="card-body">
<a href="<?php echo e(url('/en/product/'.$similar_product->slug)); ?>" class="card-text "><?php echo e($similar_product->name_en); ?></a>
<p class="card-title" href=""><b><?php echo e(Site::get_price_with_currency(\Session::get('country') , $similar_product->price)); ?></b></p>

</div>
<div class="row mr-0">
<?php if(session('cart')): ?> 
<?php if(array_search($similar_product->id, array_column(session('cart'), 'id')) !== false): ?>  

<a class="btn  border col-9 added_to_cart" >Added to Cart</a>	

<?php else: ?>
 	
<div class="col-9" style="height: 38px; padding: 0;">
<form method="post" id="cart<?php echo e($similar_product->id); ?>" name="cart_form" class="" action="<?php echo e(route('home')); ?>">
<?php echo csrf_field(); ?>
<input type="hidden" name="id" value="<?php echo e($similar_product->id); ?>" />
<button id="send<?php echo e($similar_product->id); ?>" type="submit" class="btn btn-dark border col-12">Add to cart</button>	<br><br>

</form>
</div>
<?php endif; ?>
<?php else: ?>
<div class="col-9" style="height: 38px; padding: 0;">
<form method="post" id="cart<?php echo e($similar_product->id); ?>" name="cart_form" class="" action="<?php echo e(route('home')); ?>">
<?php echo csrf_field(); ?>
<input type="hidden" name="id" value="<?php echo e($similar_product->id); ?>" />
<button id="send<?php echo e($similar_product->id); ?>" type="submit" class="btn btn-dark border col-12">Add to cart</button>	<br><br>

</form>
</div>
<?php endif; ?>
 
<?php
if(\Auth::user()){
$user=\Auth::user();
$fav_pro = \App\ProductsFav::where('user_id', $user->id)->where('product_id', $similar_product->id)->first();
if($fav_pro == null){ 
?>
<div id="" class="_fav_id<?php echo e($similar_product->id); ?> btn btn-light border col-3 heart text-center"> 
<!--<i class="fas fa-heart heart-none"></i>-->
<i class="far fa-heart  heart-block" onClick="add_fav(<?php echo e($similar_product->id); ?>);"></i>
</div>

<?php
}else{ 
?>
<div id="" class="_fav_id<?php echo e($similar_product->id); ?> btn btn-light border col-3 heart text-center">  
<i class="fas fa-heart" style="color:red" onClick="add_fav(<?php echo e($similar_product->id); ?>);"></i>
</div>
 <?php
}

}else{ 
?>
<div id="" class="_fav_id<?php echo e($similar_product->id); ?> btn btn-light border col-3 heart text-center"> 
<!--<i class="fas fa-heart heart-none"></i>-->
<i class="far fa-heart  heart-block" onClick="add_fav(<?php echo e($similar_product->id); ?>);"></i>
</div><?php
}
?>
                      
</div>
 </div> 
</div>
 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>


</div></div><br><br></div>

</div>
<?php endif; ?>
<script type="text/javascript">
 
 function get_total_price(price)
{
$.ajax({
url: "<?php echo e(url('/en/total_price')); ?>",
method: "get",
data: {
_token: '<?php echo e(csrf_token()); ?>',
price: price

},
success: function (response) {
$("#my_total").val(response + "KWD");

 //$("#divid").load(" #divid");
	//return response;
}

});        
 
}
 

function update_cart(elem,pro_price,factor,item_id)
{

 var ele = document.getElementById('qty_'+elem).value;
//alert(ele);
if(factor == 'minus'){
//	 alert('marwa');

	qq = (Number($("#qty_"+ elem).val()) - 1 > 1)?Number($("#qty_"+ elem).val()) - 1:1;
$.ajax({
url: "<?php echo e(url('/update_cart')); ?>/"+item_id+"/"+qq,
method: "get",



success: function (response) {
$(".my_total").html(response.data + "KWD");
//alert(response.data);
},error: function (response,u) {
//$(".my_total").html(response + "KWD");
	alert(u);

}

}); 
}else if(factor == 'plus'){
qq = Number($("#qty_"+ elem).val()) + 1 ;
	 $.ajax({
url: "<?php echo e(url('/update_cart')); ?>/"+item_id+"/"+qq,
method: "get",

success: function (response) {
$(".my_total").html(response.data + "KWD");
	//alert(response.data);

},error: function (response,u) {
//$(".my_total").html(response + "KWD");
	alert(u);

}

}); 
}else{}         
//calc_total_cost(elem,pro_price,factor);
$(".x_sub_total_price_"+elem).html(pro_price * qq + " KWD");
 //$("#total").load(location.href +"#total");

 //$("#total").load("#total > *");
}
 
 
 function calc_total_cost(elem,pro_price,factor)
{
	 
pro_price = pro_price;
if(factor == 'minus'){
qty = document.getElementById('qty_'+elem).value;
qty = (Number(qty) - 1 > 0)?Number(qty) - 1:1;
}else if(factor == 'plus'){
qty = document.getElementById('qty_'+elem).value;
qty = Number(qty) + 1;
}else{
	qty = 1;
}

/*
$.ajax({
url: "<?php echo e(url('/en/total_cost/qty')); ?>/" + qty+'/pro_price/'+pro_price+'/factor/'+factor , 
type: "POST",
data: {
_token: '<?php echo e(csrf_token()); ?>',
id: elem.value,
}, success: function (result) {
	//alert(result);
$(".x_sub_total_price_"+elem).html(result + "KWD");
get_total_price(result);
 
}});
*/
}
 
 
  
 
</script>
 <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.front2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/bluezo11/kocart.easyshop-qa.com/resources/views/front/product.blade.php ENDPATH**/ ?>