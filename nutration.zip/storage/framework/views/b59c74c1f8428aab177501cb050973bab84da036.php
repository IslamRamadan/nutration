
<?php $__env->startSection('title'); ?>
<?php echo app('translator')->get("تعديل منتج"); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('mo'); ?>
    



     <?php $__env->startSection('ti'); ?>
عرض وتعديل :   <?php echo e(App\Models\Item::find($category->id)->name??""); ?>

     <?php $__env->stopSection(); ?>
     <?php $cat = app('App\Models\Category'); ?>
     <?php $subcat = app('App\Models\SubCategory'); ?>
     <?php $subcat2 = app('App\Models\SubSubCategory'); ?>

     <?php $brand = app('App\Models\Brand'); ?>
     <?php $slider = app('App\Models\Slider'); ?>

        <div class="box box-primary">




            <div class="box-header">

            </div><!-- end of box header -->
            <div class="box-body">

               <?php echo $__env->make('partials._errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 


                  <?php echo Form::model($category, ['route' => ['items.update',$category->id],
                  "method"=>"PUT",'enctype' => 'multipart/form-data'

                  ]); ?>

                    <?php echo e(csrf_field()); ?>


                     
                    <div class="row">
                        <div class="col-md-4 form-group">

                        <label><?php echo app('translator')->get(' التاجر'); ?></label>
                        <?php echo Form::select('category_id',$cat->pluck('name','id')->toArray(),null,[
                            'class' => 'form-control form-control-lg' . ($errors->has('category_id') ? ' is-invalid' : null),
                             'id' => 'category',
                             'placeholder' => 'اختر  التاجر',
                             "required"=>"required"
                           

                         ]); ?>


                    </div>

                    <div class="col-md-4 form-group">
                                <label><?php echo app('translator')->get('القسم '); ?></label>
                                <?php echo Form::select('subCategory_id',$subcat->pluck('name','id')->toArray(),null,[
                                           'class' => 'form-control form-control-lg' . ($errors->has('subCategory_id') ? ' is-invalid' : null),
                                            'id' => 'records',
                                            'placeholder' => '',
                                            "required"=>"required"
                                           
                                        ]); ?>

        
                            </div>


                            <div class="col-md-4 form-group" >
                                <label><?php echo app('translator')->get('القسم الفرعي'); ?></label>
                                <?php echo Form::select('subSubCategory_id',$subcat2->pluck('name','id')->toArray(),null,[
                                           'class' => 'form-control form-control-lg' . ($errors->has('subSubCategory_id') ? ' is-invalid' : null),
                                            'id' => 'records2',
                                            'placeholder' => '',
                                            "required"=>"required"
                                           
                                        ]); ?>

        
                            </div>
                        </div>
                       

                            <div class="row">
                           
                            <div class="col-md-3 form-group">                 
                                           <label><?php echo app('translator')->get('اسم المنتج'); ?></label>
                            <input type="text" name="name" class="form-control" value="<?php echo e($category->name); ?>" required>
                        </div>
								
								  <div class="col-md-3 form-group">                 
                                           <label><?php echo app('translator')->get('الاسم بالانجليزية'); ?></label>
                            <input type="text" name="name_en" class="form-control" value="<?php echo e($category->name_en); ?>" required>
                        </div>

                        <div class="col-md-2 form-group">                         
                               <label><?php echo app('translator')->get('السعر'); ?></label>
                            <input type="text" name="price" class="form-control" value="<?php echo e($category->price); ?>" required>
                        </div>

                        <div class="col-md-2 form-group">                          
                              <label><?php echo app('translator')->get('سعر الخصم '); ?></label>
                            <input type="text" name="over_price" class="form-control" value="<?php echo e($category->over_price); ?>" required>
                        </div>

                        <div class="col-md-5 form-group">
                            <label><?php echo app('translator')->get('وصف المنتج'); ?></label>
                            <textarea rows="3" name="description" class="form-control" required ><?php echo e($category->description); ?></textarea>
                        </div>
								
								 <div class="col-md-5 form-group">
                            <label><?php echo app('translator')->get('الوصف بالانجليزية'); ?></label>
                            <textarea rows="3" name="description_en" class="form-control" required ><?php echo e($category->description_en); ?></textarea>
                        </div>
                    </div>
				
				
                  
 

                    <div class="row">
                        <div class="form-group col-md-4">
                            <label><?php echo app('translator')->get('صورة  المنتج في القسم '); ?></label>
                            <input type="file" name="photo" class="form-control" value="" >
                        </div>
                        <div class="form-group col-md-4">
                            <label><?php echo app('translator')->get('الحالة'); ?></label>
                            <select style="width:100%"  name="activity" class="form-control " >
                              <option <?php if($category->activity == 1 ): ?>  <?php echo e("selected"); ?> <?php endif; ?> value="1">مفعلة</option>
                              <option <?php if($category->activity == 0 ): ?>  <?php echo e("selected"); ?> <?php endif; ?> value="0">معطلة</option>
                              
                          </select>
                        </div>

                      
  
                        <div class="form-group col-md-4">
                            <label><?php echo app('translator')->get('ترتيب الظهور'); ?>  (اختياري)</label>
                            <input value="<?php echo e($category->num); ?>" type="number" name="num" class="form-control" >
                        </div>

                    </div>

                    <div class="row">

                        <div class="col-md-6 form-group" >
                            <label><?php echo app('translator')->get('الماركة'); ?> </label>
                            <?php echo Form::select('brand_id',$brand->pluck('text','id')->toArray(),null,[
                                'class' => 'form-control form-control-lg' . ($errors->has('category_id') ? ' is-invalid' : null),
                                 'id' => '',
                                 'placeholder' => 'لا يوجد ماركة',
                               
    
                             ]); ?>

    
                        </div>

                        <div class="col-md-6 form-group" >
                            <label><?php echo app('translator')->get('سليدر'); ?> </label>
                            <?php echo Form::select('tags',$slider->pluck('text','id')->toArray(),null,[
                                'class' => 'form-control form-control-lg' . ($errors->has('category_id') ? ' is-invalid' : null),
                                 'id' => '',
                                 'placeholder' => 'لا يتبع اي سليدر',
                               
    
                             ]); ?>

    
                        </div>

                    </div>


                 <div class="row">

                    <div class="form-group col-md-4">
                        <label><?php echo app('translator')->get('يتبع وصل حديثا'); ?></label>
                        <select style="width:100%"  name="new" class="form-control " >
                        
                        <option <?php if($category->new == 0 ): ?>  <?php echo e("selected"); ?> <?php endif; ?> value="0">لا</option>
                        <option <?php if($category->new == 1 ): ?>  <?php echo e("selected"); ?> <?php endif; ?>  value="1">نعم</option>
                        
                    </select>
                    </div>



                    <div class="form-group col-md-4">
                        <label><?php echo app('translator')->get('يتبع  الاكثر مبيعا'); ?></label>
                        <select style="width:100%"  name="popular" class="form-control " >
                        
                        <option  <?php if($category->popular == 0 ): ?>  <?php echo e("selected"); ?> <?php endif; ?> value="0">لا</option>
                        <option  <?php if($category->popular == 1 ): ?>  <?php echo e("selected"); ?> <?php endif; ?>  value="1">نعم</option>
                        
                    </select>
                    </div>



                    <div class="form-group col-md-4">
                        <label><?php echo app('translator')->get('يتبع   عروض الخصم'); ?></label>
                        <select style="width:100%"  name="over" class="form-control " >
                        
                        <option  <?php if($category->over == 0 ): ?>  <?php echo e("selected"); ?> <?php endif; ?>  value="0">لا</option>
                        <option  <?php if($category->over == 1 ): ?>  <?php echo e("selected"); ?> <?php endif; ?>   value="1">نعم</option>
                         
                    </select>
                    </div>
					  <div class="form-group col-md-4">
                        <label><?php echo app('translator')->get('نوع المنتج '); ?></label>
                        <select style="width:100%"  name="type" class="form-control " >
                        
                        <option  <?php if($category->type == 1): ?>  <?php echo e("selected"); ?> <?php endif; ?> value="1">له كمية ولون ومقاس</option>
                        <option <?php if($category->type == 2): ?>  <?php echo e("selected"); ?> <?php endif; ?>  value="2">له كمية فقط</option>
                        
                    </select>
                    </div>
					 
					   <div class="col-md-3 form-group">                 
                                           <label><?php echo app('translator')->get(' الكمية  ( منتجات لها كمية فقط)'); ?></label>
                            <input type="number" name="qut" class="form-control" value="<?php echo e($category->qut); ?>" required>
                        </div>
                </div>
                    <div class="form-group">
                        <button type="submit" class="btn btn-primary"><i class="fa fa-plus"></i> <?php echo app('translator')->get('تعديل'); ?></button>
                    </div>

                    <?php echo Form::close(); ?>


            </div><!-- end of box body -->

        </div><!-- end of box -->








        <?php $__env->startPush('scripts'); ?>
        <script>
          
            $("#category").change(function (e) {
                e.preventDefault();
                // get gov
                // send ajax
                // append records
                $("#records").empty();
                $("#records2").empty();
          
                var category = $("#category").val();
                 
                if (category)
                {
                    $.ajax({
                        url : '<?php echo e(url('api/v1/subcats')); ?>',
                        type: 'post',
                        data: {_token:"<?php echo e(csrf_token()); ?>",category_id:category},
                        success: function (data) {
        
                            if (data.state == 1)
                            {
        
                                $("#records").empty();
                                $("#records").append('<option value="">اختر قسم </option>');
                                $.each(data.data, function (index, city) {
                                    $("#records").append('<option value="'+city.id+'">'+city.name+'</option>');
                                });
                            }
                        },
                        error: function (jqXhr, textStatus, errorMessage) { // error callback
                            alert(jqXhr);
                        }
                    });
                }else{
                  //  $("#records").empty();
                    $("#records").append('<option value="">اختر قسم </option>');
                }
            });
            ///////////////////////////////////////////////sub sub cats 

            $("#records").change(function (e) {
                e.preventDefault();
                // get gov
                // send ajax
                // append records
                $("#records2").empty();

          
                var category = $("#records").val();
                 
                if (category)
                {
                    $.ajax({
                        url : '<?php echo e(url('api/v1/subcats2')); ?>',
                        type: 'post',
                        data: {_token:"<?php echo e(csrf_token()); ?>",category_id:category},
                        success: function (data) {
        
                            if (data.state == 1)
                            {
        
                                $("#records2").empty();
                                $("#records2").append('<option value="">اختر القسم الفرعي</option>');
                                $.each(data.data, function (index, city) {
                                    $("#records2").append('<option value="'+city.id+'">'+city.name+'</option>');
                                });
                            }
                        },
                        error: function (jqXhr, textStatus, errorMessage) { // error callback
                            alert(jqXhr);
                        }
                    });
                }else{
                  //  $("#records").empty();
                    $("#records2").append('<option value="">  اختر القسم الفرعي</option>');
                }
            });
        </script>
        <?php $__env->stopPush(); ?>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard.app2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/bluezo11/kocart.easyshop-qa.com/resources/views//dashboard/items/edit.blade.php ENDPATH**/ ?>