
<?php $__env->startSection('title'); ?>
<?php echo app('translator')->get("site.how_work"); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('mo'); ?>
    



     <?php $__env->startSection('ti'); ?>
     <?php echo app('translator')->get("site.how_work"); ?>
     <?php $__env->stopSection(); ?>

        <div class="box box-primary">




            <div class="box-header">

            </div><!-- end of box header -->
            <div class="box-body">

               <?php echo $__env->make('partials._errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 


                  <?php echo Form::model("", ['route' => ['how_works.store'],
                  "method"=>"post",'enctype' => 'multipart/form-data'

                  ]); ?>

                    <?php echo e(csrf_field()); ?>


                    <div class="form-group">
                        <div class="form-group">
                            <label><?php echo app('translator')->get('site.icon'); ?></label>
                            <span> <?php echo app('translator')->get('site.choose_icon'); ?></span>
                            <a href="https://fontawesome.com/v5.15/icons" target="_blank"><?php echo app('translator')->get('site.here'); ?></a>
                            </label>
                            <input type="text" name="icon" class="form-control" value="far fa-user">
                        </div>


                        <label><?php echo app('translator')->get('site.title_en'); ?></label>
                        <input type="text" name="title_en" class="form-control" value="">
                    </div>


                    <div class="form-group">
                        <label><?php echo app('translator')->get('site.title_ar'); ?></label>
                        <input type="text" name="title_ar" class="form-control" value="">
                    </div>

                

                      

                        <div class="form-group">
                            <label><?php echo app('translator')->get('site.content_en'); ?></label>
                            <input type="text" name="content_en" class="form-control" value="">

                        </div>

                       
                        <div class="form-group">
                            <label><?php echo app('translator')->get('site.content_ar'); ?></label>
                            <input type="text" name="content_ar" class="form-control" value="">
                        </div>
                <input type="hidden" name="type" class="form-control" value="2">


                    <div class="form-group">
                        <button type="submit" class="btn btn-primary"><i class="fa fa-plus"></i> <?php echo app('translator')->get('site.add'); ?></button>
                    </div>

                    <?php echo Form::close(); ?>


            </div><!-- end of box body -->

        </div><!-- end of box -->












<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard.app2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\prestige\untitled folder\resources\views//dashboard/how_works/create.blade.php ENDPATH**/ ?>