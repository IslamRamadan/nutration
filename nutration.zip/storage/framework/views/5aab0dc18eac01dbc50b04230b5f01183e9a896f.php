<?php $__env->startSection('title'); ?>


<?php echo app('translator')->get('site.post'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <!-----start carousel --->

<div  class=" relative1 " >
    <div class="abs w-100">
        <h4 class="custom-h4"><?php echo app('translator')->get('site.post'); ?></h4>
        <h1><?php echo $post['title_'.app()->getLocale()]; ?></h1>

    </div>
</div>

<section class="news section">
    <div class="container">
        <div class="row mt-30">
            <div class="col-12 mx-auto">
                <div class="block">
                    <!-- Article -->
                    <article class="blog-post single">
                        <div class="post-thumb">
                            <img src="<?php echo e(url($post->img)); ?>" alt="post-image" class="img-fluid" style="width: 100%;">
                        </div>
                        <div class="post-content">
                            <div class="date">
                                <h4><?php echo e($post->created_at->format('d')); ?><span><?php echo e($post->created_at->format('M')); ?></span></h4>
                            </div>
                            <div class="post-title">
                                <h3><?php echo $post['title_'.app()->getLocale()]; ?></h3>
                            </div>

                            <div class="post-details">
                                <?php echo $post['content_'.app()->getLocale()]; ?>

                            </div>



<div class="container-fluid  p-5">
    <div class="row justify-content-center">
        <?php $__currentLoopData = $post_img; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <div class="col-lg-4 col-md-6 col-12 mb-3"  >
            <div class="" style="background-color: rgb(35, 159, 168)">
            
            <img src="<?php echo e(url($item->img)); ?>" class="w-100 cust-hght" alt="">
        </div>

        </div>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


        

        </div>

    </div>
</div>

                        </div>


                    </article>
                    <!-- Comment Section -->

                </div>
            </div>

        </div>
    </div>
</section>




<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.front.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\monaleza\Documents\nutration\resources\views/front/single_post.blade.php ENDPATH**/ ?>