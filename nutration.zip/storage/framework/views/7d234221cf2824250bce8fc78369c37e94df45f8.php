<?php $__env->startSection('title'); ?>
    <?php echo app('translator')->get('site.home'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div id="carouselExampleIndicators" class="carousel slide relative" data-ride="carousel">
        <ol class="carousel-indicators">
            <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
            <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
            <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
        </ol>
        <div class="carousel-inner">
            <?php
                $i = 0;
            ?>
            <?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $one): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="carousel-item  <?php if($i == 0): ?> active <?php endif; ?> ">
                    <img class=" w-100  " src="<?php echo e(asset($one->img)); ?>" alt="1 slide">

                </div>
                <?php
                    $i++;
                ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


        </div>
        <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
            <span class="carousel-control-prev-icon " aria-hidden="true"></span>
            <span class="sr-only">Previous</span>
        </a>
        <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="sr-only">Next</span>
        </a>
    </div>
    <!--- end head --->
    <!--- -->

    <div class="container text-center center-p">
        <br>

        <h4><?php echo $my_section['title2_'.app()->getLocale()]; ?>


        </h4>
        <h1><?php echo $my_section['content2_'.app()->getLocale()]; ?>

        </h1><br>

    </div>
    <div  class="container-fluid" >

        <div class="row">
            <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <div class="col-lg-3 col-md-6 col-sm-6 hvr">
                <div class="" style="position: relative">
                    <img src="<?php echo e(url('/storage/'.$item->img)); ?>" alt="" class="w-100">
                    <div class="img-div" >
                        <h5><?php echo $item['title_'.app()->getLocale()]; ?></h5>
                        <h6><?php echo $item['name_'.app()->getLocale()]; ?></h6>
                          <?php
                                $pieces = explode(" ", $item['content_'.app()->getLocale()]);
                                $content = implode(" ", array_splice($pieces, 0, 10));
                            ?>
                        <p><?php echo $content; ?></p>
                        <a href="<?php echo e(route('service.show',$item->id)); ?>" class="hide-link">
                            <p><?php echo app('translator')->get('site.view_more'); ?> &nbsp;  <?php if(Lang::locale()=='ar'): ?>
                                <i class="fas fa-arrow-right text-light fa-flip-horizontal"></i>
                                <?php else: ?>
                                <i class="fas fa-arrow-right text-light "></i>
                                <?php endif; ?>
                            </p>
                        </a>


                        </div>

                </div>

            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            


        </div>
    </div>
    <div class="container text-center center-p">
        <br>

        <h4 class="mb-4"><?php echo $my_section['title1_'.app()->getLocale()]; ?></h4>
        <h1><?php echo $my_section['name1_'.app()->getLocale()]; ?>

        </h1>
        <p><?php echo $my_section['content1_'.app()->getLocale()]; ?></p>
        <br>

    </div>

    <div  class="container-fluid" >

        <div class="row">
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <div class="col-lg-6 col-md-6 col-sm-12 mb-3">
                <a href="<?php echo e(route('category.show',$item->id)); ?>">
                <div class="" style="position: relative">
                    <img src="<?php echo e(url('/storage/'.$item->img)); ?>" alt="" class="w-100 bright-50">
                    <div class="img-div1" >
                        <h2><?php echo $item['name_'.app()->getLocale()]; ?></h2>



                        </div>
                    <div class="img-div2" >
                        <h5><?php echo $item['title_'.app()->getLocale()]; ?></h5>

                        </div>

                </div>
               </a>

            </div>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>







        </div>
    </div>

    <div class="container text-center center-p1">

<div class="component">
    <blockquote class="callout quote EN">
       <h2> <?php echo $my_section['qoute1_'.app()->getLocale()]; ?>

       </h2>
       </blockquote>
    </div>
    </div>



            <div  class="container-fluid" >

                <div class="row">
                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <div class="col-lg-6 col-md-6 col-sm-12 ">
                        <div class="" style="position: relative">
                            <img src="<?php echo e(url('storage/'.$item->img)); ?>" alt="" class="w-100">
                            <div class="text-center">
                                <a href="<?php echo e(route('product.show',$item->id)); ?>" class="btn btn-primary m-5"><?php echo app('translator')->get('site.view_more'); ?> &nbsp; &nbsp;
                                    <?php if(Lang::locale()=='ar'): ?>
                                    <i class="fas fa-arrow-right text-light fa-flip-horizontal"></i>
                                    <?php else: ?>
                                    <i class="fas fa-arrow-right text-light "></i>
                                    <?php endif; ?>

                                </a>
                                     </div>

                        </div>

                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    




                </div>
            </div>

            <div class="container text-center center-p ">
                <br>
                <h4 class="mb-4"><?php echo $my_section['title3_'.app()->getLocale()]; ?></h4>
                <h1><?php echo $my_section['name3_'.app()->getLocale()]; ?></h1>
                <p><?php echo $my_section['content3_'.app()->getLocale()]; ?></p>
                
            </div>

            <div class="container-fluid  ">
                <br>

                <h2 class="text-center"><?php echo app('translator')->get('site.dry_i4'); ?><hr>
                </h2>
                <br>
                <div class="row align-items-center">
                    <?php $__currentLoopData = App\Models\ClientImg::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-lg-2 col-md-3 col-4">
                        <img src="<?php echo e(url($item->img)); ?>" alt="" style="
                            width: -webkit-fill-available;
                        ">
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>

            </div>

            <div class="container text-center center-p1">

                <div class="component">
                    <blockquote class="callout quote EN">
                       <h2><?php echo $my_section['qoute2_'.app()->getLocale()]; ?>

                       </h2>
                       </blockquote>
                    </div>
                    </div>



    <div class="container-fluid">
        <br>

        <h4 class="custom-h4" ><?php echo $my_section['last_title_'.app()->getLocale()]; ?>

        </h4>

        <div class="row">


            <div class="col-md-3 col-12 align-self-center">
                <h3 class="mb-5"><?php echo $my_section['last_name_'.app()->getLocale()]; ?></h3>
                <p><?php echo $my_section['last_content_'.app()->getLocale()]; ?></p>
            </div>
            <div class="col-md-9 col-12">
                <img src="<?php echo e(url('storage/'.$my_section->img)); ?>" alt="" class="w-100">
            </div>

        </div>
    </div>

    <div class="container-fluid contact-container">
        <div class="row justify-content-between">
            <div class="col-lg-4 col-md-6 col-12 mt-sm-3">
                <h1><?php echo $my_section['contact_name_'.app()->getLocale()]; ?></h1>

                <br>
                <br>
                <p><?php echo $my_section['contact_content_'.app()->getLocale()]; ?></p>
            </div>
            <div class="col-lg-4 col-md-6 col-12 cus-form">
                <?php echo Form::model("", ['route' => ['contacts.store'],
                "method"=>"post"

                ]); ?>

              <?php echo e(csrf_field()); ?>

                <div class="form">
                    <div class="form-group row">
                        <div class="col-sm-12">
                            <input type="text"  class="form-control" name="name"   placeholder="<?php echo app('translator')->get('site.name'); ?>" value="<?php echo e(old('name')); ?>">
                        </div>
                    </div>
                    <br>
                    <div class="form-group row">
                        <div class="col-sm-12">
                            <input type="text"  class="form-control" name="phone"   placeholder="<?php echo app('translator')->get('site.phone'); ?>" value="<?php echo e(old('phone')); ?>">
                        </div>
                    </div>
                    <br>
                    <div class="form-group row">
                        </label>
                        <div class="col-sm-12">
                            <input type="text"  class="form-control" name="email"   placeholder="<?php echo app('translator')->get('site.email'); ?>" value="<?php echo e(old('email')); ?>">
                        </div>
                    </div>
                    <br>
                    <div class="form-group row">
                        <div class="col-sm-12">
                            <textarea  rows="3" name="comment" placeholder="Write message here..."  class="form-control"  ><?php echo e(old('comment')); ?></textarea>
                        </div>
                    </div>
                    <br>
                    <div class="form-group row">
                        <div class="col-sm-12 text-center">
                            <button type="submit" class="btn btn-primary " ><?php echo app('translator')->get('site.submit'); ?></button>
                        </div>
                    </div>

                </div>
                <?php echo Form::close(); ?>


            </div>

        </div>
    </div>



<?php $__env->stopSection(); ?>


<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>








































<script>
    // Get the modal
    var modal = document.getElementById("myModal");

    // Get the image and insert it inside the modal - use its "alt" text as a caption
    var img = document.getElementById("myImg");
    var modalImg = document.getElementById("img01");
    var captionText = document.getElementById("caption");
    img.onclick = function() {
        modal.style.display = "block";
        modalImg.src = this.src;
        captionText.innerHTML = this.alt;
    }

    // Get the <span> element that closes the modal
    var span = document.getElementsByClassName("close")[0];

    // When the user clicks on <span> (x), close the modal
    span.onclick = function() {
        modal.style.display = "none";
    }
</script>

<?php echo $__env->make('layouts.front.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\monaleza\Documents\GitHub\Turk\resources\views/front/index.blade.php ENDPATH**/ ?>