
<?php $__env->startSection('title'); ?>
<?php echo app('translator')->get('site.home'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div id="carouselExampleIndicators" class="carousel slide relative" data-ride="carousel">
        <ol class="carousel-indicators">
            <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
            <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
            <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
        </ol>
        <div class="carousel-inner">
            <?php
                $i = 0;
            ?>
            <?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $one): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="carousel-item  <?php if($i==0): ?> active <?php endif; ?> ">
                <img class=" w-100  " src="<?php echo e(asset($one->img)); ?>" alt="1 slide">

            </div>
                <?php
                    $i ++;
                ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


        </div>
        <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
            <span class="carousel-control-prev-icon " aria-hidden="true"></span>
            <span class="sr-only">Previous</span>
        </a>
        <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="sr-only">Next</span>
        </a>
    </div>
    <!--- end head --->
    <!--- -->
    <div class="container-fluid  ">
        <div class="container text-center ">
            <br>

            <h2><?php echo app('translator')->get('site.how_works'); ?>
                <hr>

            </h2>
            <br>
            <div class="row  ">
                <?php $__currentLoopData = $works; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $work): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if(Lang::locale()=='ar'): ?>
                <div class="col-md-4">
                        <i class="<?php echo e($work->icon); ?> icon"></i>
                        <h3><?php echo e($work->title_ar); ?></h3>
                        <p><?php echo e($work->content_ar); ?>

                        </p>
                        <br>
                </div>
                        <?php else: ?>
                        <div class="col-md-4">
                            <i class="<?php echo e($work->icon); ?> icon"></i>
                            <h3><?php echo e($work->title_en); ?></h3>
                            <p><?php echo e($work->content_en); ?>

                            </p>
                            <br>
                        </div>


                    <?php endif; ?>

               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
    <!--- -->
    <div class="container-fluid text-center ">
        <br>
        <h2><?php echo app('translator')->get('site.how_works'); ?>
            <hr>
        </h2> <br>
        <ul class="services-list pad-0">
            <li><a href="">
                    <img class="lazy" src="<?php echo e(asset('front/img/cleaning.png')); ?>" >
                    <br>
                    Residential Cleaning Services</a></li>
            <li><a href="">
                    <img class="lazy" src="<?php echo e(asset('front/img/cleaning.png')); ?>" ><br>
                    Commercial Cleaning Services</a></li>
            <li><a href="">
                    <img class="lazy" src="<?php echo e(asset('front/img/more.png')); ?>" ><br>
                    View More</a></li>
        </ul>
    </div>

    <!--- -->
    <div class="container text-center ">
        <br>
        <h2><?php echo app('translator')->get('site.why_works'); ?>
            <hr>
        </h2> <br>
        <div class="row text-left">
            <?php $__currentLoopData = $works; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $work): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <?php if(Lang::locale()=='ar'): ?>
                    <div class="col-lg-4 col-md-6 col-12">

                        <div class="row row3 pad">


                            <div class="col-3 ">
                                <br>
                                <i class="<?php echo e($work->icon); ?>  icon" ></i>
                            </div>
                            <div class="col-9 ">
                                <h3><?php echo e($work->title_ar); ?></h3>
                                <p><?php echo e($work->content_ar); ?>

                                </p>
                            </div>

                        </div>

                    </div>

                <?php else: ?>

                    <div class="col-lg-4 col-md-6 col-12">

                        <div class="row row3 pad">


                            <div class="col-3 ">
                                <br>
                                <i class="<?php echo e($work->icon); ?>  icon" ></i>
                            </div>
                            <div class="col-9 ">
                                <h3><?php echo e($work->title_en); ?></h3>
                                <p><?php echo e($work->content_en); ?>

                                </p>
                            </div>

                        </div>

                    </div>

                <?php endif; ?>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>
    </div>

    <!--- -->
    <div class="container-fluid text-center">
        <br> <br> <br>
        <div class="container">
            <div class="row">
                <div class="col-md-4 col-6">
                    <div class="circle">
                        <i class="fas fa-thumbs-up"></i>
                    </div>
                    <h2>100%</h2>
                    <p><?php echo app('translator')->get('site.quality'); ?></p>
                    <br>  </div>

                <div class="col-md-4 col-6">
                    <div class="circle">
                        <i class="fas fa-user"></i>
                    </div>
                    <h2>100+</h2>
                    <p><?php echo app('translator')->get('site.employees'); ?></p>
                    <br>  </div>

                <div class="col-md-4 col-12">
                    <div class="circle">
                        <i class="fas fa-calendar"></i>
                    </div>
                    <h2>5+</h2>
                    <p><p><?php echo app('translator')->get('site.years_experience'); ?></p></p>
                    <br>  </div>
            </div>


        </div>
    </div>
    <!--- -->    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.front.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\prestige\untitled folder\resources\views/front/index.blade.php ENDPATH**/ ?>