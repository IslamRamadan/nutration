<?php $__env->startSection('title'); ?>
<?php echo app('translator')->get("رتب المشرفين"); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('mo'); ?>
<?php echo $__env->make('flash::message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php $__env->startSection('ti'); ?>
    رتب المشرفين
<?php $__env->stopSection(); ?>
    <div class="  " style="padding:10px">

        <a href="<?php echo e(url(route('roles.create'))); ?>" class="btn btn-primary"><i class="fa fa-plus"></i> أضف رتبة</a>

    </div>


        <div class="box box-primary">



            <div class="box-header with-border">





            </div><!-- end of box header -->



            <div class="box-body">


                <div class="table-responsive">
                    <table class="table table-bordered">
                        <thead>
                        <tr>
                            <th>#</th>
                            <th>الاسم</th>
                            <th> الاسم المعروض</th>
                            <th class="text-center">الاجراءات</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $records; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $record): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr >
                                <td><?php echo e($loop->iteration); ?></td>
                                <td><?php echo e($record->name); ?></td>
                                <td><?php echo e($record->display_name); ?></td>
                                <td class="text-center">
                                    <a href="<?php echo e(url(route("roles.edit",$record->id))); ?>" class="btn btn-info btn-sm"><i class="fa fa-edit"></i> <?php echo app('translator')->get('site.edit'); ?></a>
                              
                                    <form action="<?php echo e(url(route("roles.destroy",$record->id))); ?>" method="post" style="display: inline-block">
                                        <?php echo e(csrf_field()); ?>

                                        <?php echo e(method_field('delete')); ?>

                                                <button type="submit" class="btn btn-danger delete  btn-sm"><i class="fa  fa-trash"></i> <?php echo app('translator')->get('site.delete'); ?></button>
                                            </form><!-- end of form -->

                                    </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>


                    <!-- Button trigger modal -->


            </div><!-- end of box body -->

            <?php if(count($records)==0): ?>
            <div class="alert alert-danger"> لا يوجد بيانات
            </div>
             <?php endif; ?>




        </div>






   

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard.app2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/bluezo11/easyshop-qa.com/resources/views//dashboard/roles/index.blade.php ENDPATH**/ ?>