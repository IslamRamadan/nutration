<?php $__env->startSection('title'); ?>

    <?php echo app('translator')->get('site.projects'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<div class="container-fluid  p-5">
    <div class="" style="position: relative">

    <img src="<?php echo e(url('front/img/20.webp')); ?>" class="w-100" alt="">
    <div class="img-div3" >
        



        </div>
    </div>
</div>
<div class="container text-center center-p1">

    <div class="component">
        <blockquote class="callout quote EN">
           <h2> <?php echo $my_section['qoute1_'.app()->getLocale()]; ?>

           </h2>
           </blockquote>
        </div>
        </div>


<div class="container-fluid  p-5">
    <?php echo $product['description_'.app()->getLocale()]; ?>

</div>

<?php $__currentLoopData = $product_imgs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<div class="container-fluid  p-5">
    <div class="row justify-content-center " style="position: relative;">
        <div class="col-lg-4 col-md-6 col-12 mb-3"  >
            <div class="" >
                <img src="<?php echo e(url($item->img)); ?>" class="w-100 cust-hght" alt="">
            </div>
        </div>
        <div class="col-lg-8 col-md-6 col-12 mb-3" style="align-self:center" >

            <p><?php echo $item['description_'.app()->getLocale()]; ?></p>
        </div>
    </div>
</div>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.front.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\monaleza\Documents\GitHub\Turk\resources\views/front/product.blade.php ENDPATH**/ ?>