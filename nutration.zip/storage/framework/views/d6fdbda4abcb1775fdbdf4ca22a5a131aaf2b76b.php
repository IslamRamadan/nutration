<?php $__env->startSection('title'); ?>

    <?php echo app('translator')->get('site.services'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>


    <!-----start carousel --->
    <div  class=" relative " >
        <div class="d-block w-100 h"  style=" background: linear-gradient(to top, #4321daba, #2b10c7cc), url(<?php echo e(url('/storage/'.$service->background_img)); ?>) no-repeat top center;"        >
            
        </div>
        <div class="abs w-100">
            <h4 class="custom-h4"><?php echo $service['name_'.app()->getLocale()]; ?></h4>
            <h1><?php echo $service['title_'.app()->getLocale()]; ?></h1>
            <h2><?php echo $service['content_'.app()->getLocale()]; ?></h2>
        </div>
    </div>
    <!--- end head --->
    <div class="container text-center center-p1">

        <div class="component">
            <br>
                <h4 class="mb-4"><?php echo $service['name_'.app()->getLocale()]; ?></h4>
            <blockquote class="callout quote EN">
               <h2><?php echo $my_section['qoute1_'.app()->getLocale()]; ?>

               </h2>
               </blockquote>
            </div>
            </div>

    <!--- -->

<div class="container mb-5">
    <div id="carouselExampleIndicators" class="carousel slide relative" data-ride="carousel">
        <ol class="carousel-indicators">
            <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
            <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
            <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
        </ol>
        <div class="carousel-inner">
            <?php
                $i = 0;
            ?>
            <?php $__currentLoopData = $service_images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $one): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="carousel-item  <?php if($i == 0): ?> active <?php endif; ?> ">
                    <img class=" w-100  " src="<?php echo e(asset($one->img)); ?>" alt="1 slide">

                </div>
                <?php
                    $i++;
                ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


        </div>
        <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
            <span class="carousel-control-prev-icon " aria-hidden="true"></span>
            <span class="sr-only">Previous</span>
        </a>
        <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="sr-only">Next</span>
        </a>
    </div>
</div>


<div class="container-fluid mb-5">
    <br>
    <?php echo $service['section1_'.app()->getLocale()]; ?>

    
    </div>





    <div class="container-fluid custom-container">
        <div class="row justify-content-between">
            <div class="col-lg-4 col-md-6 col-12 mt-sm-3">
                <br>
            <h4 class="custom-h4 pl-0 pr-0"><?php echo $service['section2_title_'.app()->getLocale()]; ?>

            </h4>
<br>
                <h1><?php echo $service['section2_content_'.app()->getLocale()]; ?></h1>

            </div>
            <div class="col-lg-6 col-md-6 col-12 ">
                <img src="<?php echo e(url('/storage/'.$service->section2_img)); ?>" class="w-100" alt="">
            </div>
        </div>
    </div>








<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.front.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\monaleza\Documents\nutration\resources\views/front/show_service.blade.php ENDPATH**/ ?>