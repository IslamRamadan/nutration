<!DOCTYPE html>
<html dir="<?php echo e(LaravelLocalization::getCurrentLocaleDirection()); ?>">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>dashboard</title>
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">

    
    <link rel="stylesheet" href="<?php echo e(asset('dashboard_files/css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('dashboard_files/css/ionicons.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('dashboard_files/css/skin-blue.min.css')); ?>">

    <?php if(app()->getLocale() == 'ar'): ?>
        <link rel="stylesheet" href="<?php echo e(asset('dashboard_files/css/front-awesome-rtl.min.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('dashboard_files/css/AdminLTE-rtl.min.css')); ?>">
        <link href="https://fonts.googleapis.com/css?family=Cairo:400,700" rel="stylesheet">
        <link rel="stylesheet" href="<?php echo e(asset('dashboard_files/css/bootstrap-rtl.min.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('dashboard_files/css/select2.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('dashboard_files/css/rtl.css')); ?>">
        <link rel="stylesheet" href=" <?php echo e(asset('dashboard_files/plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.min.css')); ?>">

        <style>
            body, h1, h2, h3, h4, h5, h6 ,label,span {
                font-family: 'Cairo', sans-serif !important;
            }

                .moha{
                    background:#fff;font-weight:bold;font-size:16px;-webkit-box-shadow: -1px 6px 40px -9px rgba(0,0,0,0.75);
-moz-box-shadow: -1px 6px 40px -9px rgba(0,0,0,0.75);
box-shadow: -1px 6px 40px -9px rgba(0,0,0,0.75);

                }
                thead{
                    background: #367FA9
                }
                thead > tr{
                    font-size: 16px;
                    color:#fff;
                }

                .f-16{
                    font-size: 16px;

                }



        </style>
    <?php else: ?>
        <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">
        <link rel="stylesheet" href="<?php echo e(asset('dashboard_files/css/front-awesome.min.css')); ?>">
        <link rel="manifest" href="<?php echo e(asset('front/js/manifest.json')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('dashboard_files/css/AdminLTE.min.css')); ?>">
    <?php endif; ?>

    <style>
        .mr-2{
            margin-right: 5px;
        }

        .loader {
            border: 5px solid #f3f3f3;
            border-radius: 50%;
            border-top: 5px solid #367FA9;
            width: 60px;
            height: 60px;
            -webkit-animation: spin 1s linear infinite; /* Safari */
            animation: spin 1s linear infinite;
        }

        /* Safari */
        @-webkit-keyframes spin {
            0% {
                -webkit-transform: rotate(0deg);
            }
            100% {
                -webkit-transform: rotate(360deg);
            }
        }

        @keyframes  spin {
            0% {
                transform: rotate(0deg);
            }
            100% {
                transform: rotate(360deg);
            }
        }


        .moha{
                    background:rgb(37, 37, 37);font-weight:bold;font-size:16px;-webkit-box-shadow: -1px 6px 40px -9px rgba(0,0,0,0.75);
-moz-box-shadow: -1px 6px 40px -9px rgba(0,0,0,0.75);
box-shadow: -1px 6px 40px -9px rgba(0,0,0,0.75);

                }
                thead{
                    background: #367FA9
                }
                thead > tr{
                    font-size: 16px;
                    color:#fff;
                }

                .f-16{
                    font-size: 16px;

                }


    </style>

    
    <script src="<?php echo e(asset('dashboard_files/js/jquery.min.js')); ?>"></script>

    
    <link rel="stylesheet" href="<?php echo e(asset('dashboard_files/plugins/noty/noty.css')); ?>">
    <script src="<?php echo e(asset('dashboard_files/plugins/noty/noty.min.js')); ?>"></script>

    
    <link rel="stylesheet" href="<?php echo e(asset('dashboard_files/plugins/morris/morris.css')); ?>">

    
    <link rel="stylesheet" href="<?php echo e(asset('dashboard_files/plugins/icheck/all.css')); ?>">


    
    <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
    <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>

</head>
<body class="hold-transition skin-blue sidebar-mini">

<div class="wrapper">

    <header class="main-header">

        
        <a href="" class="logo">
            
            <span class="logo-mini">admin</span>
            <span class="logo-lg"><span style="font-weight: bold">   <?php echo app('translator')->get("KOCART"); ?>
             </span></span>
        </a>

        <nav class="navbar navbar-static-top">
            <!-- Sidebar toggle button-->
            <a href="#" class="sidebar-toggle" data-toggle="push-menu" role="button">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </a>

            <div class="navbar-custom-menu">
                <ul class="nav navbar-nav">




 <!-- 
    <a href="#" class="dropdown-toggle" data-toggle="dropdown">
      <i class="fa fa-envelope-o"></i>
      <span class="label label-success">4</span>
    </a>
  
  </li>

  <li class="dropdown notifications-menu">
    <a href="#" class="dropdown-toggle" data-toggle="dropdown">
      <i class="fa fa-bell-o"></i>
      <span class="label label-warning">۱۰</span>
    </a>
    <ul class="dropdown-menu">
      <li class="header">لديك 10  طلبات جديدة</li>
      <li>
      
      </li>
      <li class="footer "><a href="#"> <button class="btn btn-success">الذهاب الي الطلبات</button> </a></li>
    </ul>
  </li>
-->
<li class="dropdown messages-menu">
 
  <li class="dropdown user user-menu">
    
  <a href="<?php echo e(route('user_logout')); ?>"  > تسجيل خروج</a>   
    <ul class="dropdown-menu">
      <!-- User image -->
      <li class="user-header">
        <img src="<?php echo e(asset('avatar.png')); ?>" class="img-circle" alt="User Image">
        <p>
        <?php echo e(request()->user()->name); ?> <br>   <?php echo e(request()->user()->email); ?>

        </p>
      </li>
      <!-- Menu Body
      <li class="user-body">
        <div class="col-xs-4 text-center">
          <a href="#">Followers</a>
        </div>
        <div class="col-xs-4 text-center">
          <a href="#">Sales</a>
        </div>
        <div class="col-xs-4 text-center">
          <a href="#">Friends</a>
        </div>
      </li>
      <!-- Menu Footer-->
      <li class="user-footer">
        <div class="pull-right">
          <a href="<?php echo e(route('profile.index')); ?>" class="btn btn-default btn-flat">الملف الشخصي</a>
        </div>
        <div class="pull-left">
          <form action="" method="post">
            <?php echo csrf_field(); ?>
			  <a href="<?php echo e(route('user_logout')); ?>"  > تسجيل خروج</a>
        </form>
        </div>
      </li>
    </ul>
  </li>
 
                </ul>
            </div>
        </nav>

    </header>
<?php /**PATH C:\xampp\htdocs\kokart\resources\views/layouts/dashboard/header.blade.php ENDPATH**/ ?>