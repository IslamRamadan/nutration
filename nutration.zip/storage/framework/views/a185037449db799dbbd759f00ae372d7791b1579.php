

<?php $__env->startSection('title'); ?>

    <?php echo app('translator')->get('site.post'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>


    <?php if(Lang::locale()=='ar'): ?>

        <!-----start carousel --->
        <div  class=" relative " >
            <img class="d-block w-100 h" src="<?php echo e(asset('front/img/s.jpg')); ?> " alt="1 slide">
            <div class="abs w-100">
                <h2><?php echo app('translator')->get('site.blog'); ?></h2>
                <a href=""><?php echo app('translator')->get('site.home'); ?></a>
                >>
                <a href=""><?php echo app('translator')->get('site.blog'); ?></a>
            </div>
        </div>
        <!--- end head --->
        <!--- -->
        <div class="container-fluid  ">
            <div class="container  ">
                <br>
                <div class="row  ">
                    <h2  class="text-center col-12"><?php echo app('translator')->get('site.blog'); ?>

                        <hr>
                    </h2>
                    <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <div class="text-center col-md-12">
                            <img id="myImg" src="<?php echo e(asset($post->img)); ?>" style="height: 80%;width: 80%">
                            <br><br>
                        </div>
                        <div class="col-md-12">
                            <h2 class="text-center mb-3"><?php echo e($post->title_ar); ?></h2>

                            <p><?php echo e($post->content_ar); ?></p>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <br><br>   <br><br>  </div></div>
        <!--- -->
    <?php else: ?>

        <!-----start carousel --->
        <div  class=" relative " >
            <img class="d-block w-100 h" src="<?php echo e(asset('front/img/s.jpg')); ?>" alt="1 slide">
            <div class="abs w-100">
                <h2><?php echo app('translator')->get('site.blog'); ?></h2>
                <a href=""><?php echo app('translator')->get('site.home'); ?></a>
                >>
                <a href=""><?php echo app('translator')->get('site.blog'); ?></a>
            </div>
        </div>
        <!--- end head --->
        <!--- -->
        <div class="container-fluid  ">
            <div class="container  ">
                <br>
                <div class="row  ">
                    <h2  class="text-center col-12"><?php echo app('translator')->get('site.blog'); ?>

                        <hr>
                    </h2>
                    <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <div class="text-center col-md-12">
                            <a href="<?php echo e(asset($post->img)); ?>">
                                <img id="myImg" src="<?php echo e(asset($post->img)); ?>" style="    width: 80%!important;height: 80%!important;">
                            </a>
                            <br>
                        </div>


                        <div class="text-left col-md-12">
                            <h2 class="text-center mb-3"><?php echo e($post->title_en); ?></h2>

                            <p><?php echo e($post->content_en); ?></p>

                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>         </div></div>
            <br><br>

            <br><br></div>
        <!--- -->


    <?php endif; ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.front.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\prestige\prestige\untitled folder\resources\views/front/post.blade.php ENDPATH**/ ?>