 

<?php $__env->startSection('title'); ?>
<?php echo app('translator')->get("الطلبات"); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('mo'); ?>
    



     <?php $__env->startSection('ti'); ?>
      بيانات الطلب
     <?php $__env->stopSection(); ?>
     <?php $governs = app('App\Models\Govern'); ?>
     


   


        <div class="box box-primary">

   
        



              <div style=" padding:20px ">
                     <div class="row ">
                          
						 <div class="col-md-3 col-xs-12 col-sm-6" >
								                       
								<span style="color:red">كود الطلب </span>
								<span class=""> : </span>

								<span><?php echo e($order->id); ?></span>
								
								</div>
						 
						  <div class="col-md-3 col-xs-12 col-sm-6" >
								                       
								<span style="color:red">تاريخ الطلب </span>
								<span class=""> : </span>

								<span><?php echo e($order->created_at); ?></span>
								
								</div>
						 
						 
                            <div class="col-md-3 col-xs-12 col-sm-6" >
								                       
								<span style="color:red">االمشتري </span>
								<span class=""> : </span>

								<span><?php if($order->user_id ==0 || $order->user_id ==""): ?>
								زائر
								<?php else: ?>
								عضو 
								<?php endif; ?></span>
								
								</div>
						 
						 
						  <div class="col-md-3 col-xs-12 col-sm-6" >
								                       
								<span style="color:red">الحالة </span>
								<span class=""> : </span>

								<span>
									<?php if($order->status ==1): ?>
							       جاري الشحن
							<?php elseif($order->status ==2): ?>
									جاري التوصيل 
									<?php elseif($order->status ==3): ?>
									تم الاستلام 
                         <?php elseif($order->status ==4): ?>
								تم الغاء الطلب 
									<?php else: ?>	
									لا يوجد 
									<?php endif; ?></span>
								
								</div>
						 
						 
						 
						  <div class="col-md-3 col-xs-12 col-sm-6" >
								                       
								<span style="color:red">الدولة </span>
								<span class=""> : </span>

								<span><?php echo e($order->country); ?></span>
								
								</div>
						 
						 
						 
						   <div class="col-md-3 col-xs-12 col-sm-6" >
								                       
								<span style="color:red">المدينة </span>
								<span class=""> : </span>

								<span><?php echo e($order->govern); ?></span>
								
								</div>
						 
						 
						 
						   <div class="col-md-3 col-xs-12 col-sm-6" >
								                       
								<span style="color:red">المنطقة </span>
								<span class=""> : </span>

								<span><?php echo e($order->city); ?></span>
								
								</div>
						 
						 
						  <div class="col-md-3 col-xs-12 col-sm-6" >
								                       
								<span style="color:red">العنوان </span>
								<span class=""> : </span>

								<span><?php echo e($order->address); ?></span>
								
								</div>
						 
						 
						  <div class="col-md-3 col-xs-12 col-sm-6" >
								                       
								<span style="color:red">الاسم </span>
								<span class=""> : </span>

								<span><?php echo e($order->username); ?></span>
								
								</div>
						 
						 
						 
						  <div class="col-md-3 col-xs-12 col-sm-6" >
								                       
								<span style="color:red">الهاتف </span>
								<span class=""> : </span>

								<span><?php echo e($order->phone); ?></span>
								
								</div>
						 
						 
						 
						  <div class="col-md-3 col-xs-12 col-sm-6" >
								                       
								<span style="color:red">طريقة الدفع </span>
								<span class=""> : </span>

								<span><?php echo e($order->type); ?></span>
								
								</div>
						 
						 
						 
						   <div class="col-md-3 col-xs-12 col-sm-6" >
								                       
								<span style="color:red">المبلغ </span>
								<span class=""> : </span>
								<span class=""> <?php echo e($my_setting->currency); ?> </span>

								<span><?php echo e($order->price); ?></span>

								</div>
						 
						 
						  <div class="col-md-3 col-xs-12 col-sm-6" >
								                       
								<span style="color:red">الدفع من الرصيد </span>
								<span class=""> : </span>
									<span class=""> <?php echo e($my_setting->currency); ?> </span>

								<span><?php echo e($order->balance); ?></span>

								</div>
						 
						 
						   <div class="col-md-3 col-xs-12 col-sm-6" >
								                       
								<span style="color:red">كود ماي فاتورة </span>
								<span class=""> : </span>

								<span><?php echo e($order->inovic_id); ?></span>
								
								</div>
						 
						  
						 
						 
						 
						 
								</div>
                          
                </div>	

            <div class="box-body">
				
				
                <div class="table-responsive">
                    <table class="table table-hover table-bordered  ">

                        <thead>
                        <tr>
                            <th>#</th>
                            <th class="text-center"><?php echo app('translator')->get('المنتج'); ?></th>
                            <th class="text-center"><?php echo app('translator')->get('سعر الوحدة'); ?></th>
                            <th class="text-center"><?php echo app('translator')->get('الكمية'); ?></th>
                            <th class="text-center"><?php echo app('translator')->get('اجمالي'); ?></th>
                            <th class="text-center"><?php echo app('translator')->get('اللون'); ?></th>
                            <th class="text-center"><?php echo app('translator')->get('المقاس'); ?></th>
                            <th class="text-center"><?php echo app('translator')->get('الصورة'); ?></th>

                        </tr>
                        </thead>

                        <tbody>
                            <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


                            <tr>
                                <td><?php echo e($loop->iteration); ?></td>
                            <td class="text-center"><?php echo e(App\Models\Item::find($category->item_id)->name??""); ?></td>
                            <td class="text-center"><?php echo e($category->price); ?>  <?php echo e($my_setting->currency); ?> </td>
                            <td class="text-center"><?php echo e($category->qut); ?></td>
                            <td class="text-center"><?php echo e($category->qut * $category->price); ?>  <?php echo e($my_setting->currency); ?> </td>
                            <td class="text-center"><?php echo e($category->color); ?></td>
                            <td class="text-center"><?php echo e($category->size); ?></td>
                            <td class="text-center"><img src="<?php echo e(asset($category->img)); ?>" alt="" width="90px" height="70px"> </td>
                            
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </tbody>

                    </table><!-- end of table -->
                </div>

                    <?php echo e($orders->appends(request()->query())->links()); ?>

                    <!-- Button trigger modal -->


            </div><!-- end of box body -->

            <?php if(count($orders)==0): ?>
            <div class="alert alert-danger"> لا يوجد بيانات
            </div>
             <?php endif; ?>










  

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard.app2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/bluezo11/kocart.easyshop-qa.com/resources/views//dashboard/orderItems/index.blade.php ENDPATH**/ ?>