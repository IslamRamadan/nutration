

<?php $__env->startSection('title'); ?>
<?php echo app('translator')->get("الطلبات"); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('mo'); ?>
    



     <?php $__env->startSection('ti'); ?>
      الطلبات
     <?php $__env->stopSection(); ?>
     <?php $governs = app('App\Models\Govern'); ?>
    
     <?php $users = app('App\Models\Client'); ?>



   


        <div class="box box-primary">

   
            <div class="box-header with-border">



                <form action="<?php echo e(route('orders.index')); ?>" method="get">


                        <div class="form-group col-md-6">
                            <label><?php echo app('translator')->get('حالة الطلب'); ?></label>
                            <select style="width:100%"  name="status" class="form-control " >
                            
                            <option value="1">جاري الشحن</option>
                            <option  value="2">تم الشحن</option>
                            <option  value="3">تم الاستلام</option>
								<option  value="4">تم الالغاء</option>

                            
                        </select>
                        </div>

                           


                              

                                <div class="col-md-6 form-group" >

                                    <label><?php echo app('translator')->get('المحافظة'); ?></label>
                                    <?php echo Form::select('govern',$governs->pluck('name','name')->toArray(),null,[
                                        'class' => 'form-control form-control-lg' . ($errors->has('category_id') ? ' is-invalid' : null),
                                         'id' => 'category',
                                         'placeholder' => 'اختر  المحافظة',
                                       
            
                                     ]); ?>

            
                                </div>
					
					
					 


                                <div class="col-md-6" >
                                    <label><?php echo app('translator')->get(' الهاتف'); ?></label>
                                    <input type="number" name="phone" class="form-control" placeholder="بحث بالهاتف" value="<?php echo e(request()->search); ?>">
                                </div>
            
                       

                        <div class="col-md-6 form-group"  >
                            <label><?php echo app('translator')->get('كود الطلب'); ?></label>
                            <input type="text" name="number" class="form-control" placeholder="بحث بكود الطلب" value="<?php echo e(request()->search); ?>">
                        </div>
					
					 <div class="col-md-6 form-group" >

                                    <label><?php echo app('translator')->get('الاعضاء'); ?></label>
                                    <?php echo Form::select('user_id',$users->pluck('name','id')->toArray(),null,[
                                        'class' => 'form-control form-control-lg',
                                         'id' => 'user_id',
                                         'placeholder' => 'اختر  العضو',
                                       
            
                                     ]); ?>

            
                                </div>

                        <div class="col-md-6 form-group" >
							                            <label><?php echo app('translator')->get('ابحث'); ?></label>

                            <button  type="submit" class="btn btn-primary btn-block"><i class="fa fa-search"></i> <?php echo app('translator')->get('site.search'); ?></button>



                        </div>

                   
                </form><!-- end of form -->

            </div><!-- end of box header -->





            <div class="box-body">


                <div class="table-responsive">
                    <table class="table table-hover table-bordered  ">

                        <thead>
                        <tr>
                            <th>#</th>
                            <th class="text-center"><?php echo app('translator')->get('الكود'); ?></th>
                            <th class="text-center"><?php echo app('translator')->get('المبلغ'); ?></th>
                            <th class="text-center"><?php echo app('translator')->get('الهاتف'); ?></th>
                            <th class="text-center"><?php echo app('translator')->get('المحافظة'); ?></th>
                            <th class="text-center"><?php echo app('translator')->get('المدينة'); ?></th>
                            <th class="text-center"><?php echo app('translator')->get('العنوان'); ?></th>
                            <th class="text-center"><?php echo app('translator')->get('التاريخ'); ?></th>
                            <th class="text-center"><?php echo app('translator')->get('حالة الطلب'); ?></th>

                            <th class="text-center"><?php echo app('translator')->get('الاجراءت'); ?></th>
                        </tr>
                        </thead>

                        <tbody>
                            <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


                            <tr>
                                <td><?php echo e($loop->iteration); ?></td>
                            <td class="text-center"><?php echo e($category->id); ?></td>
                            <td class="text-center"><?php echo e($category->price); ?>  <?php echo e($my_setting->currency); ?> </td>
                            <td class="text-center"><?php echo e($category->phone); ?></td>
                            <td class="text-center"><?php echo e($category->govern); ?></td>
                            <td class="text-center"><?php echo e($category->city); ?></td>
                            <td class="text-center"><?php echo e($category->address); ?></td>
                            <td class="text-center"><?php echo e($category->created_at); ?></td>
                            <?php if($category->status==1): ?>
                            <td class="text-center"> <div class="alert alert-info">جاري الشحن</div></td>
                            <?php elseif($category->status==2): ?>
                            <td class="text-center"> <div class="alert alert-danger">تم الشحن</div></td>

                            <?php elseif($category->status==3): ?>
                            <td class="text-center"> <div class="alert alert-success">تم الاستلام </div></td>
                             <?php elseif($category->status==4): ?>
                            <td class="text-center"> <div class="alert alert-danger">تم الالغاء</div></td>
                            <?php else: ?>
                            <td class="text-center"> </td>

                              <?php endif; ?>


                           


                                <td class="text-center">
                           <?php if($category->status!=4): ?>
                                        <a href="<?php echo e(url(route("orders.get_cancel",$category->id))); ?>" class="btn btn-primary btn-sm"><i class="fa fa-close"></i> <?php echo app('translator')->get(''); ?></a>
									<?php endif; ?>
									 <a href="<?php echo e(url(route("orders.edit",$category->id))); ?>" class="btn btn-primary btn-sm"><i class="fa fa-edit"></i> <?php echo app('translator')->get(''); ?></a>
									
                                        <a href="<?php echo e(url(route("order.item",$category->id))); ?>" class="btn btn-success btn-sm"><i class="fa fa-eye"></i> <?php echo app('translator')->get(''); ?></a>

                               
                                <form action="<?php echo e(url(route("orders.destroy",$category->id))); ?>" method="post" style="display: inline-block">
                                    <?php echo e(csrf_field()); ?>

                                    <?php echo e(method_field('delete')); ?>

                                            <button type="submit" class="btn btn-danger delete  btn-sm"><i class="fa  fa-trash"></i> <?php echo app('translator')->get(''); ?></button>
                                        </form><!-- end of form -->

                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </tbody>

                    </table><!-- end of table -->
                </div>

                    <?php echo e($orders->appends(request()->query())->links()); ?>

                    <!-- Button trigger modal -->


            </div><!-- end of box body -->

            <?php if(count($orders)==0): ?>
            <div class="alert alert-danger"> لا يوجد بيانات
            </div>
             <?php endif; ?>










  

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard.app2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/bluezo11/kocart.easyshop-qa.com/resources/views//dashboard/orders/index.blade.php ENDPATH**/ ?>