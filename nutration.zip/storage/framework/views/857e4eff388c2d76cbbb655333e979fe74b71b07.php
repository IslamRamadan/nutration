<?php $__env->startSection('title'); ?>

    <?php echo app('translator')->get('site.post'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<div  class=" relative1 " >
    <div class="abs w-100">
        <h4 class="custom-h4">Blog</h4>
        <h1>Blog</h1>

    </div>
</div>

<section class="news-hr section  mb-5 mt-5">
    <div class="container">

        <div class="row no-gutters">
            <div class="col-lg-6">
                <article class="news-post-hr">
                    <div class="row">
                    <div class="col-md-6 col-12 post-thumb">
                        <a href="">
                            <img src="<?php echo e(url('front/img/20.webp')); ?>" alt="post-image" class="img-fluid">
                        </a>
                    </div>
                    <div class="col-md-6 col-12 post-contents border-top">
                        <div class="post-title">
                            <h6><a href="">Default title here</a></h6>
                        </div>
                        <div class="post-exerpts">
                            <p>Lorem ipsum dolor sit amet conse ctetur adipisicing elit, sed doeiuse tempor incididunt ut
                            </p>
                        </div>

                        <div class="date">
                            <h4>20<span>May</span></h4>
                        </div>
                        <div class="more text-dir1">
                            <a href="">Show more</a>
                        </div>
                    </div>
                </div>
                </article>
            </div>
            <div class="col-lg-6">
                <article class="news-post-hr">
                    <div class="row">
                    <div class="col-md-6 col-12 post-thumb">
                        <a href="">
                            <img src="<?php echo e(url('front/img/26.webp')); ?>" alt="post-image" class="img-fluid">
                        </a>
                    </div>
                    <div class="col-md-6 col-12 post-contents border-top">
                        <div class="post-title">
                            <h6><a href="">Default title here</a></h6>
                        </div>
                        <div class="post-exerpts">
                            <p>Lorem ipsum dolor sit amet conse ctetur adipisicing elit, sed doeiuse tempor incididunt ut
                            </p>
                        </div>

                        <div class="date">
                            <h4>20<span>May</span></h4>
                        </div>
                        <div class="more text-dir1">
                            <a href="">Show more</a>
                        </div>
                    </div>
                </div>
                </article>
            </div>
            <div class="col-lg-6">
                <article class="news-post-hr">
                    <div class="row">
                    <div class="col-md-6 col-12 post-thumb">
                        <a href="">
                            <img src="<?php echo e(url('front/img/24.webp')); ?>" alt="post-image" class="img-fluid">
                        </a>
                    </div>
                    <div class="col-md-6 col-12 post-contents border-top">
                        <div class="post-title">
                            <h6><a href="">Default title here</a></h6>
                        </div>
                        <div class="post-exerpts">
                            <p>Lorem ipsum dolor sit amet conse ctetur adipisicing elit, sed doeiuse tempor incididunt ut
                            </p>
                        </div>

                        <div class="date">
                            <h4>20<span>May</span></h4>
                        </div>
                        <div class="more text-dir1">
                            <a href="">Show more</a>
                        </div>
                    </div>
                </div>
                </article>
            </div>
            <div class="col-lg-6">
                <article class="news-post-hr">
                    <div class="row">
                    <div class="col-md-6 col-12 post-thumb">
                        <a href="">
                            <img src="<?php echo e(url('front/img/21.webp')); ?>" alt="post-image" class="img-fluid">
                        </a>
                    </div>
                    <div class="col-md-6 col-12 post-contents border-top">
                        <div class="post-title">
                            <h6><a href="">Default title here</a></h6>
                        </div>
                        <div class="post-exerpts">
                            <p>Lorem ipsum dolor sit amet conse ctetur adipisicing elit, sed doeiuse tempor incididunt ut
                            </p>
                        </div>

                        <div class="date">
                            <h4>20<span>May</span></h4>
                        </div>
                        <div class="more text-dir1">
                            <a href="">Show more</a>
                        </div>
                    </div>
                </div>
                </article>
            </div>
            <div class="col-lg-6">
                <article class="news-post-hr">
                    <div class="row">
                    <div class="col-md-6 col-12 post-thumb">
                        <a href="">
                            <img src="<?php echo e(url('front/img/23.webp')); ?>" alt="post-image" class="img-fluid">
                        </a>
                    </div>
                    <div class="col-md-6 col-12 post-contents border-top">
                        <div class="post-title">
                            <h6><a href="">Default title here</a></h6>
                        </div>
                        <div class="post-exerpts">
                            <p>Lorem ipsum dolor sit amet conse ctetur adipisicing elit, sed doeiuse tempor incididunt ut
                            </p>
                        </div>

                        <div class="date">
                            <h4>20<span>May</span></h4>
                        </div>
                        <div class="more text-dir1">
                            <a href="">Show more</a>
                        </div>
                    </div>
                </div>
                </article>
            </div>
            <div class="col-lg-6">
                <article class="news-post-hr">
                    <div class="row">
                    <div class="col-md-6 col-12 post-thumb">
                        <a href="">
                            <img src="<?php echo e(url('front/img/25.webp')); ?>" alt="post-image" class="img-fluid">
                        </a>
                    </div>
                    <div class="col-md-6 col-12 post-contents border-top">
                        <div class="post-title">
                            <h6><a href="">Default title here</a></h6>
                        </div>
                        <div class="post-exerpts">
                            <p>Lorem ipsum dolor sit amet conse ctetur adipisicing elit, sed doeiuse tempor incididunt ut
                            </p>
                        </div>

                        <div class="date">
                            <h4>20<span>May</span></h4>
                        </div>
                        <div class="more text-dir1">
                            <a href="">Show more</a>
                        </div>
                    </div>
                </div>
                </article>
            </div>

        </div>
    </div>
</section>

<!--====  End of News  ====-->


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.front.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\monaleza\Documents\GitHub\Turk\resources\views/front/plan.blade.php ENDPATH**/ ?>