
<?php $__env->startSection('title','Account'); ?>
<?php echo app('translator')->get(""); ?>
<?php $__env->startSection('content'); ?>
    <div class="container"  id="divid"> <br><br>
        <?php if(  count($orders) > 0): ?>

            <div class="row pad text-center ">

                <h1  class="col-12 text-center">Order list</h1>
                <div class="col-lg-8 col-md-12"> <!--d-md-block d-none-->
                    <div class="table_block table-responsive " >


                        <table class="table table-bordered">
                            <thead class="btn-dark">

                            <tr>
                                <th >Order address</th>
                                <th >Order country</th>

                                <th >Order city</th>
                                <th >Order government</th>
                                <th >Order Price</th>
                                <th >&nbsp;</th>
                            </tr>
                            </thead>
                            <tbody >

                            <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <tr >
                                    <td >
                                        <span><?php echo e($order->address); ?></span>

                                    </td>
                                    <td >
                                        <span><?php echo e($order->country); ?></span>

                                    </td>

                                    <td >
                                        <span><?php echo e($order->city); ?></span>
                                    </td>

                                    <td >
                                        <span><?php echo e($order->govern); ?></span>

                                    </td>
                                    <td>
                                        <span><?php echo e($order->price); ?></span>


                                    </td>
                                    

                                        

                                    
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>





                            </tbody>
                        </table>


                    </div>
                </div>
                <?php elseif( count($orders) == 0): ?>
                    <br><br><br><br>
                    <h1 style="color: red ;text-align: center;">There are no Orders</h1><br><br><br><br>



                <?php endif; ?>




            </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\untitled folder\resources\views/front/order.blade.php ENDPATH**/ ?>