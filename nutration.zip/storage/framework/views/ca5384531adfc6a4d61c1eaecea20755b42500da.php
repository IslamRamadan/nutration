


<?php $__env->startSection('title'); ?>

    <?php echo app('translator')->get('site.projects'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>


    <?php if(Lang::locale()=='ar'): ?>


        <!-----start carousel --->
        <div  class=" relative " >
            <img class="d-block w-100 h" src="<?php echo e(asset('front/img/s.jpg')); ?>" alt="1 slide">
            <div class="abs w-100">
                <h2>    <?php echo app('translator')->get('site.projects'); ?></h2>
                <a href="">    <?php echo app('translator')->get('site.home'); ?>
                </a>
                >>
                <a href="">    <?php echo e($service->title_ar); ?>

                </a>
            </div>
        </div>
        <!--- end head --->
        <!--- -->
        <div class="container-fluid  ">
            <div class="container  ">
                <br>
                <div class="row  ">
                    <h2  class="text-center col-12"><?php echo e($service->name_ar); ?>



                        <hr>
                    </h2>

                    <p class="col-12"><br><?php echo e($service->content_ar); ?></p>
                    <br><br>
                    <div class="text-center col-12">
                        <?php $__currentLoopData = $service_images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service_image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <img src="<?php echo e(asset('myfiles/'.$service_image->img)); ?>" class="img-services" style="width: 300px;height: 223px">
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <br><br>
                </div>
            </div></div>
        <!--- -->



    <?php else: ?>

        <!-----start carousel --->
        <div  class=" relative " >
            <img class="d-block w-100 h" src="<?php echo e(asset('front/img/s.jpg')); ?>" alt="1 slide">
            <div class="abs w-100">
                <h2>    <?php echo app('translator')->get('site.projects'); ?></h2>
                <a href="">    <?php echo app('translator')->get('site.home'); ?>
                </a>
                >>
                <a href="">    <?php echo e($service->title_en); ?>

                </a>
            </div>
        </div>
        <!--- end head --->
        <!--- -->
        <div class="container-fluid  ">
            <div class="container  ">
                <br>
                <div class="row  ">
                    <h2  class="text-center col-12"><?php echo e($service->name_en); ?>



                        <hr>
                    </h2>

                    <p class="col-12"><br><?php echo e($service->content_en); ?></p>
                    <br><br>
                    <div class="text-center col-12">
                        <?php $__currentLoopData = $service_images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service_image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <img src="<?php echo e(asset('myfiles/'.$service_image->img)); ?>" class="img-services" style="width: 300px;height: 223px">
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <br><br>
                </div>
            </div></div>
        <!--- -->



    <?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.front.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\prestige\prestige\untitled folder\resources\views/front/project.blade.php ENDPATH**/ ?>