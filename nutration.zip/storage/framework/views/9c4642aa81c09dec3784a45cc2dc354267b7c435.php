 
<?php $__env->startSection('title'); ?>
<?php echo app('translator')->get(""); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
 <!-----start carousel --->
     <div id="carouselExampleIndicators" class="carousel slide  carousel-fade border-main" data-ride="carousel">
          <ol class="carousel-indicators">
            <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
            <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
            
          </ol>
      <div class="carousel-inner">
          <?php
          $i = 0;
          ?>
          <?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $one): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="carousel-item h  <?php if($i==0): ?> active <?php endif; ?>">
              <img class="d-block w-100 " src="<?php echo e(asset($one->img)); ?>" alt="<?php echo e($one->name_en); ?>">
          
      </div>
          <?php
          $i ++;
          ?>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
     
      </div>
          <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="sr-only">Previous</span>
          </a>
          <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="sr-only">Next</span>
          </a>
        </div>
      <!-----start category --->
     <div class="container-fluid ">
           <div class="container border-main"><br>
        <div class="row vendor">

         <h1 class="col-12">Vendors  <br><br></h1>
               <div id="carousel-our" class="carousel slide multi col-12 text-center" data-ride="carousel"  >
        	 			<div class="carousel-inner text-cente row w-100 mx-auto" role="listbox">
        	 			   
        	 			    
          <?php
          $i = 0;
          ?>
          <?php $__currentLoopData = $vendors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $one): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <?php if($one->img != ""): ?>
            			<div class="carousel-item col-12 col-sm-6 col-md-4 col-lg-3 <?php if($i==0): ?> active <?php endif; ?>"  >
                    <a href="<?php echo e(route("vendor",$one->id)); ?>"> <img src="<?php echo e(asset($one->img)); ?>" class=" " alt="<?php echo e($one->name_en); ?>"> </a>
                               </div>
		  <?php
          $i ++;
          ?>	
          <?php endif; ?>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          
        			</div>
        	
            </div>
               </div><br><br></div>
    
    </div>
      
      
    <!----- shop --->
           <div class="container border-main" >
          
               <br>
        <div class="row  row5 ">
                 <h1 class="col-12"> deal of the day</h1>
                 
                 <?php $__currentLoopData = $offers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $one): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
             <div class=" col-6 col-md-4 col-lg-3 "  >
                          <br> <div class="card">
                 <h6 class="bg-main abs">ref:<?php echo e($one->id); ?></h6>
				 <a href="<?php echo e(route("product",$one->id)); ?>">
                     <img height="200" src="<?php echo e(asset($one->img)); ?>" class="card-img-top  " alt="..." > </a>
                                <div class="card-body">
                  <a href="<?php echo e(route("product",$one->id)); ?>" class="card-text "><?php echo e($one->name_en); ?></a>
             <p class="card-title" href=""><b>KWD<?php echo e($one->price); ?></b></p>
                              
                                </div>
                                    <div class="row mr-0">
                <a href="<?php echo e(route('add.cart',[$one->id,1])); ?>" class="btn btn-dark border col-9">add to cart</a>

                                        <!--islam Modification-->
                                        <?php if(!Auth::guard('client')->check()): ?>
                                            <div class="btn btn-light border col-3 heart text-center"> <a class="addToWishlist" href="<?php echo e(route('login/client')); ?>"><i class="fas fa-heart heart-none"></i><i class="far fa-heart  heart-block"></i></a> </div></div> </div></div>

                                        <?php elseif(Auth::guard('client')->check()): ?>
                    <a href="#" class="addToWishlist" data-product-id = "<?php echo e($one->id); ?>"><div class="btn btn-light border col-3 heart text-center"> <i class="fas fa-heart heart-none"></i><i class="far fa-heart  heart-block"></i> </div> </a>                         </div> </div></div>


                                        <?php endif; ?>
                                        <!--islam Modification-->


 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              
            
						</div>
<br>
<?php echo e($offers->appends(request()->query())->links()); ?>


               <br><br></div>
 
    
    
      <div class="container  border-main" ><br>
        <div class="row  row5 ">
                 <h1 class="col-12"> deal of the day</h1>
                 
                 <?php $__currentLoopData = $populars; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $one): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
             <div class=" col-6 col-md-4 col-lg-3 "  >
                          <br> <div class="card">
                 <h6 class="bg-main abs">ref:<?php echo e($one->id); ?></h6>
				 <a href="<?php echo e(route("product",$one->id)); ?>">
                     <img height="200" src="<?php echo e(asset($one->img)); ?>" class="card-img-top  " alt="..." > </a>
                                <div class="card-body">
                  <a href="<?php echo e(route("product",$one->id)); ?>" class="card-text "><?php echo e($one->name_en); ?></a>
             <p class="card-title" href=""><b>KWD<?php echo e($one->price); ?></b></p>
                              
                                </div>
                                    <div class="row mr-0">
                <a href="<?php echo e(route('add.cart',[$one->id,1])); ?>" class="btn btn-dark border col-9">add to cart</a>
                                        <!--islam Modification-->
                                        <?php if(!Auth::guard('client')->check()): ?>
                                            <div class="btn btn-light border col-3 heart text-center"> <a class="addToWishlist" href="<?php echo e(route('login/client')); ?>"><i class="fas fa-heart heart-none"></i><i class="far fa-heart  heart-block"></i></a> </div></div> </div></div>

                <?php elseif(Auth::guard('client')->check()): ?>
                    <a href="#" class="addToWishlist" data-product-id = "<?php echo e($one->id); ?>"><div class="btn btn-light border col-3 heart text-center"> <i class="fas fa-heart heart-none"></i><i class="far fa-heart  heart-block"></i> </div> </a>                         </div> </div></div>


 <?php endif; ?>
 <!--islam Modification-->

 <!--islam Modification-->              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              
            
						</div>
<br>
<?php echo e($populars->appends(request()->query())->links()); ?>

   <br><br> </div>
            
            
         <br><br>
      <div class="container">
            <div id="carouselExampleIndicators" class="carousel slide  carousel-fade" data-ride="carousel">
        
      <div class="carousel-inner">
      <div class="carousel-item  active">
                <img src="<?php echo e(asset('front/img/c.png')); ?>" class="w-100 ad">
          
      </div>
           <div class="carousel-item  ">
               <img src="<?php echo e(asset('front/img/s3.jpg')); ?>" class="w-100 ad">
          
      </div>
      <div class="carousel-item  ">
            <img src="<?php echo e(asset('front/img/s2.jpg')); ?>" class="w-100 ad">  
          
      </div>
      </div>
         
        </div>
   
       
    </div>  <br><br>   
    <?php $__env->stopSection(); ?>
 <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

 <script  >
    $(document).on('click','.addToWishlist',function (e) {

        e.preventDefault();
        $.ajax({
            type: 'get',
            url:"<?php echo e(route('wishlist.store')); ?>",
            data:{
                'productId':$(this).attr('data-product-id'),
            },
            success:function (data) {
                if (data.message){
                alert(data.message)}
                else {
                    alert('This product already in you wishlist');
                }
            }
        });


    });


</script>
    
<?php echo $__env->make('layouts.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\kokart\resources\views/front/index.blade.php ENDPATH**/ ?>