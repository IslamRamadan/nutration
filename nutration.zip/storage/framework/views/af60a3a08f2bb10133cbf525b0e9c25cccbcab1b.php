

<?php $__env->startSection('title'); ?>
<?php echo app('translator')->get("site.categories"); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('mo'); ?>
    



     <?php $__env->startSection('ti'); ?>
             تشكيلة  :  <?php echo e(App\Models\Item::find($id)->name); ?>

     <?php $__env->stopSection(); ?>


     <?php $cat = app('App\Models\Category'); ?>
     <?php $subcat = app('App\Models\SubCategory'); ?>
     <?php $subcat2 = app('App\Models\SubSubCategory'); ?>



    <br>


        <div class="box box-primary">



            <div class="box-header with-border">

         <div style="margin: 10px;font-size: 16px;font-weight: bold">  اضف مقاس جديد  </div>
                <form action="<?php echo e(route('items.add.size',$id)); ?>" method="post">
                     <?php echo csrf_field(); ?>
                    <div class="row">

                        <div class="col-md-12 form-group"  style=" ">
                            <input type="text" name="name" class="form-control" placeholder="مقاس جديد" value="<?php echo e(request()->name); ?>">
                        </div>

                     

                        <div class="col-md-2 form-group" style=" ">
                            <button  type="submit" class="btn btn-primary "><i class="fa fa-add"></i> <?php echo app('translator')->get('site.add'); ?></button>



                        </div>

                    </div>
                </form><!-- end of form -->

            </div><!-- end of box header -->

        </div>
            

        <?php if(count($sizes)==0): ?>
        <div class="alert alert-danger"> لا يوجد بيانات
        </div>
        <?php else: ?>
        <div class="alert alert-success text-center" style="font-weight: bold;font-size: 17px;"> التشكيلة المتاحة
        </div>
        <?php endif; ?>











        <div class="row">   
        <?php $__currentLoopData = $sizes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $one): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

      

               

                   

                        
                  <div class="col-md-6">   

                               
                <div class="panel panel-primary">
                    <div class="panel-heading">
                      <h3 class="panel-title">  المقاس :   <a href="<?php echo e(route('items.edit.size',$one->id)); ?>" > <?php echo e($one->name); ?> <span style="padding : 20px 30px"> <i class="fa fa-eye"></i></span></a>  </h3>
                    </div>
                    <div class="panel-body">

                       
                       

                        


                        <form action="<?php echo e(route('items.add.color',[$id])); ?>" method="post">
                            <?php echo csrf_field(); ?>
                        <div class="row">
                            <input type="hidden" name="hidden" value="<?php echo e($one->id); ?>">
                            <div class="col-md-3 form-group"  style=" ">
    
                                <input type="text" name="name" class="form-control" placeholder="لون جديد" value="" required>
                            </div>
							
							 <div class="col-md-3 form-group"  style=" ">
    
                                <input type="text" name="name_en" class="form-control" placeholder="اللون بالانجليزية" value="" required>
                            </div>
    
    
    
                            <div class="col-md-3 form-group"  style=" ">
    
                                <input min="1" type="number" name="qut" class="form-control" placeholder="الكمية" value="" required>
                            </div>
    
                            <div class="col-md-3 form-group"  style=" ">
    
                                <button  type="submit" class="btn btn-success "><i class="fa fa-plus"></i> <?php echo app('translator')->get('site.add'); ?></button>

                            </div>
    
                           
                        </div>
                    </form>
                    <?php
                    $array = [];
                ?>
                        <?php $__currentLoopData = $one->colors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $one2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
 


                         <?php if(!in_array($one2->name,$array)): ?>
                         <form action="<?php echo e(route('items.update.color',[$id,])); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="hidden_size" value="<?php echo e($one->id); ?>">
                            <input type="hidden" name="hidden_color" value="<?php echo e($one2->id); ?>">

                            <div class="row">
                        <div class="col-md-3 form-group"  style=" ">
                            <label><?php echo app('translator')->get('اللون'); ?></label>

                            <input type="text" name="name" class="form-control" placeholder="" value="<?php echo e($one2->name); ?>">
                        </div>
								
								  <div class="col-md-3 form-group"  style=" ">
                            <label><?php echo app('translator')->get('اللون بالانجليزية'); ?></label>

                            <input type="text" name="name_en" class="form-control" placeholder="" value="<?php echo e($one2->name_en); ?>">
                        </div>



                        <div class="col-md-2 form-group"  style=" ">
                            <label><?php echo app('translator')->get('الكمية'); ?></label>
                            <?php
                                $qut = App\Models\Color::where("item_id",$id)->where("size_id",$one->id)->where("name",$one2->name)->count();
                            ?>

                            <input type="text" name="qut" class="form-control" placeholder="" value="<?php echo e($qut); ?>">
                        </div>

                        <div class="col-md-2 form-group"  style=" ">
                            <label><?php echo app('translator')->get(' '); ?></label>

                            <input  type="submit" class="btn btn-primary btn-block " value="<?php echo app('translator')->get('site.edit'); ?>">
                        </div>

                        <div class="col-md-2 form-group"  style=" ">
                            <label><?php echo app('translator')->get(' '); ?></label>

                            <input  type="submit" class="btn btn-danger btn-block  "value ="<?php echo app('translator')->get('حذف'); ?>" name="delete">
                        </div>
                    </div>
                </form>
                    <?php endif; ?>

                   
                    <?php
                    $array[] = $one2->name;
                ?>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                        <?php
                        $array = [];
                    ?>

                       
                    </div>
                </div>

            </div>     
           

          
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
    </div>


           
  

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard.app2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/bluezo11/easyshop-qa.com/resources/views//dashboard/items/size.blade.php ENDPATH**/ ?>