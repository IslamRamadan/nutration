<?php $__env->startSection('title'); ?>
    

    <?php echo $my_section['about_title_'.app()->getLocale()]; ?>


<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<!-----start carousel --->
<div  class=" relative1 " >
    <div class="abs w-100">
        <h4 class="custom-h4"><?php echo $my_setting['about_'.app()->getLocale()]; ?></h4>
        <h1><?php echo $my_section['about_title_'.app()->getLocale()]; ?></h1>

    </div>
</div>

<div class="container-fluid">
    <div class="row justify-content-between">
        <div class="col-md-7 col-12 ">

<br>
<?php echo $my_setting['about_app_'.app()->getLocale()]; ?>

        
    </div>
</div>

    

<div class="container-fluid  mb-4">
    <br>

    <h2 class="text-center"><?php echo app('translator')->get('site.dry_i4'); ?><hr>
    </h2>
    <br>
    <div class="row align-items-center">
        <?php $__currentLoopData = App\Models\ClientImg::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-lg-2 col-md-3 col-4">
            <img src="<?php echo e(url($item->img)); ?>" alt="" style="
                width: -webkit-fill-available;
            ">
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </div>

</div>

<!--- -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.front.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\monaleza\Documents\GitHub\Turk\resources\views/front/about.blade.php ENDPATH**/ ?>