<footer class="container-fluid bg-main">
    <div class="container">
        <br><br>
        <div class="row">
            <div class="col-12">
                
                <p>

                <?php if(app()->getLocale() == 'en'): ?>
                    <?php echo e($my_setting->address_en); ?>

                <?php else: ?>
                    <?php echo e($my_setting->address); ?>

                <?php endif; ?>
                </p>
            </div>
            <div class="col-md-9">

                <a href="<?php echo e(route('home.index')); ?>"><?php echo app('translator')->get('site.home'); ?></a>
                <a href="<?php echo e(route('about.index')); ?>"><?php echo app('translator')->get('site.about_us'); ?></a>
                <a href="<?php echo e(route('contacts.index')); ?>"><?php echo app('translator')->get('site.contact_us'); ?></a>
                
                
                

            </div>

            <div class="col-md-3">
                <nav class="navbar navbar-expand pad-0 ">
                    <ul class="navbar-nav mr-auto ">


                        <li class="nav-item "><a class="nav-link " href="<?php echo e($my_setting->insta_link); ?>" title="instagram"><i class="fab fa-instagram"></i>  </a></li>
                        <li class="nav-item "><a class="nav-link " href="<?php echo e($my_setting->tw_link); ?>" title="twitter"><i class="fab fa-twitter"></i>  </a></li>
                        <li class="nav-item "><a class="nav-link " href="tel:<?php echo e($my_setting->contact_phone); ?>" title="call us"><i class="fas fa-phone"></i>  </a></li>
                        <li class="nav-item "><a class="nav-link " href="<?php echo e($my_setting->yt_link); ?>" title="youtube"><i class="fab fa-youtube"></i>  </a></li>

                    </ul>

                </nav>
            </div>
            <p class="col-12 text-center"><br><br>All rights reserved © 2022 | This template is made by <a href="#" class=""><?php echo $my_setting['name_en']; ?></a></p>

        </div>

    </div>

</footer>







<a href="https://wa.me/<?php echo e($my_setting->wats); ?>">
    <img src="<?php echo e(asset('front/img/whatsapp.svg')); ?>" class="whatsapp shadow">
</a>














<script src="<?php echo e(asset('front/js/jquery-3.3.1.min.js')); ?>"></script>
<script src="<?php echo e(asset('front/js/popper.min.js')); ?>"></script>
<script src="<?php echo e(asset('front/js/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('front/js/all.min.js')); ?>"></script>
<script src="<?php echo e(asset('front/js/wow.min.js')); ?>"></script>
<script>
    new WOW().init();
</script>
<script src="<?php echo e(asset('front/js/main-js.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('js/slick.min.js')); ?>"></script>
<script src="<?php echo e(asset('front/js/counterup.min.js')); ?>"></script>

</body>

</html>
<?php /**PATH C:\Users\monaleza\Documents\GitHub\Turk\resources\views/layouts/front/footer.blade.php ENDPATH**/ ?>