<!DOCTYPE html>
<html lang="en">
<head>
	<title>reset passsword</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
<!--===============================================================================================-->	
	<link rel="icon" type="image/png" href="<?php echo e(asset('login/images/icons/favicon.ico')); ?>" />
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('login/vendor/bootstrap/css/bootstrap.min.css')); ?>" >
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('login/fonts/font-awesome-4.7.0/css/font-awesome.min.css')); ?>" >
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('login/fonts/Linearicons-Free-v1.0.0/icon-font.min.css')); ?>" >
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('login/vendor/animate/animate.css')); ?>" >
<!--===============================================================================================-->	
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('login/vendor/css-hamburgers/hamburgers.min.css')); ?>" >
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('login/vendor/select2/select2.min.css')); ?>" >
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('login/css/util.css')); ?>" >
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('login/css/main.css')); ?>" >
<!--===============================================================================================-->
</head>
<body>
	
	<div class="limiter">
		<div class="container-login100">
			<div class="wrap-login100 p-l-50 p-r-50 p-t-77 p-b-30">
				<form class="login100-form validate-form" method="post" action="<?php echo e(route('password.email')); ?>">
					<span class="login100-form-title p-b-55">
						send to email
					</span>

   
                    <div class="card-body">
                        <?php if(session('status')): ?>
                            <div class="alert alert-success" role="alert">
                                <?php echo e(session('status')); ?>

                            </div>
                        <?php endif; ?>

				<?php echo csrf_field(); ?>
                    <div class="wrap-input100 validate-input m-b-16" data-validate = "Valid email is required: ex@abc.xyz">
                        <input class="input100  <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="text" name="email" placeholder="Email"  name="email" value="<?php echo e(old('email')); ?>" id="email">
                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
						<span class="focus-input100"></span>
						<span class="symbol-input100">
							<span class="lnr lnr-envelope"></span>
						</span>
					</div>

				

				
					
					<div class="container-login100-form-btn p-t-25">
						<button class="login100-form-btn">
							send
						</button>
					</div>

				

				
					
				</form>
			</div>
		</div>
	</div>
	
	

	
<!--===============================================================================================-->	
	<script src="<?php echo e(asset('login/vendor/jquery/jquery-3.2.1.min.js')); ?>" ></script>
<!--===============================================================================================-->
	<script src="<?php echo e(asset('login/vendor/bootstrap/js/popper.js')); ?>" ></script>
	<script src="<?php echo e(asset('login/vendor/bootstrap/js/bootstrap.min.js')); ?>" ></script>
<!--===============================================================================================-->
	<script src="<?php echo e(asset('login/vendor/select2/select2.min.js')); ?>" ></script>
<!--===============================================================================================-->
	<script src="<?php echo e(asset('login/js/main.js')); ?>" ></script>

</body>
</html><?php /**PATH /home/bluezo11/easyshop-qa.com/resources/views/auth/passwords/email.blade.php ENDPATH**/ ?>