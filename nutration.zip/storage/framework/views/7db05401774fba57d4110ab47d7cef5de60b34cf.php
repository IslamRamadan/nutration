


<?php $__env->startSection('title'); ?>

    <?php echo app('translator')->get('site.projects'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>


    <?php if(Lang::locale()=='ar'): ?>

        <!-----start carousel --->
        <div  class=" relative " >
            <img class="d-block w-100 h" src="<?php echo e(asset('front/img/s.jpg')); ?>" alt="1 slide">
            <div class="abs w-100">
                <h2>    <?php echo app('translator')->get('site.projects'); ?></h2>
                <a href="">    <?php echo app('translator')->get('site.home'); ?>
                </a>
                >>
                <a href="">    <?php echo app('translator')->get('site.projects'); ?>
                </a>
            </div>
        </div>
        <!--- end head --->
        <!--- -->
        <div class="container-fluid">
            <div class="container  ">
                <br>
                <div class="row  ">
                    <h2  class="text-center col-12"><?php echo app('translator')->get('site.projects'); ?>


                        <hr>
                    </h2>

                    <p class="col-12 "><br><?php echo app('translator')->get('site.our_projects'); ?></p>
                    <br><br>
                    <br><br>

                    <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-6">
                            <h4><?php echo e($service->title_ar); ?></h4>

                            <p><?php echo e($service->content_ar); ?></p>

                            <a href="<?php echo e(route('my_projects.show',$service->id)); ?>" class="btn btn-primary mb-3"><?php echo app('translator')->get('site.view_more'); ?></a>
                        </div>
                        <div class="text-center col-md-6">
                            <a href="<?php echo e(asset($service->img)); ?>" target="_blank">
                                <img id="myImg" src="<?php echo e(asset($service->img)); ?>" class="w-100">
                            </a>
                            <br><br>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>         </div></div>
            <br><br>

            <br><br></div>
        <!--- -->


    <?php else: ?>


        
        
            
            
                
                
                
                
                
                
            
        
        
        
        
            
                
                
                    


                        
                    

                    
                    




                    
                        
                        

                            
                                
                                

                                    
                                    
                                        

                                    
                                
                            

                        

                            

                    






                    
                
            
        

















        <!-----start carousel --->
        <div  class=" relative " >
            <img class="d-block w-100 h" src="<?php echo e(asset('front/img/s.jpg')); ?>" alt="1 slide">
            <div class="abs w-100">
                <h2>    <?php echo app('translator')->get('site.projects'); ?></h2>
                <a href="">    <?php echo app('translator')->get('site.home'); ?>
                </a>
                >>
                <a href="">    <?php echo app('translator')->get('site.projects'); ?>
                </a>
            </div>
        </div>
        <!--- end head --->
        <!--- -->
        <div class="container-fluid  mt-3">
            <div class="container  ">
                <br>
                <div class="row  ">
                    <h2  class="text-center col-12"><?php echo app('translator')->get('site.projects'); ?>


                        <hr>
                    </h2>

                    <p class="col-12"><br><?php echo app('translator')->get('site.our_projects'); ?></p>
                    <br><br>
                    <br><br>
                    <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-6">
                            <h4><?php echo e($service->title_en); ?></h4>

                            <p><?php echo e($service->content_en); ?></p>

                            <a href="<?php echo e(route('my_projects.show',$service->id)); ?>" class="btn btn-primary mb-3"><?php echo app('translator')->get('site.view_more'); ?></a>
                        </div>
                        <div class="text-center col-md-6">
                            <a href="<?php echo e(asset($service->img)); ?>" target="_blank">
                            <img id="myImg" src="<?php echo e(asset($service->img)); ?>" class="w-100">
                            </a>
                            <br><br>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>         </div></div>
            <br><br>

            <br><br></div>
        <!--- -->










    <?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.front.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\prestige\prestige\untitled folder\resources\views/front/all_projects.blade.php ENDPATH**/ ?>