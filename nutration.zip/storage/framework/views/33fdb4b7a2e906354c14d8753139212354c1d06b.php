<?php $__env->startSection('title', 'Cart'); ?>
<?php $__env->startSection('content'); ?>






<div class="container"  id="divid"> <br><br>           
<div class="row pad text-center ">
<?php if(session('success')): ?>

<div class="alert alert-success text-center" style="width: 60%; margin-left: 15%;">
<?php echo e(session('success')); ?>

</div>

<?php endif; ?>
<h1  class="col-12 text-center">Cart</h1>  

<div class="col-lg-8 col-md-12"> <!--d-md-block d-none-->
<div class="table_block table-responsive " >
<table class="table table-bordered">
<thead class="btn-dark">
<tr>
<th colspan="2" >Product name</th>
<th >vendor</th>
<th >Price</th>
<th >QUANTITY</th>
<th >SUBTOTAL</th>
<th >&nbsp;</th>
</tr>
</thead>
<tbody >

<?php $total = 0 ; ?>
<?php if(session('cart')): ?> 
<?php $__currentLoopData = session('cart'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $details): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<?php
$total += $details['price'] * $details['quantity'] ;
$product = \App\Models\Item::where('id', $details['id'])->first();
$vendor = \App\Models\Category::where('id', $product->category_id)->first();

?>
<tr >
<td >
<a href="<?php echo e(url('/en/product/'.$product->slug)); ?>">
<img alt="<?php echo e($product->name_en); ?>" src="<?php echo e(asset($product->img)); ?>" width="100px;">
</a>
</td>
<td >
<p class="">
<a href="<?php echo e(url('/en/product/'.$product->slug)); ?> " class="active"><?php echo e($product->name); ?></a>
</p>

<small>Product Code: <span><?php echo e($product->ref_id); ?> </span></small>
</td>
<td >
<span><?php echo e($vendor->name); ?></span>
</td>
<td >
<span><?php echo e($product->price); ?></span>
</td>

<td data-th="Quantity" class=" text-center" style="width:15%">
 <?php $price = $details["price"] ;
?>
<div class=" product-count col-12">
<a onClick="update_cart(<?=$details["id"]?>,<?=$price?>,'minus',<?=$details["id"]?>);" rel="nofollow" data-id="<?php echo e($id); ?>" class="btn btn-default btn-minus " href="#" title="Subtract">&ndash;</a>
<input type="text" name="quantity" id="qty_<?=$details["id"]?>" value="<?=(isset($details['quantity']))?$details['quantity']: 1 ?>" size="2" class="cart_quantity_input form-control grey count quantity" min=1 style="" />
<a onClick="update_cart(<?=$details["id"]?>,<?=$price?>,'plus',<?=$details["id"]?>);"  rel="nofollow" class="btn btn-default btn-plus " href="#" title="Add">+</a>
</div>
</td>
<td class="subtotal text-center" data-title="SUBTOTAL">
<p class="x_sub_total_price_<?=$details["id"]?>"><?php echo e($details['price'] * $details['quantity']); ?> KWD</p> 
</td>
<td style="" >
<button title="refresh" style="border: none;color: #fe3843;padding:10;background: none; cursor: pointer;" class="btn btn-info btn-sm update-cart" data-id="<?php echo e($id); ?>"><i style="width:15px" class="fas fa-sync-alt"></i></button>
<button title="delete" style="border: none;color: #fe3843;padding:0px;background: none; cursor: pointer;" class="btn btn-danger btn-sm remove-from-cart" data-id="<?php echo e($id); ?>"><i style="width:15px"  class="fas fa-trash"></i></button>

</td>
</tr>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php else: ?>
	<tr >
<td colspan="7" class="text-center" >  There are no items in the cart  </td>
</tr>
<?php endif; ?>
 

</tbody>
</table>
</div>
</div>
<div class="col-lg-4   col-xs-12  text-left">
<div class="row">
<div id="tttt" class="container col-xs-12  border">
<div class="btn-dark row">
<h3 class=" col-12 c-w  mr-0">  Cart detail </h3>
</div><br>
<p >Cart Subtotal:<span id="total" class="float-right my_total "><?php echo e($total); ?> KWD</span></p><br>
<p >Shipping:<span class="float-right">Free Shipping</span></p><br>
<p >ORDER TOTAL: <span id="" class="float-right my_total"><?php echo e($total); ?> KWD</span></p><br>
<!--
<h4 class="main-color">Coupon Discount</h4>

<input type="text" class="form-control "  placeholder="Coupon code" required> <br>
-->
<a  href="<?php echo e(url('/en/checkout/')); ?>" class="btn w-100 bg-main ">Checkout</a>  <br><br>
<a  href="<?php echo e(url('/en')); ?>" class="btn w-100 btn-light border">Continue Shopping</a> <br><br>                                          

</div>
</div>


</div>


 
 
</div>
</div>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>


<script type="text/javascript">
$(document).ready(function(){
$(".update-cart").click(function (e) {  
e.preventDefault();

var ele = $(this);
 
$.ajax({
url: "<?php echo e(url('/update-cart')); ?>",
method: "patch",
data: {_token: '<?php echo e(csrf_token()); ?>', id: ele.attr("data-id"), quantity: ele.parents("tr").find(".quantity").val()},
success: function (response) {
window.location.reload();
}
});
});


$(".remove-from-cart").click(function (e) {
e.preventDefault();

var ele = $(this);

if(confirm("Do you want to delete this item ?")) {
$.ajax({
url: '<?php echo e(url('remove-from-cart')); ?>',
method: "DELETE",
data: {_token: '<?php echo e(csrf_token()); ?>', id: ele.attr("data-id")},
success: function (response) {
window.location.reload();
}
});
}
});

});


</script>



<script type="text/javascript">
 
 function get_total_price(price)
{
$.ajax({
url: "<?php echo e(url('/en/total_price')); ?>",
method: "get",
data: {
_token: '<?php echo e(csrf_token()); ?>',
price: price

},
success: function (response) {
$("#my_total").val(response + "KWD");

 //$("#divid").load(" #divid");
	//return response;
}

});        
 
}
 

function update_cart(elem,pro_price,factor,item_id)
{

 var ele = document.getElementById('qty_'+elem).value;
//alert(ele);
if(factor == 'minus'){
//	 alert('marwa');

	qq = (Number($("#qty_"+ elem).val()) - 1 > 1)?Number($("#qty_"+ elem).val()) - 1:1;
$.ajax({
url: "<?php echo e(url('/update_cart')); ?>/"+item_id+"/"+qq,
method: "get",



success: function (response) {
$(".my_total").html(response.data + "KWD");
//alert(response.data);
},error: function (response,u) {
//$(".my_total").html(response + "KWD");
	alert(u);

}

}); 
}else if(factor == 'plus'){
qq = Number($("#qty_"+ elem).val()) + 1 ;
	 $.ajax({
url: "<?php echo e(url('/update_cart')); ?>/"+item_id+"/"+qq,
method: "get",

success: function (response) {
$(".my_total").html(response.data + "KWD");
	//alert(response.data);

},error: function (response,u) {
//$(".my_total").html(response + "KWD");
	alert(u);

}

}); 
}else{}         
//calc_total_cost(elem,pro_price,factor);
$(".x_sub_total_price_"+elem).html(pro_price * qq + " KWD");
 //$("#total").load(location.href +"#total");

 //$("#total").load("#total > *");
}
 
 
 function calc_total_cost(elem,pro_price,factor)
{
	 
pro_price = pro_price;
if(factor == 'minus'){
qty = document.getElementById('qty_'+elem).value;
qty = (Number(qty) - 1 > 0)?Number(qty) - 1:1;
}else if(factor == 'plus'){
qty = document.getElementById('qty_'+elem).value;
qty = Number(qty) + 1;
}else{
	qty = 1;
}

/*
$.ajax({
url: "<?php echo e(url('/en/total_cost/qty')); ?>/" + qty+'/pro_price/'+pro_price+'/factor/'+factor , 
type: "POST",
data: {
_token: '<?php echo e(csrf_token()); ?>',
id: elem.value,
}, success: function (result) {
	//alert(result);
$(".x_sub_total_price_"+elem).html(result + "KWD");
get_total_price(result);
 
}});
*/
}
 
 
  
 
</script>


<!-- pg-body -->


<?php $__env->stopSection(); ?>

 
<?php echo $__env->make('layouts.front2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/bluezo11/kocart.easyshop-qa.com/resources/views/front/cart/cart.blade.php ENDPATH**/ ?>