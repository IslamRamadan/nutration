

<?php $__env->startSection('title'); ?>
    

    <?php echo app('translator')->get('site.contact_us'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<!-----start carousel --->
<div  class=" relative " >
    <img class="d-block w-100 h" src="<?php echo e(asset('front/img/s.jpg')); ?>" alt="1 slide">
    <div class="abs w-100">
        <h2>ا<?php echo app('translator')->get('site.contact_us'); ?>
        </h2>
        <a href=""><?php echo app('translator')->get('site.home'); ?></a>
        >>
        <a href=""><?php echo app('translator')->get('site.contact_us'); ?>
        </a>
    </div>
</div>
<!--- end head --->
<!--- -->
<div class="container-fluid  ">
    <div class="container  ">
        <br>
        <div class="row  bg-w">

            <div class="col-md-8 ">
                <h2> <?php echo app('translator')->get('site.contact_us'); ?>
                </h2>
                <p>
                    <?php echo app('translator')->get('site.happy'); ?>
                </p>


                    <?php echo Form::model("", ['route' => ['contacts.store'],
                      "method"=>"post"

                      ]); ?>

                    <?php echo e(csrf_field()); ?>

                    <div class="form-group row">
                        <label class="col-sm-3 col-form-label"><?php echo app('translator')->get('site.name'); ?></label>
                        <div class="col-sm-9">
                            <input type="text"  class="form-control" name="name"   placeholder="<?php echo app('translator')->get('site.name'); ?>" >
                        </div>
                    </div>
                    <br>
                    <div class="form-group row">
                        <label class="col-sm-3 col-form-label"><?php echo app('translator')->get('site.phone'); ?></label>
                        <div class="col-sm-9">
                            <input type="text"  class="form-control" name="phone"   placeholder="<?php echo app('translator')->get('site.phone'); ?>" >
                        </div>
                    </div>
                    <br>
                    <div class="form-group row">
                        <label class="col-sm-3 col-form-label"><?php echo app('translator')->get('site.email'); ?>
                        </label>
                        <div class="col-sm-9">
                            <input type="text"  class="form-control" name="email"   placeholder="<?php echo app('translator')->get('site.email'); ?>" >
                        </div>
                    </div>
                    <br>
                    <div class="form-group row">
                        <label class="col-sm-3 col-form-label"><?php echo app('translator')->get('site.comment'); ?></label>
                        <div class="col-sm-9">
                            <textarea  rows="3" name="comment"  class="form-control"  ></textarea>
                        </div>
                    </div>
                    <br>
                    <div class="form-group row">
                        <label class="col-sm-3 col-form-label"></label>
                        <div class="col-sm-9">
                            <button type="submit" class="btn bg-main" ><?php echo app('translator')->get('site.send'); ?></button>
                        </div>
                    </div>

                <?php echo Form::close(); ?>

            </div>
            <div class="col-md-4 border-right">
                <h3><?php echo app('translator')->get('site.phone'); ?></h3>
                <p><?php echo e($my_setting->contact_phone); ?></p>
                <p></p>
                <h3><?php echo app('translator')->get('site.address'); ?></h3>

                <?php if(Lang::locale()=='ar'): ?>
                    <p><?php echo e($my_setting->address); ?> </p>

                <?php else: ?>
                    <p><?php echo e($my_setting->address_en); ?> </p>


                <?php endif; ?>
                <h3><?php echo app('translator')->get('site.contact_us'); ?>
                </h3>
                <p><?php echo e($my_setting->contact_email); ?></p>
                <h3><?php echo app('translator')->get('site.follow_us'); ?></h3>
                <nav class="navbar navbar-expand pad-0 " >
                    <ul class="navbar-nav ">
                        <li class="nav-item "><a class="nav-link " href="<?php echo e($my_setting->insta_link); ?>" title="instagram"><i class="fab fa-instagram"></i>  </a></li>
                        <li class="nav-item "><a class="nav-link " href="<?php echo e($my_setting->tw_link); ?>" title="twitter"><i class="fab fa-twitter"></i>  </a></li>
                        <li class="nav-item "><a class="nav-link " href="<?php echo e($my_setting->fb_link); ?>" title="call us"><i class="fas fa-phone"></i>  </a></li>
                        <li class="nav-item "><a class="nav-link " href="<?php echo e($my_setting->yt_link); ?>" title="youtube"><i class="fab fa-youtube"></i>  </a></li>

                    </ul>

                </nav>

            </div>






        </div>
        <br><br>
        <div class="container" >
            <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d1781246.1045858918!2d48.657151504561746!3d29.311784251648273!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3fc5363fbeea51a1%3A0x74726bcd92d8edd2!2z2KfZhNmD2YjZitiq4oCO!5e0!3m2!1sar!2seg!4v1589595972634!5m2!1sar!2seg" class="col-12" height="450" frameborder="0" style="border:0;" allowfullscreen="" aria-hidden="false" tabindex="0"></iframe>
        </div>


    </div></div>
<!--- -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.front.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\prestige\untitled folder\resources\views/front/contact.blade.php ENDPATH**/ ?>