
<?php $__env->startSection('title'); ?>

    <?php echo app('translator')->get('site.terms_and_condition'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>


    <!-----start carousel --->
    <div  class=" relative " >
        <img class="d-block w-100 h" src="<?php echo e(asset('front/img/s.jpg')); ?>" alt="1 slide">
        <div class="abs w-100">
            <h2>    <?php echo app('translator')->get('site.terms_and_condition'); ?>
            </h2>
            <a href="">    <?php echo app('translator')->get('site.home'); ?>
            </a>
            >>
            <a href="">     <?php echo app('translator')->get('site.terms_and_condition'); ?>
            </a>
        </div>
    </div>
    <!--- end head --->
    <!--- -->
    <div class="container-fluid  ">
        <div class="container  ">
            <br>
            <div class="row  ">
                <h2  class="text-center col-12">    <?php echo app('translator')->get('site.terms_and_condition'); ?>

                    <hr>
                </h2>
                <?php if(Lang::locale()=='ar'): ?>
                    <p class="col-12">  <br>
                        <?php echo e($my_setting->strategy); ?>

                    </p>
                <?php else: ?>
                    <p class="col-12">  <br>
                        <?php echo e($my_setting->strategy_en); ?>

                    </p>

                <?php endif; ?>


                <br><br>

                <br><br>
            </div>
        </div></div>







<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.front.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\prestige\untitled folder\resources\views/front/terms.blade.php ENDPATH**/ ?>