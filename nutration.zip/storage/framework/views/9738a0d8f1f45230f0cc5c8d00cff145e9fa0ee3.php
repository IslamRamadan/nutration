<?php $__env->startSection('title'); ?>
<?php echo app('translator')->get("اضافة مشرف"); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('mo'); ?>
<?php echo $__env->make('flash::message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $role = app('App\Role'); ?>

    <?php $__env->startSection('ti'); ?>
    اضافة مشرف
<?php $__env->stopSection(); ?>

        <div class="box box-primary">




            <div class="box-header">

            </div><!-- end of box header -->
            <div class="box-body">




               <?php echo Form::model($model, ['route' => ['users.store'],
               "method"=>"post"

               ]); ?>





<?php
$roles = $role->pluck('display_name', 'id')->toArray();
?>

<div class="form-group">
    <label for="name">الاسم</label>
    <?php echo Form::text('name',null,[
    'class' => 'form-control'
 ]); ?>

</div>
<div class="form-group">
    <label for="email">الايميل</label>
    <?php echo Form::text('email',null,[
    'class' => 'form-control'
 ]); ?>

</div>
<div class="form-group">
    <label for="password">كلمة المرور</label>
    <?php echo Form::password('password',[
    'class' => 'form-control'
 ]); ?>

</div>
<div class="form-group">
    <label for="password_confirmation">تأكيد كلمة المرور</label>
    <?php echo Form::password('password_confirmation',[
    'class' => 'form-control'
 ]); ?>

</div>
<div class="form-group">
    <label for="roles_list">رتب المستخدمين</label>
    <?php echo Form::select('roles_list[]',$roles,null,[
    'class' => 'form-control select2',
    'multiple' => 'multiple',
 ]); ?>

</div>

<div class="form-group">
 <button class="btn btn-primary" type="submit"> حفظ</button>
</div>







             <?php echo Form::close (); ?>


            </div><!-- end of box body -->

        </div><!-- end of box -->












    

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard.app2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/bluezo11/kocart.easyshop-qa.com/resources/views//dashboard/users/create.blade.php ENDPATH**/ ?>