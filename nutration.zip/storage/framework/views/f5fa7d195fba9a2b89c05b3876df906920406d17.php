<?php $__env->startSection('title'); ?>
    <?php echo app('translator')->get("site.add_social"); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('mo'); ?>




<?php $__env->startSection('ti'); ?>
    <?php echo app('translator')->get("site.add_social"); ?>
<?php $__env->stopSection(); ?>


<div class="box box-primary">




    <div class="box-header">

    </div><!-- end of box header -->
    <div class="box-body">

        <?php echo $__env->make('partials._errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


        <?php echo Form::model("", ['route' => ['social.store'],
        "method"=>"post",'enctype' => 'multipart/form-data'

        ]); ?>

        <?php echo e(csrf_field()); ?>

        <div class="form-group">
            <input type="checkbox" class="form-check-input" name="appearance" value="1" id="exampleCheck1">
            <label class="form-check-label" for="exampleCheck1"><?php echo app('translator')->get('site.appear'); ?></label>
          </div>

        <div class="form-group">
            <label><?php echo app('translator')->get('site.link'); ?></label>
            <input type="text" name="link" class="form-control" value="<?php echo e(old('link')); ?>">
        </div>



        <div class="form-group">
            <label><?php echo app('translator')->get('site.image'); ?></label>
            <input type="file" name="photo" class="form-control" value="">
        </div>






        <div class="form-group">
            <button type="submit" class="btn btn-primary"><i class="fa fa-plus"></i> <?php echo app('translator')->get('site.add'); ?></button>
        </div>

        <?php echo Form::close(); ?>


    </div><!-- end of box body -->

</div><!-- end of box -->














<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

<script src="https://cdn.ckeditor.com/4.17.1/standard/ckeditor.js"></script>
<script>
    CKEDITOR.replace( 'description_ar' );
    CKEDITOR.replace( 'description_en' );



</script>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard.app2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\monaleza\Documents\nutration\resources\views//dashboard/socials/create.blade.php ENDPATH**/ ?>