<?php $__env->startSection('title'); ?>
<?php echo app('translator')->get("site.categories"); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('mo'); ?>
    



     <?php $__env->startSection('ti'); ?>
         منتجات نفذت كميتها
     <?php $__env->stopSection(); ?>


     <?php $slider = app('App\Models\Slider'); ?>
     <?php $brand = app('App\Models\Brand'); ?>
     <?php $cat = app('App\Models\Category'); ?>
     <?php $subcat = app('App\Models\SubCategory'); ?>
     <?php $subcat2 = app('App\Models\SubSubCategory'); ?>



    <div class="  " style="padding:10px">

<a style="margin-top:2px " href="<?php echo e(url(route("items.deactivate"))); ?>" class="btn btn-danger btn-sm"><?php echo app('translator')->get('جعل هذه المنتجات غير مفعلة'); ?></a>
		
		<a style="margin-top:2px " href="<?php echo e(url(route("items.activate"))); ?>" class="btn btn-success btn-sm"><?php echo app('translator')->get('جعل هذه المنتجات مفعلة'); ?></a>
    </div>


        <div class="box box-primary">



 

            <div class="box-body">


                <div class="table-responsive">
                    <table class="table table-hover table-bordered  ">

                        <thead>
                        <tr>
                            <th>#</th>
                            <th class="text-center"><?php echo app('translator')->get('المنتج '); ?></th>

                            <th class="text-center"><?php echo app('translator')->get('القسم '); ?></th>
                            <th class="text-center"><?php echo app('translator')->get('القسم الفرعي '); ?></th>
                            <th class="text-center"><?php echo app('translator')->get('التصنيف '); ?></th>
                            <th class="text-center"><?php echo app('translator')->get('الصورة '); ?></th>
                            <th class="text-center"><?php echo app('translator')->get('السعر'); ?></th>
                            <th class="text-center"><?php echo app('translator')->get('سعر الخصم'); ?></th>
                            <th class="text-center"><?php echo app('translator')->get('الحالة '); ?></th>

                            <th class="text-center"><?php echo app('translator')->get('الاجراءت'); ?></th>
                        </tr>
                        </thead>

                        <tbody>
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


                            <tr>
                                <td><?php echo e($loop->iteration); ?></td>
                                <td class="text-center"><?php echo e($category->name); ?></td>
                                <td class="text-center"><?php echo e($cat->find( $category->category_id)->name); ?></td>
                            <td class="text-center"><?php echo e($subcat->find( $category->subCategory_id)->name); ?></td>
                            <td class="text-center"><?php echo e($subcat2->find( $category->subSubCategory_id)->name); ?></td>
                            <td class="text-center"><img src="<?php echo e(asset($category->img)); ?>" alt="" width="90px" height="70px">  </td>
                            <td class="text-center"><?php echo e($category->price); ?>  د.ك</td>
                            <td class="text-center"><?php echo e($category->over_price); ?>  د.ك</td>

                            <td class="text-center"><?php echo e($category->activity==1?"مفعل":"معطل"); ?></td>


                                <td class="text-center">
  <?php if($category->type == 1): ?>
       <a style="margin-top:2px " href="<?php echo e(url(route("items.size",$category->id))); ?>" class="btn btn-success btn-sm"><i class="fa fa-list"></i> <?php echo app('translator')->get(''); ?></a>
									<?php endif; ?>

                                        <a style="margin-top:2px " href="<?php echo e(url(route("galaries.index",$category->id))); ?>" class="btn btn-info btn-sm"><i class="fa fa-image"></i> <?php echo app('translator')->get(''); ?></a>
                                        <a style="margin-top:2px " href="<?php echo e(url(route("items.edit",$category->id))); ?>" class="btn btn-primary btn-sm"><i class="fa fa-eye"></i> <?php echo app('translator')->get(''); ?></a>


                               
                                <form action="<?php echo e(url(route("items.destroy",$category->id))); ?>" method="post" style="display: inline-block">
                                    <?php echo e(csrf_field()); ?>

                                    <?php echo e(method_field('delete')); ?>

                                            <button style="margin-top:2px " type="submit" class="btn btn-danger delete  btn-sm"><i class="fa  fa-trash"></i> <?php echo app('translator')->get(''); ?></button>
                                        </form><!-- end of form -->

                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </tbody>

                    </table><!-- end of table -->
                </div>

                    <!-- Button trigger modal -->


            </div><!-- end of box body -->

            <?php if(count($categories)==0): ?>
            <div class="alert alert-danger"> لا يوجد بيانات
            </div>
             <?php endif; ?>









             <?php $__env->startPush('scripts'); ?>
             <script>
               
                 $("#category").change(function (e) {
                     e.preventDefault();
                     // get gov
                     // send ajax
                     // append records
                     $("#records").empty();
                     $("#records2").empty();
               
                     var category = $("#category").val();
                      
                     if (category)
                     {
                         $.ajax({
                             url : '<?php echo e(url('api/v1/subcats')); ?>',
                             type: 'post',
                             data: {_token:"<?php echo e(csrf_token()); ?>",category_id:category},
                             success: function (data) {
             
                                 if (data.state == 1)
                                 {
             
                                     $("#records").empty();
                                     $("#records").append('<option value="">اختر قسم فرعي</option>');
                                     $.each(data.data, function (index, city) {
                                         $("#records").append('<option value="'+city.id+'">'+city.name+'</option>');
                                     });
                                 }
                             },
                             error: function (jqXhr, textStatus, errorMessage) { // error callback
                                 alert(jqXhr);
                             }
                         });
                     }else{
                       //  $("#records").empty();
                         $("#records").append('<option value="">اختر قسم فرعي</option>');
                     }
                 });
                 ///////////////////////////////////////////////sub sub cats 

                 $("#records").change(function (e) {
                     e.preventDefault();
                     // get gov
                     // send ajax
                     // append records
                     $("#records2").empty();

               
                     var category = $("#records").val();
                      
                     if (category)
                     {
                         $.ajax({
                             url : '<?php echo e(url('api/v1/subcats2')); ?>',
                             type: 'post',
                             data: {_token:"<?php echo e(csrf_token()); ?>",category_id:category},
                             success: function (data) {
             
                                 if (data.state == 1)
                                 {
             
                                     $("#records2").empty();
                                     $("#records2").append('<option value="">اختر التصنيف</option>');
                                     $.each(data.data, function (index, city) {
                                         $("#records2").append('<option value="'+city.id+'">'+city.name+'</option>');
                                     });
                                 }
                             },
                             error: function (jqXhr, textStatus, errorMessage) { // error callback
                                 alert(jqXhr);
                             }
                         });
                     }else{
                       //  $("#records").empty();
                         $("#records2").append('<option value="">  اختر التصنيف</option>');
                     }
                 });
             </script>
             <?php $__env->stopPush(); ?>
  

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard.app2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/bluezo11/easyshop-qa.com/resources/views//dashboard/items/qut.blade.php ENDPATH**/ ?>