
<?php $__env->startSection('title','Account'); ?>
    <?php echo app('translator')->get(""); ?>
<?php $__env->startSection('content'); ?>

    <div class="container account" >
        <div class="row pad  ">
            <h1  class="col-12  text-center"><br>My Account</h1>
            <br>

            <form class=" col-12  border">
                <div class="row border-bottom pad-10">
                    <label class="col-md-3 col-12  "><b> name:</b></label>
                    <p class="  col-9 pad-0 "><?php echo e(Auth::guard('client')->user()->name); ?></p><br>
                </div>
                <div class="row border-bottom pad-10">
                    <label class="col-md-3 col-12 "> <b>Email</b></label>
                    <p class="  col-9 pad-0 "><?php echo e(Auth::guard('client')->user()->email); ?></p><br>
                </div>

                <div class="row border-bottom pad-10">
                    <label class="col-md-3 col-12  "><b> Phone Number</b></label>
                    <p class="  col-9 pad-0 "><?php echo e(Auth::guard('client')->user()->phone); ?></p><br>
                </div>

                <div class="  col-12 justify-content-center">
                                        <a href="<?php echo e(route('account.orders',Auth::guard('client')->user()->id)); ?>" class="btn bg-main mr-10 float-right">My orders</a>

                    <a href=" <?php echo e(route('wishlist.products.index')); ?>" class="btn bg-main mr-10  float-right"> my wishlist </a>
                    
                                        <a href="<?php echo e(route('address.index',Auth::guard('client')->user()->id)); ?>" class="btn bg-main mr-10  float-right"> address book</a>

                    
                    <br><br>
                </div>
            </form>
        </div></div>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\untitled folder\resources\views/front/account.blade.php ENDPATH**/ ?>