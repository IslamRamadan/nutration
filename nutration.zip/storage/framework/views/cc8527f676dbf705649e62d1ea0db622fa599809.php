

<?php $__env->startSection('title'); ?>
    <?php echo app('translator')->get("services"); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('mo'); ?>




<?php $__env->startSection('ti'); ?>
    <?php echo app('translator')->get("site.services"); ?>

<?php $__env->stopSection(); ?>
<div class="row">
    <?php if(Lang::locale()=='ar'): ?>
        <h1><?php echo e($service->name_ar); ?></h1>

    <?php else: ?>
        <h1><?php echo e($service->name_en); ?></h1>


    <?php endif; ?>

</div>
<div class="row">
    <div class="col-4 m-2">

        <?php $__currentLoopData = $service_images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service_image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            

            <img src="<?php echo e(asset('myfiles/'.$service_image->img)); ?>" alt="" width="500px" height="300px">
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </div>
</div>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard.app2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\monaleza\Documents\GitHub\Turk\resources\views/dashboard/categories/show.blade.php ENDPATH**/ ?>