<?php $__env->startSection('title'); ?>
    <?php echo app('translator')->get("site.edit_product"); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('mo'); ?>




<?php $__env->startSection('ti'); ?>
    <?php echo app('translator')->get("site.edit_product"); ?>
<?php $__env->stopSection(); ?>

<div class="box box-primary">




    <div class="box-header">

    </div><!-- end of box header -->
    <div class="box-body">

        <?php echo $__env->make('partials._errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


        <?php echo Form::model("", ['route' => ['products.update.product',$product->id],
        "method"=>"POST",'enctype' => 'multipart/form-data'

        ]); ?>

        <?php echo e(csrf_field()); ?>


        <div class="form-group">
            <input type="checkbox" class="form-check-input" name="appearance" value="1" id="exampleCheck1"
            <?php if($product->appearance == 1): ?>  <?php echo e('checked'); ?> <?php endif; ?>
            >
            <label class="form-check-label" for="exampleCheck1"><?php echo app('translator')->get('site.appear'); ?></label>
          </div>


        <div class="form-group">
            <label><?php echo app('translator')->get('site.title_ar'); ?></label>
            <input type="text" name="title_ar" class="form-control" value="<?php echo e($product->title_ar); ?>">
        </div>

        <div class="form-group">
            <label><?php echo app('translator')->get('site.title_en'); ?></label>
            <input type="text" name="title_en" class="form-control" value="<?php echo e($product->title_en); ?>">
        </div>

        <div class="form-group">
            <label><?php echo app('translator')->get('site.description_ar'); ?></label>
            <textarea type="text" name="description_ar" class="form-control">
                <?php echo e($product->description_ar); ?>

            </textarea>
        </div>

        <div class="form-group">
            <label><?php echo app('translator')->get('site.description_en'); ?></label>
            <textarea type="text" name="description_en" class="form-control" >
                <?php echo e($product->description_en); ?>

            </textarea>
        </div>



        <div class="form-group">
            <label><?php echo app('translator')->get('site.image'); ?></label>
            <input type="file" name="photo" class="form-control" >
        </div>
        <input type="hidden" name="sections" value="<?php echo e(count($sections)); ?>">
        <?php if(count($sections)>0): ?>
            <?php $__currentLoopData = $sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <h3 class="text-center">فقره </h3>
            <div class="form-group">
                <label>مجتوي الفقره بالعربيه</label>
                <textarea type="text" name="description_ar1[]" class="form-control" rows="10">
                    <?php echo e($section->description_ar); ?>

                </textarea>
            </div>

            <div class="form-group">
                <label>محتوي الفقره بالانجليزيه</label>
                <textarea type="text" name="description_en1[]" class="form-control" rows="10">
                    <?php echo e($section->description_en); ?>

                </textarea>
            </div>


            <div class="form-group">
                <label>الصوره</label>
                <input type="file" name="photo1[]" class="form-control" value="">
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>


        <div id="section">

        </div>


        <div class="form-group text-center">
            <button type="button" id="add_section" class="btn btn-success"><i class="fa fa-plus"></i> <?php echo app('translator')->get('site.add_section'); ?></button>
        </div>


        <div class="form-group">
            <button type="submit" class="btn btn-primary"><i class="fa fa-plus"></i> <?php echo app('translator')->get('site.edit'); ?></button>
        </div>

        <?php echo Form::close(); ?>


    </div><!-- end of box body -->

</div><!-- end of box -->












<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

<script src="https://cdn.ckeditor.com/4.17.1/standard/ckeditor.js"></script>
<script>
    CKEDITOR.replace( 'description_ar' );
    CKEDITOR.replace( 'description_en' );
    $("#add_section").click(function (e) {
            e.preventDefault();
            // get gov
            // send ajax



                $.ajax({
                    url : "<?php echo e(route('add.section')); ?>",
                    type: 'post',
                    data: {_token:"<?php echo e(csrf_token()); ?>",type:2},
                    success: function (data) {
                        console.log(data);
                        $("#section").append(data);
                    },
                    error: function (jqXhr, textStatus, errorMessage) { // error callback
                        alert(jqXhr);
                    }
                });

        });
</script>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard.app2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\monaleza\Documents\GitHub\Turk\resources\views//dashboard/products/edit.blade.php ENDPATH**/ ?>