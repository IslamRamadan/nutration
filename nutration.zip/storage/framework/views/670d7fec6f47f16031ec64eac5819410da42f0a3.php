
<?php $__env->startSection('title'); ?>
<?php echo app('translator')->get("اضافة سليدر"); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('mo'); ?>
    



     <?php $__env->startSection('ti'); ?>
       اضافة سليدر
     <?php $__env->stopSection(); ?>

        <div class="box box-primary">




            <div class="box-header">

            </div><!-- end of box header -->
            <div class="box-body">

               <?php echo $__env->make('partials._errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 


                  <?php echo Form::model("", ['route' => ['sliders.store'],
                  "method"=>"post",'enctype' => 'multipart/form-data'

                  ]); ?>

                    <?php echo e(csrf_field()); ?>


                    <div class="form-group">
                        <label><?php echo app('translator')->get('اسم السليدر '); ?></label>
                        <input type="text" name="text" class="form-control" value="">
                    </div>


                    <div class="form-group">
                        <label><?php echo app('translator')->get('الصورة '); ?></label>
                        <input type="file" name="photo" class="form-control" value="">
                    </div>

                

                      

                        <div class="form-group">
                            <label><?php echo app('translator')->get('الحالة'); ?></label>
                            <select style="width:100%"  name="activity" class="form-control " >
                            <option  value="1">مفعلة</option>
                            <option value="0">معطلة</option>
                            
                        </select>
                        </div>

                       
                        <div class="form-group">
                            <label><?php echo app('translator')->get('ترتيب الظهور'); ?></label>
                            <input value="" type="number" name="num" class="form-control" value="">
                        </div>


                    <div class="form-group">
                        <button type="submit" class="btn btn-primary"><i class="fa fa-plus"></i> <?php echo app('translator')->get('site.add'); ?></button>
                    </div>

                    <?php echo Form::close(); ?>


            </div><!-- end of box body -->

        </div><!-- end of box -->












<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard.app2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/bluezo11/easyshop-qa.com/resources/views//dashboard/sliders/create.blade.php ENDPATH**/ ?>