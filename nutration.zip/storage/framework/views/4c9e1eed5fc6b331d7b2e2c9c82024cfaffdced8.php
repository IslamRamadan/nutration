<html >
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="<?php echo e(asset('front/css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('front/css/all.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('front/css/animate.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('front/css/main-style.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('front/css/media.css')); ?>">
    <!-- slick css-->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('front/css/slick.css')); ?>"/>
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('front/css/slick-theme.css')); ?>"/>
    <title><?php echo $__env->yieldContent('title'); ?></title>
</head>

    <?php if(Lang::locale()=='ar'): ?>
        <body class="arabic">

        <?php else: ?>
            <body class="english">


<?php endif; ?>
<div class="container-fluid pad-0 bg-main  ">
    <div class="container  ">
        <div class="float-left">
            <nav class="navbar navbar-expand pad-0 " >
                <ul class="navbar-nav  pad-0">

                    <li class="nav-item ">
                        <a href="#" title="" class="nav-link "> <i class="fas fa-phone"></i>  <?php echo e($my_setting->contact_phone); ?></a></li>
                    <li class="nav-item ">
                        <a href="#" title="" class="nav-link "> <i class="fab fa-whatsapp"></i>  <?php echo e($my_setting->wats); ?></a>
                    </li></ul>
            </nav>
        </div>
        <div class="float-right text-right">
            <nav class="navbar navbar-expand pad-0 " >
                <ul class="navbar-nav pad-0">

                    <li class="nav-item "><a class="nav-link " href="<?php echo e($my_setting->insta_link); ?>" title="instagram"><i class="fab fa-instagram"></i>  </a></li>
                    <li class="nav-item "><a class="nav-link " href="<?php echo e($my_setting->tw_link); ?>" title="twitter"><i class="fab fa-twitter"></i>  </a></li>
                    <li class="nav-item "><a class="nav-link " href="<?php echo e($my_setting->fb_link); ?>" title="call us"><i class="fas fa-phone"></i>  </a></li>
                    <li class="nav-item "><a class="nav-link " href="<?php echo e($my_setting->yt_link); ?>" title="youtube"><i class="fab fa-youtube"></i>  </a></li>

                </ul>


            </nav>
        </div>
        <div class="clearfix"></div>
    </div></div>

<!--- -->
<div class="container-fluid  border-main sticky-top bg-w">
    <div class="container  ">
        <div class="row  ">
            <nav class="navbar navbar-expand-lg col-12" id="start">
                <a  href="<?php echo e(route('home.index')); ?>">
                    <img src="<?php echo e(asset('front/img/logo.png')); ?>"  class="logo" >
                </a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                    <i class=" fas fa-bars c-b"></i>
                </button>
                <div class="collapse navbar-collapse " id="navbarSupportedContent">
                    <ul class="navbar-nav mr-right pad-0">
                        <li class="nav-item "><a class="nav-link active" href="<?php echo e(route('home.index')); ?>"><?php echo app('translator')->get('site.home'); ?></a></li>
                        <li class="nav-item">
                            <div class="dropdown nav-link" >
                                <div class=" dropdown-toggle"  id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    <?php echo app('translator')->get('site.services'); ?>
                                </div>
                                <div class="dropdown-menu text-right" aria-labelledby="dropdownMenuButton" >
                                    <?php $__currentLoopData = $my_sevices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $my_sevice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if(Lang::locale()=='ar'): ?>
                                            <a class="dropdown-item" href="<?php echo e(route('my_services.show',$my_sevice->id)); ?>"><?php echo e($my_sevice->name_ar); ?></a>

                                        <?php else: ?>
                                            <a class="dropdown-item" href="<?php echo e(route('my_services.show',$my_sevice->id)); ?>"><?php echo e($my_sevice->name_en); ?></a>


                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </div>
                            </div>
                        </li>

                        <li class="nav-item">
                            <div class="dropdown nav-link" >
                                <div class=" dropdown-toggle"  id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    <?php echo app('translator')->get('site.our_works'); ?>
                                </div>
                                <div class="dropdown-menu text-right" aria-labelledby="dropdownMenuButton" >
                                    <?php $__currentLoopData = $my_projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $my_project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if(Lang::locale()=='ar'): ?>
                                            <a class="dropdown-item" href="<?php echo e(route('my_projects.show',$my_project->id)); ?>"><?php echo e($my_project->name_ar); ?></a>

                                        <?php else: ?>
                                            <a class="dropdown-item" href="<?php echo e(route('my_projects.show',$my_project->id)); ?>"><?php echo e($my_project->name_en); ?></a>


                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </div>
                            </div>
                        </li>

                        <li class="nav-item "><a class="nav-link " href="<?php echo e(route('post.index')); ?>" ><?php echo app('translator')->get('site.blog'); ?></a></li>
                        <li class="nav-item "><a class="nav-link " href="<?php echo e(route('about.index')); ?>" ><?php echo app('translator')->get('site.about_us'); ?></a></li>
                        <li class="nav-item">
                            <div class="dropdown nav-link" >
                                <div class=" dropdown-toggle"  id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    <?php echo app('translator')->get('site.our_plans'); ?>
                                </div>
                                <div class="dropdown-menu text-right" aria-labelledby="dropdownMenuButton" >
                                    <?php $__currentLoopData = $my_plans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $my_plan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if(Lang::locale()=='ar'): ?>
                                            <a class="dropdown-item" href="<?php echo e(route('my_plans.show',$my_plan->id)); ?>"><?php echo e($my_plan->name_ar); ?></a>

                                        <?php else: ?>
                                            <a class="dropdown-item" href="<?php echo e(route('my_plans.show',$my_plan->id)); ?>"><?php echo e($my_plan->name_en); ?></a>


                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </div>
                            </div>
                        </li>

                        <li class="nav-item"><a class="nav-link " href="<?php echo e(route('contacts.index')); ?>" ><?php echo app('translator')->get('site.contact_us'); ?></a></li>

                        <li class="nav-item">
                            <div class="dropdown nav-link" >
                                <div class=" dropdown-toggle"  id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">



                                    <?php if(Lang::locale()=='ar'): ?>
                                        <img src="<?php echo e(asset('front/img/kuwait.png')); ?>" width="20">  العربيه

                                    <?php else: ?>
                                        <img src="<?php echo e(asset('front/img/en.png')); ?>" width="20">  English


                                    <?php endif; ?>
                                </div>
                                <div class="dropdown-menu  text-right" aria-labelledby="dropdownMenuButton" >

                                        <?php $__currentLoopData = LaravelLocalization::getSupportedLocales(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $localeCode => $properties): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                <a style="color: red" class="dropdown-item" rel="alternate" hreflang="<?php echo e($localeCode); ?>" href="<?php echo e(LaravelLocalization::getLocalizedURL($localeCode, null, [], true)); ?>">
                                                    <?php echo e($properties['native']); ?>

                                                </a>

                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </div>
                            </div>
                        </li>

                    </ul>

                </div>
            </nav>
        </div>
    </div>

</div><?php /**PATH C:\xampp\htdocs\prestige\untitled folder\resources\views/layouts/front/header.blade.php ENDPATH**/ ?>