<?php $__env->startSection('title'); ?>
    <?php echo app('translator')->get("site.social"); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('mo'); ?>




<?php $__env->startSection('ti'); ?>
    <?php echo app('translator')->get("site.social"); ?>
<?php $__env->stopSection(); ?>



<div class="  " style="padding:10px">

    <a href="<?php echo e(route('social.create')); ?>" class="btn btn-primary"><i class="fa fa-plus"></i> <?php echo app('translator')->get("site.new"); ?></a>

</div>


<div class="box box-primary">







    <div class="box-body">


        <div class="table-responsive">
            <table class="table table-hover table-bordered  ">

                <thead>
                <tr>
                    <th>#</th>

                    <th class="text-center"><?php echo app('translator')->get('site.link'); ?></th>

                    <th class="text-center"><?php echo app('translator')->get('site.image'); ?></th>

                    <th class="text-center"><?php echo app('translator')->get('site.Procedures'); ?></th>
                </tr>
                </thead>

                <tbody>
                <?php $__currentLoopData = $socials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $social): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


                    <tr>
                        <td><?php echo e($loop->iteration); ?></td>
                        <td class="text-center"><?php echo e($social->link); ?></td>
                        <td class="text-center"><img src="<?php echo e(asset('/storage/'.$social->img)); ?>" alt="" width="90px" height="70px">  </td>


                        <td class="text-center">

                            <a href="<?php echo e(url(route("social.edit",$social->id))); ?>" class="btn btn-info btn-sm"><i class="fa fa-edit"></i> <?php echo app('translator')->get('site.edit'); ?></a>


                            <form action="<?php echo e(url(route("social.destroy",$social->id))); ?>" method="post" style="display: inline-block">
                                <?php echo e(csrf_field()); ?>

                                <?php echo e(method_field('delete')); ?>

                                <button type="submit" class="btn btn-danger delete  btn-sm"><i class="fa  fa-trash"></i> <?php echo app('translator')->get('site.delete'); ?></button>
                            </form><!-- end of form -->

                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </tbody>

            </table><!-- end of table -->
        </div>

    <?php echo e($socials->appends(request()->query())->links()); ?>

    <!-- Button trigger modal -->


    </div><!-- end of box body -->

    <?php if(count($socials)==0): ?>

        <div class="alert alert-danger"><?php echo app('translator')->get('site.no_data'); ?>
        </div>
    <?php endif; ?>













</div>












<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.dashboard.app2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\monaleza\Documents\nutration\resources\views//dashboard/socials/index.blade.php ENDPATH**/ ?>