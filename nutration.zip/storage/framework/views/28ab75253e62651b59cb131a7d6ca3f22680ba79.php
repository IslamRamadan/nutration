 
<?php $__env->startSection('title', 'Register'); ?>

<?php $__env->startSection('content'); ?>
 

<!--- --->
<br><br>

<div class="sign w-50 text-center shadow pad-10">
<br>

<h1>Create new customer account</h1>
<h6><b>Personal Information</b></h6>
<?php if(Session::has('success-reg')): ?>
    <div class="alert alert-success">
        <ul>
            <li><?php echo \Session::get('success-reg'); ?></li>
        </ul>
    </div>
<?php endif; ?>
<?php if($errors->any() && (Session::has('test') || !empty(Session::get('fail-reg')) )): ?>
    <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>
<div id="error_message"></div>



    <?php if(isset($url)): ?>
    <form method="POST" action='<?php echo e(url("register/$url")); ?>' aria-label="<?php echo e(__('Register')); ?>">
    <?php else: ?>
    <form method="POST" action="<?php echo e(route('register')); ?>" aria-label="<?php echo e(__('Register')); ?>">
    <?php endif; ?>
    <?php echo csrf_field(); ?>
    <input placeholder="Name " name="name" class="w-100 " type="text">
    <input placeholder="Email " name="email" class="w-100 " type="email">
<input placeholder="Password " name="password" class="w-100" minlength="6" type="password">

    <input placeholder="Phone Number " name="phone" class="w-100 " type="text"><br>

<button type="submit" class="btn w-100 btn-dark bg-main">register </button><br><br>
</form>
<p>Already have an account <a href="<?php echo e(url('/en/login')); ?>" class="main-color">login</a></p>


<br>

</div>
<br><br>


 <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\kokart\resources\views/front/register.blade.php ENDPATH**/ ?>