<?php $__env->startSection('title'); ?>
    <?php echo app('translator')->get('site.home'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div id="carouselExampleIndicators" class="carousel slide relative" data-ride="carousel">
        <ol class="carousel-indicators">
            <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
            <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
            <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
        </ol>
        <div class="carousel-inner">
            <?php
                $i = 0;
            ?>
            <?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $one): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="carousel-item  <?php if($i == 0): ?> active <?php endif; ?> ">
                    <img class=" w-100  " src="<?php echo e(asset($one->img)); ?>" alt="1 slide">

                </div>
                <?php
                    $i++;
                ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


        </div>
        <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
            <span class="carousel-control-prev-icon " aria-hidden="true"></span>
            <span class="sr-only">Previous</span>
        </a>
        <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="sr-only">Next</span>
        </a>
    </div>
    <!--- end head --->
    <!--- -->

    <div class="container text-center center-p">

        <h1><?php echo app('translator')->get('site.about'); ?></h1>
        

    </div>




    <div class="container-fluid">

        <div class="row">

            <div class="col-lg-6 col-md-6 col-sm-12 ">
                <div class="">
                    
                    <img src="<?php echo e(url('/storage/'.$section->about_img)); ?>" alt="" class="w-100">

                </div>

            </div>
            <div class="col-lg-6 col-md-6 col-sm-12 sm-m">
                <?php echo $section['about_content_'.app()->getLocale()]; ?>

            </div>


        </div>
    </div>
    <div class="container text-center center-p">

        <h1><?php echo app('translator')->get('site.services'); ?></h1>
        


    </div>




    <div class="container-fluid">

        <div class="row">

            <div class="col-lg-6 col-md-6 col-sm-12 ">
                <div class="">
                    
                    <img src="<?php echo e(url('/storage/'.$section->service_img)); ?>" alt="" class="w-100">

                </div>

            </div>
            <div class="col-lg-6 col-md-6 col-sm-12 sm-m">

                             <?php echo $section['service_content_'.app()->getLocale()]; ?>


            </div>


        </div>
    </div>

<?php if(count($social)>0): ?>

    <div class="container text-center center-p">

        <h1><?php echo app('translator')->get('site.social'); ?></h1>
        
    </div>
    <div class="container-fluid mb-3">
        
        <div class="swiper mySwiper">
            <div class="swiper-wrapper">
               <?php $__currentLoopData = $social; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <div class="swiper-slide">
                    <div class="swiper-img">
                        <a href="<?php echo e($item->link); ?>" target="_blank">
                            <img src="<?php echo e(url('/storage/'.$item->img)); ?>" />
                        </a>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <div class="swiper-pagination"></div>
            </div>
        </div>
        
    </div>
<?php endif; ?>

<?php $__env->stopSection(); ?>


<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>








































<script>
    // Get the modal
    var modal = document.getElementById("myModal");

    // Get the image and insert it inside the modal - use its "alt" text as a caption
    var img = document.getElementById("myImg");
    var modalImg = document.getElementById("img01");
    var captionText = document.getElementById("caption");
    img.onclick = function() {
        modal.style.display = "block";
        modalImg.src = this.src;
        captionText.innerHTML = this.alt;
    }

    // Get the <span> element that closes the modal
    var span = document.getElementsByClassName("close")[0];

    // When the user clicks on <span> (x), close the modal
    span.onclick = function() {
        modal.style.display = "none";
    }
</script>

<?php echo $__env->make('layouts.front.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\monaleza\Documents\nutration\resources\views/front/index.blade.php ENDPATH**/ ?>