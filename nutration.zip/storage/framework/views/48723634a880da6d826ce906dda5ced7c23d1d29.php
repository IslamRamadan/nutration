
<?php $__env->startSection('title', 'Login'); ?>
<style>
.form-control  {color:#fff !important}
</style>
<?php $__env->startSection('content'); ?>



<!--- --->
    <br><br>
<div class="sign w-50 text-center shadow pad-10">
  <br>
<h1>Customer Login</h1>
<h6><b>Registered customers</b></h6>
<p>If you have an account, sign in with your email address</p>
  <?php if(Session::has('fails')): ?>
    <div class="alert alert-danger">
        <ul>
            <li><?php echo \Session::get('fails'); ?></li>
        </ul>
    </div>
<?php endif; ?>
    <?php if(isset($url)): ?>
        <form method="POST" action='<?php echo e(url("login/$url")); ?>' aria-label="<?php echo e(__('Login')); ?>">
            <?php else: ?>
                <form method="POST" action="<?php echo e(route('login')); ?>" aria-label="<?php echo e(__('Login')); ?>">
                    <?php endif; ?>
                    <?php echo csrf_field(); ?>


<input placeholder="Email"  name="email" class="w-100 " type="email">
<input placeholder="Password " name="password" class="w-100" minlength="6" type="password">
<button type="submit" class="btn w-100 btn-dark bg-main">Login </button><br><br>
<a href="#" class="main-color" data-toggle="modal" data-target="#login">Forget password?</a><br><br>
<p>Do not have account yet <a href="<?php echo e(route('register/client')); ?>" class="main-color">Creat one</a></p>

</form>
  <br>
</div>
  <br><br>

    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\untitled folder\resources\views/front/login.blade.php ENDPATH**/ ?>