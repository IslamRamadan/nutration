
<?php $__env->startSection('title'); ?>
    <?php echo app('translator')->get("site.add_rank"); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('mo'); ?>
<?php echo $__env->make('flash::message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $model = app('App\Role'); ?>
<?php $perm = app('App\Permission'); ?>
    <?php $__env->startSection('ti'); ?>
    <?php echo app('translator')->get("site.add_rank"); ?>
<?php $__env->stopSection(); ?>


        <div class="box box-primary">




            <div class="box-header">

            </div><!-- end of box header -->
            <div class="box-body">




               <?php echo Form::model($model, ['route' => ['roles.store'],
               "method"=>"post"

               ]); ?>




<div class="form-group">
 <label for="name"><?php echo app('translator')->get("site.name"); ?>
</label>
 <?php echo Form::text('name',null,[
 'class' => 'form-control'
]); ?>

</div>
<div class="form-group">
 <label for="display_name"><?php echo app('translator')->get("site.display_name"); ?></label>
 <?php echo Form::text('display_name',null,[
 'class' => 'form-control'
]); ?>

</div>
<div class="form-group">
 <label for="description"><?php echo app('translator')->get("site.description"); ?></label>
 <?php echo Form::textarea('description',null,[
 'class' => 'form-control'
]); ?>

</div>
<div class="form-group">
 <label for="name"><?php echo app('translator')->get("site.permissions"); ?></label><br>
 <input id="select-all" type="checkbox">  <label for='select-all'> <?php echo app('translator')->get("site.select_all"); ?>  </label>
 <br>
 <div class="row">
     <?php $__currentLoopData = $perm->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
         <div class="col-sm-3">
             <div class="checkbox">
                 <label>
                     <input type="checkbox" name="permissions_list[]" value="<?php echo e($permission->id); ?>"
                     <?php if($model->hasPermission($permission->name)): ?>
                         checked
                     <?php endif; ?>
                     >
                     <?php echo e($permission->display_name); ?>

                 </label>
             </div>
         </div>
     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
 </div>
</div>
<div class="form-group">
 <button class="btn btn-primary" type="submit"> <?php echo app('translator')->get("site.save"); ?></button>
</div>


<?php $__env->startPush('scripts'); ?>
 <script>
     $("#select-all").click(function(){
         $("input[type=checkbox]").prop('checked', $(this).prop('checked'));
     });

 </script>
<?php $__env->stopPush(); ?>




             <?php echo Form::close (); ?>


            </div><!-- end of box body -->

        </div><!-- end of box -->





     






   

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard.app2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\monaleza\Documents\GitHub\Turk\resources\views//dashboard/roles/create.blade.php ENDPATH**/ ?>