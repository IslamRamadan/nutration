<?php $__env->startSection('mo'); ?>
    
<?php $SubCategory = app('App\Models\SubCategory'); ?>
<?php $SubSubCategory = app('App\Models\SubSubCategory'); ?>
<?php $Order = app('App\Models\Order'); ?>
<?php $Order = app('App\Models\Order'); ?>
<?php $Category = app('App\Models\Category'); ?>

<?php $Govern = app('App\Models\Govern'); ?>
<?php $Item = app('App\Models\Item'); ?>
<?php $Brand = app('App\Models\Brand'); ?>
<?php $Slider = app('App\Models\Slider'); ?>

<?php $User = app('App\User'); ?>
<?php $Role = app('App\Role'); ?>


     <?php $__env->startSection('ti'); ?>
         الرئيسية
     <?php $__env->stopSection(); ?>



        <div class="box box-primary">





            <section class="content" style="background: #ECF0F5">
                <!-- Info boxes -->
                <div class="row">
                <div class="col-md-3 col-sm-6 col-xs-12">
                    <div class="info-box">
                      <span class="info-box-icon bg-aqua"><i class="fa fa-heart"></i></span>
                      <div class="info-box-content">
                        <span class="info-box-text">الطلبات</span>
                      <span class="info-box-number"><small><?php echo e($Order->count()); ?></small></span>
                      </div><!-- /.info-box-content -->
                    </div><!-- /.info-box -->
                  </div><!-- /.col -->


                  <div class="col-md-3 col-sm-6 col-xs-12">
                    <div class="info-box">
                      <span class="info-box-icon bg-red"><i class="fa fa-list"></i></span>
                      <div class="info-box-content">
                        <span class="info-box-text">المنتجات</span>
                        <span class="info-box-number"><?php echo e($Item->count()); ?></span>
                      </div><!-- /.info-box-content -->
                    </div><!-- /.info-box -->
                  </div><!-- /.col -->

                  <!-- fix for small devices only -->
                  <div class="clearfix visible-sm-block"></div>

                

                  <div class="col-md-3 col-sm-6 col-xs-12">
                    <div class="info-box">
                      <span class="info-box-icon bg-yellow"><i class="fa fa-list"></i></span>
                      <div class="info-box-content">
                        <span class="info-box-text">التجار</span>
                        <span class="info-box-number"><?php echo e($Category->count()); ?></span>
                      </div><!-- /.info-box-content -->
                    </div><!-- /.info-box -->
                  </div><!-- /.col -->


                  <div class="col-md-3 col-sm-6 col-xs-12">
                    <div class="info-box">
                      <span class="info-box-icon  bg-aqua"><i class="fa fa-list"></i></span>
                      <div class="info-box-content">
                        <span class="info-box-text"> الاقسام </span>
                        <span class="info-box-number"><?php echo e($SubCategory->count()); ?></span>
                      </div><!-- /.info-box-content -->
                    </div><!-- /.info-box -->
                  </div><!-- /.col -->

                  <div class="col-md-3 col-sm-6 col-xs-12">
                    <div class="info-box">
                      <span class="info-box-icon  bg-yellow"><i class="fa fa-list"></i></span>
                      <div class="info-box-content">
                        <span class="info-box-text"> الماركات</span>
                        <span class="info-box-number"><?php echo e($Brand->count()); ?></span>
                      </div><!-- /.info-box-content -->
                    </div><!-- /.info-box -->
                  </div><!-- /.col -->


                  <div class="col-md-3 col-sm-6 col-xs-12">
                    <div class="info-box">
                      <span class="info-box-icon  bg-aqua"><i class="fa fa-list"></i></span>
                      <div class="info-box-content">
                        <span class="info-box-text">السليدر</span>
                        <span class="info-box-number"><?php echo e($Slider->count()); ?></span>
                      </div><!-- /.info-box-content -->
                    </div><!-- /.info-box -->
                  </div><!-- /.col -->



              



              



                  <div class="col-md-3 col-sm-6 col-xs-12">
                    <div class="info-box">
                      <span class="info-box-icon bg-yellow"><i class="fa fa-cogs"></i></span>
                      <div class="info-box-content">
                        <span class="info-box-text">الاقسام الفرعية</span>
                        <span class="info-box-number"><?php echo e($SubSubCategory->count()); ?></span>
                      </div><!-- /.info-box-content -->
                    </div><!-- /.info-box -->
                  </div><!-- /.col -->




                  <div class="col-md-3 col-sm-6 col-xs-12">
                    <div class="info-box">
                      <span class="info-box-icon bg-red"><i class="fa fa-users"></i></span>
                      <div class="info-box-content">
                        <span class="info-box-text">المشرفين</span>
                        <span class="info-box-number"><?php echo e($User->count()); ?></span>
                      </div><!-- /.info-box-content -->
                    </div><!-- /.info-box -->
                  </div><!-- /.col -->


                  <div class="col-md-3 col-sm-6 col-xs-12">
                    <div class="info-box">
                      <span class="info-box-icon bg-green"><i class="fa fa-list"></i></span>
                      <div class="info-box-content">
                        <span class="info-box-text">رتب المشرفين</span>
                        <span class="info-box-number"><?php echo e($Role->count()); ?></span>
                      </div><!-- /.info-box-content -->
                    </div><!-- /.info-box -->
                  </div><!-- /.col -->



                  <div class="col-md-3 col-sm-6 col-xs-12">
                    <div class="info-box">
                      <span class="info-box-icon bg-green"><i class="fa fa-flag"></i></span>
                      <div class="info-box-content">
                        <span class="info-box-text"> المحافظات</span>
                        <span class="info-box-number"><?php echo e($Govern->count()); ?></span>
                      </div><!-- /.info-box-content -->
                    </div><!-- /.info-box -->
                  </div><!-- /.col -->





                </div><!-- /.row -->
              </section><!-- /.content -->


              <div class="row">


                <div class="col-md-12">
                    <!-- LINE CHART -->
                    <div class="box box-info">
                      <div class="box-header with-border">
                        <h3 class="box-title">احصائيات الطلبات </h3>
                        <div class="box-tools pull-right">
                          <button class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i></button>
                          <button class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button>
                        </div>
                      </div>
                      <div class="box-body chart-responsive">
                        <div class="box-body border-radius-none">
                          <div id="chartContainer" style="height: 300px; width: 100%;"></div>

                        </div>
                      </div><!-- /.box-body -->
                    </div><!-- /.box -->
                   </div>





            </div>
		


<br>
            <div class="row">


              <div class="col-md-12">
                <div class="box-header with-border">
                  <h3 class="box-title">اخر الطلبات </h3>
                  <div class="box-tools pull-right">
                    <button class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i></button>
                    <button class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button>
                  </div>
                </div>
                <div class="box-body">

     <div class="table-responsive">
                    <table class="table table-hover table-bordered  ">

                        <thead>
                        <tr>
                            <th>#</th>
                            <th class="text-center"><?php echo app('translator')->get('الكود'); ?></th>
                            <th class="text-center"><?php echo app('translator')->get('المبلغ'); ?></th>
                            <th class="text-center"><?php echo app('translator')->get('الهاتف'); ?></th>
                            <th class="text-center"><?php echo app('translator')->get('المحافظة'); ?></th>
                            <th class="text-center"><?php echo app('translator')->get('المدينة'); ?></th>
                            <th class="text-center"><?php echo app('translator')->get('العنوان'); ?></th>
                            <th class="text-center"><?php echo app('translator')->get('التاريخ'); ?></th>
                            <th class="text-center"><?php echo app('translator')->get('حالة الطلب'); ?></th>

                            <th class="text-center"><?php echo app('translator')->get('الاجراءت'); ?></th>
                        </tr>
                        </thead>

                        <tbody>
                            <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


                            <tr>
                                <td><?php echo e($loop->iteration); ?></td>
                            <td class="text-center"><?php echo e($category->id); ?></td>
                            <td class="text-center"><?php echo e($category->price); ?>  <?php echo e($my_setting->currency); ?> </td>
                            <td class="text-center"><?php echo e($category->phone); ?></td>
                            <td class="text-center"><?php echo e($category->govern); ?></td>
                            <td class="text-center"><?php echo e($category->city); ?></td>
                            <td class="text-center"><?php echo e($category->address); ?></td>
                            <td class="text-center"><?php echo e($category->created_at); ?></td>
                            <?php if($category->status==1): ?>
                            <td class="text-center"> <div class="alert alert-info">جاري الشحن</div></td>
                            <?php elseif($category->status==2): ?>
                            <td class="text-center"> <div class="alert alert-danger">تم الشحن</div></td>

                            <?php elseif($category->status==3): ?>
                            <td class="text-center"> <div class="alert alert-success">تم الاستلام </div></td>
                             <?php elseif($category->status==4): ?>
                            <td class="text-center"> <div class="alert alert-danger">تم الالغاء</div></td>
                            <?php else: ?>
                            <td class="text-center"> </td>

                              <?php endif; ?>


                           


                                <td class="text-center">
                           <?php if($category->status!=4): ?>
                                        <a href="<?php echo e(url(route("orders.get_cancel",$category->id))); ?>" class="btn btn-primary btn-sm"><i class="fa fa-close"></i> <?php echo app('translator')->get(''); ?></a>
									<?php endif; ?>
									 <a href="<?php echo e(url(route("orders.edit",$category->id))); ?>" class="btn btn-primary btn-sm"><i class="fa fa-edit"></i> <?php echo app('translator')->get(''); ?></a>
									
                                        <a href="<?php echo e(url(route("order.item",$category->id))); ?>" class="btn btn-success btn-sm"><i class="fa fa-eye"></i> <?php echo app('translator')->get(''); ?></a>

                               
                                <form action="<?php echo e(url(route("orders.destroy",$category->id))); ?>" method="post" style="display: inline-block">
                                    <?php echo e(csrf_field()); ?>

                                    <?php echo e(method_field('delete')); ?>

                                            <button type="submit" class="btn btn-danger delete  btn-sm"><i class="fa  fa-trash"></i> <?php echo app('translator')->get(''); ?></button>
                                        </form><!-- end of form -->

                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </tbody>

                    </table><!-- end of table -->
                </div>
                    
                      <!-- Button trigger modal -->
  
  
              </div><!-- end of box body -->
                 
                 </div>





          </div>



           
              </div><!-- end of box body -->




    
          




<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
<script src="https://canvasjs.com/assets/script/canvasjs.min.js"></script>
<script>
  window.onload = function () {
  
  var chart = new CanvasJS.Chart("chartContainer", {
    animationEnabled: true,
   
    axisX:{
      valueFormatString: "DD MMM"
    },
    axisY: {
      title: "عدد الطلبات",
      scaleBreaks: {
        autoCalculate: true
      }
    },
    data: [{
		type: "line",
		xValueFormatString: "DD MMM",
		color: "#F08080",
		dataPoints: [
      <?php $__currentLoopData = $records; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $record): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			{ x: new Date(<?php echo e($record->year); ?>, 0, <?php echo e($record->month); ?>), y: <?php echo e($record->count); ?> },
     

      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		
		]
	}]
});
  chart.render();
  
  }
  //<?php $__currentLoopData = $records; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $record): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
         

// { x: new Date("<?php echo e($record->year); ?>", 0, "<?php echo e($record->month); ?>"), y:"<?php echo e($record->count); ?>" },
 //<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </script>
  
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.dashboard.app2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\kokart\resources\views/dashboard/welcome.blade.php ENDPATH**/ ?>