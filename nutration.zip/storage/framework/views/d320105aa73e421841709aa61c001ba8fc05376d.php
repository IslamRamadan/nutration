<?php $__env->startSection('title'); ?>
    <?php echo app('translator')->get("site.sections"); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('mo'); ?>
    <?php echo $__env->make('flash::message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->startSection('ti'); ?>
    <?php echo app('translator')->get("site.sections"); ?>
<?php $__env->stopSection(); ?>


<div class="box box-primary">



    <div class="box-header with-border">





    </div><!-- end of box header -->



    <div class="box-body">

        <?php if($section): ?>
            <?php

            $id = $section->id;

            $service_content_ar = $section->service_content_ar;
            $service_content_en = $section->service_content_en;
            $about_content_en = $section->about_content_en;
            $about_content_ar = $section->about_content_ar;

            ?>

        <?php else: ?>
            <?php

            $id = '';
            $service_content_ar = '';
            $service_content_en = '';
            $about_content_en = '';
            $about_content_ar = '';

            ?>
        <?php endif; ?>
        <?php echo Form::model($section, ['route' => ['sections.update', $id], 'method' => 'post', 'enctype' => 'multipart/form-data']); ?>

        <?php echo e(csrf_field()); ?>


        <div class="form-group text-center">
            <h2><?php echo app('translator')->get('site.about_sec'); ?></h2>
        </div>
        <div class="form-group">
            <label><?php echo app('translator')->get('site.about_content_ar'); ?></label>
            <textarea class="form-control" name="about_content_ar">
                <?php echo e($about_content_ar); ?>

            </textarea>
        </div>

        <div class="form-group">
            <label><?php echo app('translator')->get('site.about_content_en'); ?></label>
            <textarea class="form-control" name="about_content_en">
                <?php echo e($about_content_en); ?>

            </textarea>
        </div>

        <div class="form-group">
            <label><?php echo app('translator')->get('site.about_img'); ?></label>
            <input type="file" class="form-control" name="about_img1">
        </div>
        

        <div class="form-group text-center">
            <h2><?php echo app('translator')->get('site.service_sec'); ?></h2>
        </div>
        <div class="form-group">
            <label><?php echo app('translator')->get('site.service_content_ar'); ?></label>
            <textarea class="form-control" name="service_content_ar">
                <?php echo e($service_content_ar); ?>

            </textarea>
        </div>

        <div class="form-group">
            <label><?php echo app('translator')->get('site.service_content_en'); ?></label>
            <textarea class="form-control" name="service_content_en">
                <?php echo e($service_content_en); ?>

            </textarea>
        </div>

        <div class="form-group">
            <label><?php echo app('translator')->get('site.service_img'); ?></label>
            <input type="file" class="form-control" name="service_img1">
        </div>
        


        <div class="form-group">
            <button type="submit" class="btn btn-primary"><i class="fa fa-plus"></i> <?php echo app('translator')->get('site.save'); ?></button>
        </div>

        <?php echo Form::close(); ?>




        <!-- Button trigger modal -->


    </div><!-- end of box body -->






</div>






<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

<script src="https://cdn.ckeditor.com/4.17.1/standard/ckeditor.js"></script>
<script>
    CKEDITOR.replace('about_content_en');
    CKEDITOR.replace('about_content_ar');
    CKEDITOR.replace('service_content_en');
    CKEDITOR.replace('service_content_ar');
</script>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard.app2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\monaleza\Documents\nutration\resources\views//dashboard/sections/index.blade.php ENDPATH**/ ?>