<?php $__env->startSection('title'); ?>
<?php echo app('translator')->get('site.home'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div id="carouselExampleIndicators" class="carousel slide relative" data-ride="carousel">
        <ol class="carousel-indicators">
            <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
            <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
            <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
        </ol>
        <div class="carousel-inner">
            <?php
                $i = 0;
            ?>
            <?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $one): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="carousel-item  <?php if($i==0): ?> active <?php endif; ?> ">
                <img class=" w-100  " src="<?php echo e(asset($one->img)); ?>" alt="1 slide">

            </div>
                <?php
                    $i ++;
                ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


        </div>
        <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
            <span class="carousel-control-prev-icon " aria-hidden="true"></span>
            <span class="sr-only">Previous</span>
        </a>
        <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="sr-only">Next</span>
        </a>
    </div>
    <!--- end head --->
    <!--- -->
    <div class="container-fluid  ">
        <div class="container text-center ">
            <br>

            <h2><?php echo app('translator')->get('site.how_works'); ?>
                <hr>

            </h2>
            <br>

            <div class="row  ">
                <div class="col-md-3">
                    <?php if(Lang::locale()=='ar'): ?>

                    <i class="<?php echo e($works[0]->icon); ?>  icon"></i>
                    <h3><?php echo e($works[0]->title_ar); ?></h3>
                    <p><?php echo e($works[0]->content_ar); ?>

                    </p>
                    <br>
                    <?php else: ?>
                        <i class="<?php echo e($works[0]->icon); ?>  icon"></i>
                        <h3><?php echo e($works[0]->title_en); ?></h3>
                        <p><?php echo e($works[0]->content_en); ?>

                        </p>
                        <br>
                        <?php endif; ?>

                </div>
                <div class="col-md-6">
                    <div class="row">
                        <div class="col-md-3 pad-0 d-md-block d-none">
                            <br> <br> <br> <br>
                            <img src="<?php echo e(asset('front/img/awro1.png')); ?>">
                        </div>
                        <div class="col-md-6 pad-0">
                            <?php if(Lang::locale()=='ar'): ?>

                                <i class="<?php echo e($works[1]->icon); ?>  icon"></i>
                                <h3><?php echo e($works[1]->title_ar); ?></h3>
                                <p><?php echo e($works[1]->content_ar); ?>

                                </p>


                            <?php else: ?>
                                <i class="<?php echo e($works[1]->icon); ?>  icon"></i>
                                <h3><?php echo e($works[1]->title_en); ?></h3>
                                <p><?php echo e($works[1]->content_en); ?>

                                </p>
                                <?php endif; ?>
                        </div>

                        <div class="col-md-3 pad-0 d-md-block d-none">
                            <br> <br> <br>
                            <img src="<?php echo e(asset('front/img/awro2.png')); ?>"></div>
                    </div> <br></div>
                <div class="col-md-3">
                    <?php if(Lang::locale()=='ar'): ?>

                        <i class="<?php echo e($works[2]->icon); ?>  icon"></i>
                        <h3><?php echo e($works[2]->title_ar); ?></h3>
                        <p><?php echo e($works[2]->content_ar); ?>

                        </p>
                        <br>

                    <?php else: ?>

                        <i class="<?php echo e($works[2]->icon); ?>  icon"></i>
                        <h3><?php echo e($works[2]->title_en); ?></h3>
                        <p><?php echo e($works[2]->content_en); ?>

                        </p>
                        <br>
                        <?php endif; ?>
                </div>
            </div>
        </div>
    <!--- -->
    <div class="container-fluid text-center ">
        <br>
        <h2>    <?php echo app('translator')->get('site.services'); ?>

            <hr>
        </h2> <br>
        <ul class="services-list pad-0">
            <?php $__currentLoopData = $my_sevices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $my_sevice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><a href="">
                    <img class="lazy" src="<?php echo e(asset('front/img/cleaning.png')); ?>" >
                    <br>
                    <?php if(Lang::locale()=='ar'): ?>

                    <?php echo e($my_sevice->name_ar); ?></a></li>
                    <?php else: ?>
                    <?php echo e($my_sevice->name_en); ?></a></li>

                    <?php endif; ?>
           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <li><a href="<?php echo e(route('my_services.index')); ?>">
                    <img class="lazy" src="<?php echo e(asset('front/img/more.png')); ?>" ><br>
                    <?php echo app('translator')->get('site.view_more'); ?></a></li>
        </ul>
    </div>

    <!--- -->
    <div class="container text-center ">
        <br>
        <h2><?php echo app('translator')->get('site.why_works'); ?>
            <hr>
        </h2> <br>
        <div class="row text-left">
            <?php $__currentLoopData = $works; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $work): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <?php if(Lang::locale()=='ar'): ?>
                    <div class="col-lg-4 col-md-6 col-12">

                        <div class="row row3 pad">


                            <div class="col-3 ">
                                <br>
                                <i class="<?php echo e($work->icon); ?>  icon" ></i>
                            </div>
                            <div class="col-9 ">
                                <h3><?php echo e($work->title_ar); ?></h3>
                                <p><?php echo e($work->content_ar); ?>

                                </p>
                            </div>

                        </div>

                    </div>

                <?php else: ?>

                    <div class="col-lg-4 col-md-6 col-12">

                        <div class="row row3 pad">


                            <div class="col-3 ">
                                <br>
                                <i class="<?php echo e($work->icon); ?>  icon" ></i>
                            </div>
                            <div class="col-9 ">
                                <h3><?php echo e($work->title_en); ?></h3>
                                <p><?php echo e($work->content_en); ?>

                                </p>
                            </div>

                        </div>

                    </div>

                <?php endif; ?>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>
    </div>

    <!--- -->
    <div class="container-fluid text-center">
        <br> <br> <br>
        <div class="container">
            <div class="row">
                <div class="col-md-4 col-6">
                    <div class="circle">
                        <i class="fas fa-thumbs-up"></i>
                    </div>
                    <h2>100%</h2>
                    <p><?php echo app('translator')->get('site.quality'); ?></p>
                    <br>  </div>

                <div class="col-md-4 col-6">
                    <div class="circle">
                        <i class="fas fa-user"></i>
                    </div>
                    <h2>100+</h2>
                    <p><?php echo app('translator')->get('site.employees'); ?></p>
                    <br>  </div>

                <div class="col-md-4 col-12">
                    <div class="circle">
                        <i class="fas fa-calendar"></i>
                    </div>
                    <h2>5+</h2>
                    <p><p><?php echo app('translator')->get('site.years_experience'); ?></p></p>
                    <br>  </div>
            </div>


        </div>
    </div>
    <!--- -->





    <!-- country -->
    <div class="country ">

        <div class="relative">

            <video class="h-100 w-100 " autoplay controls muted>
                <source src="<?php echo e(asset('front/vedio/monstroid.mp4')); ?>" type="video/mp4" >
            </video>
            <div class="abs-shop text-center">
                <button class=" btn bg-main close-country  "> <?php echo app('translator')->get('site.continue'); ?>  </button>
            </div>

            <br> </div>

    </div>
    </div>





<?php $__env->stopSection(); ?>


        <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
        
            
            
            
                
                

                
                    
                    
                
                
                    
                    
                    
                    
                    
                    
                    
                    
                    
                
                    
                
                
                
                    
                        
                    
                
            
        

    

    
        
    


<script>
    // Get the modal
    var modal = document.getElementById("myModal");

    // Get the image and insert it inside the modal - use its "alt" text as a caption
    var img = document.getElementById("myImg");
    var modalImg = document.getElementById("img01");
    var captionText = document.getElementById("caption");
    img.onclick = function(){
        modal.style.display = "block";
        modalImg.src = this.src;
        captionText.innerHTML = this.alt;
    }

    // Get the <span> element that closes the modal
    var span = document.getElementsByClassName("close")[0];

    // When the user clicks on <span> (x), close the modal
    span.onclick = function() {
        modal.style.display = "none";
    }
</script>

<?php echo $__env->make('layouts.front.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\prestige\prestige\untitled folder\resources\views/front/index.blade.php ENDPATH**/ ?>