
<?php $__env->startSection('title'); ?>
<?php echo app('translator')->get("تعديل حالة الطلب"); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('mo'); ?>
    

     <?php $country = app('App\Models\Country'); ?>


     <?php $__env->startSection('ti'); ?>
         تعديل المحافظات
     <?php $__env->stopSection(); ?>

        <div class="box box-primary">




            <div class="box-header">

            </div><!-- end of box header -->
            <div class="box-body">

               <?php echo $__env->make('partials._errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


                 <?php echo Form::model($Govern, ['route' => ['governs.update',$Govern->id],
                  "method"=>"PUT"

                  ]); ?>

                    <?php echo e(csrf_field()); ?>


 <div class="form-group">
                            <label><?php echo app('translator')->get('الدولة'); ?> </label>
                            <?php echo Form::select('country_id',$country->pluck('name','id')->toArray(),null,[
                                'class' => 'form-control form-control-lg' . ($errors->has('category_id') ? ' is-invalid' : null),
                                 'id' => '',
                                 'placeholder' => 'اختر الدولة',
                               
    
                             ]); ?>

    
                        </div>

                        <div class="form-group">
                            <label><?php echo app('translator')->get('المحافظة'); ?></label>
                            <input type="text" name="name" class="form-control" value="<?php echo e($Govern->name); ?>" required>
                        </div>
				
				  <div class="form-group">
                            <label><?php echo app('translator')->get('المحافظة بالانجليزية'); ?></label>
                            <input type="text" name="name_en" class="form-control" value="<?php echo e($Govern->name_en); ?>" required>
                        </div>

                        <div class="form-group">
                            <label><?php echo app('translator')->get('سعر التوصيل'); ?></label>
                            <input type="text" name="price" class="form-control" value="<?php echo e($Govern->price); ?>" required>
                        </div>

                        <div class="form-group">
                            <label><?php echo app('translator')->get('الحالة '); ?></label>
                            <select style="width:100%"  name="activity" class="form-control " >
                                <option <?php if($Govern->activity == 1 ): ?>  <?php echo e("selected"); ?> <?php endif; ?> value="1">مفعلة</option>
                                <option <?php if($Govern->activity == 0 ): ?>  <?php echo e("selected"); ?> <?php endif; ?> value="0">معطلة</option>
                            
                        </select>
                        </div>
  
                        <div class="form-group">
                            <label><?php echo app('translator')->get('ترتيب الظهور'); ?></label>
                            <input  type="number" name="num" class="form-control" value="<?php echo e($Govern->num); ?>">
                        </div>


                    <div class="form-group">
                        <button type="submit" class="btn btn-primary"><i class="fa fa-plus"></i> <?php echo app('translator')->get('site.edit'); ?></button>
                    </div>

                    <?php echo Form::close(); ?>


            </div><!-- end of box body -->

        </div><!-- end of box -->












<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard.app2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/bluezo11/easyshop-qa.com/resources/views//dashboard/governs/edit.blade.php ENDPATH**/ ?>