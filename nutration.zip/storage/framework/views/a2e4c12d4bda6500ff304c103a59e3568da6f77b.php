<?php $__env->startSection('title'); ?>

    <?php echo app('translator')->get('site.post'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<div  class=" relative1 " >
    <div class="abs w-100">
        <h4 class="custom-h4"><?php echo $my_setting['blog_'.app()->getLocale()]; ?></h4>
        <h1><?php echo $my_section['posts_title_'.app()->getLocale()]; ?></h1>

    </div>
</div>

<section class="news-hr section  mb-5 mt-5">
    <div class="container">

        <div class="row no-gutters">
            <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <div class="col-lg-6">
                <article class="news-post-hr">
                    <div class="row">
                    <div class="col-md-12 col-12 post-thumb p-0">
                        <a href="<?php echo e(route('post.show',$item->id)); ?>">
                            <img src="<?php echo e(url($item->img)); ?>" alt="post-image" class="img-fluid">
                        </a>
                    </div>
                    <div class="col-md-12 col-12 post-contents border-top">
                        <div class="post-title">
                            <h6><a href="<?php echo e(route('post.show',$item->id)); ?>"><?php echo e($item['title_'.app()->getLocale()]); ?></a></h6>
                        </div>
                        <div class="post-exerpts">
                            
                            <p><?php echo $item['brief_'.app()->getLocale()]; ?></p>
                        </div>

                        <div class="date">
                            <h4>20<span>May</span></h4>
                        </div>
                        <div class="more text-dir1">
                            <a href="<?php echo e(route('post.show',$item->id)); ?>"><?php echo app('translator')->get('site.view_more'); ?></a>
                        </div>
                    </div>
                </div>
                </article>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            

        </div>
    </div>
</section>

<!--====  End of News  ====-->


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.front.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\monaleza\Documents\GitHub\Turk\resources\views/front/all_posts.blade.php ENDPATH**/ ?>