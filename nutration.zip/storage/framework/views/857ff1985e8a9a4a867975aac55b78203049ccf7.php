<?php $__env->startSection('title'); ?>

<?php echo $my_setting['product_'.app()->getLocale()]; ?>


<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

  <div  class=" relative1 " >
    <div class="abs w-100">
        <h4 class="custom-h4"><?php echo $my_setting['product_'.app()->getLocale()]; ?></h4>
        <h1><?php echo $my_section['products_title_'.app()->getLocale()]; ?></h1>

    </div>
</div>
<div class="container text-center center-p">
    <br>

    <h4 class="mb-4"><?php echo $my_section['product1_title_'.app()->getLocale()]; ?></h4>

    <h1><?php echo $my_section['product1_name_'.app()->getLocale()]; ?></h1>
    <p><?php echo $my_section['product1_content_'.app()->getLocale()]; ?></p>
    <br>

</div>


<br>


<div class="container">


    <div class="row">
        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <div class="col-lg-6 col-md-6 col-sm-12 mb-3">
            <div class="" style="position: relative">
                <img src="<?php echo e(url('/storage/'.$item->img)); ?>" alt="" class=" w-100 ">





                <div class="img-div4">
                    <div class="d-flex justify-content-between align-items-center">
                                    <h5><?php echo $item['title_'.app()->getLocale()]; ?>

                                    </h5>
                                <a href="<?php echo e(route('product.show',$item->id)); ?>">
                                    <h6>
                                         <?php echo app('translator')->get('site.view_more'); ?> &nbsp;  <?php if(Lang::locale()=='ar'): ?>
                                        <i class="fas fa-arrow-right text-light fa-flip-horizontal"></i>
                                        <?php else: ?>
                                        <i class="fas fa-arrow-right text-light "></i>
                                        <?php endif; ?>
                                    </h6>
                                </a>

                    </div>
                    </div>

            </div>

        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        




    </div>

</div>




<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.front.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\monaleza\Documents\GitHub\Turk\resources\views/front/all_products.blade.php ENDPATH**/ ?>