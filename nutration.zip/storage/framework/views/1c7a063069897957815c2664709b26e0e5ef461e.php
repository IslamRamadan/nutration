<?php $__env->startSection('title'); ?>
    <?php echo app('translator')->get("site.edit_category"); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('mo'); ?>




<?php $__env->startSection('ti'); ?>
    <?php echo app('translator')->get("site.edit_category"); ?>
<?php $__env->stopSection(); ?>

<div class="box box-primary">




    <div class="box-header">

    </div><!-- end of box header -->
    <div class="box-body">

        <?php echo $__env->make('partials._errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


        <?php echo Form::model("", ['route' => ['categories.update.category',$category->id],
        "method"=>"POST",'enctype' => 'multipart/form-data'

        ]); ?>

        <?php echo e(csrf_field()); ?>


        <div class="form-group">

            <label><?php echo app('translator')->get('site.title_ar'); ?></label>
            <input type="text" name="title_ar" class="form-control" value="<?php echo e($category->title_ar); ?>">
        </div>


        <div class="form-group">
            <label><?php echo app('translator')->get('site.title_en'); ?></label>
            <input type="text" name="title_en" class="form-control" value="<?php echo e($category->title_en); ?>">
        </div>

        <div class="form-group">
            <label><?php echo app('translator')->get('site.main_image'); ?></label>
            <input type="file" name="photo" class="form-control" >
        </div>

        <div class="form-group">
            <label><?php echo app('translator')->get('site.background_image'); ?></label>
            <input type="file" name="background_photo" class="form-control" >
        </div>


        <div class="form-group">
        <label><?php echo app('translator')->get('site.name_en'); ?></label>
            <input type="text" name="name_en" class="form-control" value="<?php echo e($category->name_en); ?>">
        </div>


        <div class="form-group">
            <label><?php echo app('translator')->get('site.name_ar'); ?></label>
            <input type="text" name="name_ar" class="form-control" value="<?php echo e($category->name_ar); ?>">
        </div>





        <div class="form-group">
            <label><?php echo app('translator')->get('site.content_en'); ?></label>
            <textarea  name="content_en" class="form-control">
            <?php echo e($category->content_en); ?></textarea>
        </div>


        <div class="form-group">
            <label><?php echo app('translator')->get('site.content_ar'); ?></label>
            <textarea  name="content_ar" class="form-control" >
            <?php echo e($category->content_ar); ?></textarea>
        </div>



        <div class="form-group text-center">
            <h2>اضافات اختياريه</h2>
        </div>

        <div class="form-group">
            <label><?php echo app('translator')->get('site.section1_en'); ?></label>
            <textarea  name="section1_en" class="form-control" >
            <?php echo e($category->section1_en); ?></textarea>
        </div>

        <div class="form-group">
            <label><?php echo app('translator')->get('site.section1_ar'); ?></label>
            <textarea  name="section1_ar" class="form-control" >
            <?php echo e($category->section1_ar); ?></textarea>
        </div>


        <div class="form-group">
            <label><?php echo app('translator')->get('site.section2_title_en'); ?></label>
            <input type="text" name="section2_title_en" class="form-control" value="<?php echo e($category->section2_title_en); ?>">
        </div>

        <div class="form-group">
            <label><?php echo app('translator')->get('site.section2_title_ar'); ?></label>
            <input type="text" name="section2_title_ar" class="form-control" value="<?php echo e($category->section2_title_ar); ?>">

        </div>

        <div class="form-group">
            <label><?php echo app('translator')->get('site.section2_content_en'); ?></label>
            <textarea  name="section2_content_en" class="form-control">
            <?php echo e($category->section2_content_en); ?></textarea>
        </div>

        <div class="form-group">
            <label><?php echo app('translator')->get('site.section2_content_ar'); ?></label>
            <textarea  name="section2_content_ar" class="form-control">
            <?php echo e($category->section2_content_ar); ?></textarea>
        </div>

        <div class="form-group">
            <label><?php echo app('translator')->get('site.section2_image'); ?></label>
            <input type="file" name="section2_photo" class="form-control" >
        </div>







        <div class="form-group">
            <button type="submit" class="btn btn-primary"><i class="fa fa-plus"></i> <?php echo app('translator')->get('site.edit'); ?></button>
        </div>

        <?php echo Form::close(); ?>


    </div><!-- end of box body -->

</div><!-- end of box -->










<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

<script src="https://cdn.ckeditor.com/4.17.1/standard/ckeditor.js"></script>
<script>
    // CKEDITOR.replace( 'content_ar' );
    // CKEDITOR.replace( 'content_en' );
    CKEDITOR.replace( 'section1_en' );
    CKEDITOR.replace( 'section1_ar' );
</script>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard.app2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\monaleza\Documents\GitHub\Turk\resources\views//dashboard/categories/edit.blade.php ENDPATH**/ ?>