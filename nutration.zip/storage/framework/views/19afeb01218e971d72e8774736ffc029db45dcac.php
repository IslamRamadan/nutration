<?php echo e($slot); ?>

<?php /**PATH /home/bluezo11/easyshop-qa.com/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>