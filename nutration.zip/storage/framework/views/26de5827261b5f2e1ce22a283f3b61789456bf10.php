 <a href="<?php echo e(url('/en/cart')); ?>" class="nav-link   border-right"  >  <i class="fas fa-shopping-bag" ></i> cart <b>
 <sup class="text-danger" id="cart_counter" style="font-size: 15px;">
 ( <?php echo e((session('cart')  !== null )? count(session('cart')): 0); ?> )
 </sup>
 </b></a>
 
<div id="cart_body" class=" li2 pad-0"  style="width: 350px;padding: 10px;right:0!important;left:auto!important;">

<div class="row border-bottom mr-0">
<div class="col-8">there is (<?php echo e((session('cart')  !== null )? count(session('cart')): 0); ?>) item</div>
<a class="col-4  text-right"  id="dropdownMenuButton" data-toggle="dropdown">  <i class="fas fa-times" style="font-size: 20px"></i> </a>    
</div>
<br>
<?php //\Session::forget('cart'); ?>
<?php if(session('cart')): ?>
	
<?php $__currentLoopData = session('cart'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $details): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>	
<?php 
 $product = \App\Models\Item::where('id', $details['id'])->first();
$vendor = \App\Models\Category::where('id', $product->category_id)->first();
?>
<div class="row  mr-0 border-bottom">
<div class="col-3  ">
  <a href="<?php echo e(url('/en/product/'.$product->slug)); ?> ">
	 <img alt="<?php echo e($product->name); ?>" src="<?php echo e(url('/public/uploads/')); ?>/<?php echo e($product->thumbnail); ?>"  class="w-100">
  </a>
</div>
<div class="col-9 ">   
	 <a href=" <?php echo e(url('/en/product/'.$product->slug)); ?> " class="active "><h6><?php echo e($product->name); ?></h6></a>
  <h6 class="">vendor : <?php echo e($vendor->name); ?> </h6> 
<h6 class=""><b><?php echo e($product->price); ?>KWD </b> </h6>                                               
<!--
<form class=" product-count float-left ">
<a rel="nofollow" class="btn btn-default btn-minus" href="#" title="Subtract">&ndash;</a>
<input type="text" disabled="" size="2" autocomplete="off" class="cart_quantity_input form-control grey count" value="1" name="quantity">
<a rel="nofollow" class="btn btn-default btn-plus" href="#" title="Add">+</a>
</form>        
  <a   class="active float-right"><i class="fas fa-archive"  ></i></a> 
  -->
</div>     
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php else: ?>
	<h6 class="text-center" style="color:#41479b"> There are no items in the cart  </h6>
<?php endif; ?>
<br>
<?php if(session('cart')): ?>
<div class="row  mr-0">
<!--
<p  class="col-6  ">cart subtotal</p>
<p  class="col-6  text-right"> $800.00</p>
-->
<div class="col-6  ">
<a  href="<?php echo e(url('/en/checkout')); ?>" class="btn w-100 bg-main ">Checkout</a> 
</div>
<div class="col-6  ">
<a  href="<?php echo e(url('/en/cart')); ?>" class="btn w-100 btn-light border">View bag</a>
</div>
</div>
<?php endif; ?>
<br>

</div><?php /**PATH C:\xampp\htdocs\kokart\resources\views/front/includes/header_cart.blade.php ENDPATH**/ ?>